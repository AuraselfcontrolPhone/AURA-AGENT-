package com.aura.agent

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

/**
 * SEENA main screen: futuristic dashboard. Status, assistant, and one section per kind of thing.
 * Each device button has two tabs: ON sends its ON link, OFF sends its OFF link (in the background).
 */
class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private var edit = false
    private lateinit var mem: Memory
    private val ui = Handler(Looper.getMainLooper())
    private var waveView: WaveView? = null
    private var tick = 0

    private val waveRun: Runnable = object : Runnable {
        override fun run() {
            val w = waveView ?: return
            tick++
            w.push((0.15f + 0.85f * Math.abs(Math.sin(tick * 0.45)).toFloat() * (0.4f + Math.random().toFloat() * 0.6f)))
            ui.postDelayed(this, 90)
        }
    }

    private fun dp(v: Int): Int = Neo.dp(this, v)
    private val glass = Color.parseColor("#B30B1030")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#02030D")
        window.navigationBarColor = Color.parseColor("#02030D")
        mem = Memory.get(this)
        mem.seedDefaultsIfEmpty()

        val frame = FrameLayout(this)
        frame.addView(FuturisticBg(this), FrameLayout.LayoutParams(-1, -1))
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.layoutDirection = View.LAYOUT_DIRECTION_RTL
        content.setPadding(dp(14), dp(34), dp(14), dp(110))
        scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(content)
        frame.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        val nav = navBar()
        val np = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM)
        np.setMargins(dp(12), 0, dp(12), dp(12))
        frame.addView(nav, np)
        setContentView(frame)
    }

    override fun onResume() {
        super.onResume()
        build()
        val svc = AuraService.instance
        if (svc != null) {
            svc.overlay.showIdle()                       // the moon appears as soon as the app opens
            if (!Prefs.getBool(this, "studied", false)) {   // study the phone once, automatically
                Prefs.setBool(this, "studied", true)
                Toast.makeText(this, "SEENA فون کو اسٹڈی کر رہا ہے...", Toast.LENGTH_LONG).show()
                content.postDelayed({ svc.study() }, 1500)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(waveRun)
    }

    /* ---------------- helpers ---------------- */

    private fun tv(t: String, size: Float, color: Int): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        return v
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = Neo.pill(this, glass, Neo.stroke, 22)
        c.setPadding(dp(14), dp(12), dp(14), dp(14))
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, 0, 0, dp(14))
        c.layoutParams = p
        return c
    }

    private fun sectionTitle(text: String, icon: String): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(tv(icon, 18f, Neo.cyan))
        val t = tv("  $text", 16f, Neo.goldHi)
        t.typeface = Typeface.DEFAULT_BOLD
        row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        return row
    }

    private fun smallBtn(label: String, color: Int, click: () -> Unit): TextView {
        val b = tv(label, 13f, color)
        b.setPadding(dp(10), dp(4), dp(10), dp(4))
        b.background = Neo.pill(this, 0, Neo.stroke, 12)
        b.setOnClickListener { click() }
        return b
    }

    private fun navItem(icon: String, label: String, click: () -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.addView(tv(icon, 20f, Color.WHITE))
        c.addView(tv(label, 10f, Neo.dim))
        c.setOnClickListener { click() }
        c.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        return c
    }

    private fun navBar(): LinearLayout {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.layoutDirection = View.LAYOUT_DIRECTION_RTL
        bar.background = Neo.pill(this, Color.parseColor("#EE070A1C"), Neo.stroke, 28)
        bar.setPadding(dp(8), dp(8), dp(8), dp(8))
        bar.addView(navItem("🏠", "ہوم") { scroll.smoothScrollTo(0, 0) })
        bar.addView(navItem("📔", "ڈائری") { showDiary() })
        val mic = tv("🎙", 24f, Color.WHITE)
        mic.gravity = Gravity.CENTER
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        d.setColor(Color.parseColor("#14305A"))
        d.setStroke(dp(2), Neo.cyan)
        mic.background = d
        mic.setOnClickListener {
            val svc = AuraService.instance
            if (svc == null) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            else { svc.setAlwaysListen(!svc.always); build() }
        }
        bar.addView(mic, LinearLayout.LayoutParams(dp(58), dp(58)))
        bar.addView(navItem("⚙", "سیٹنگ") { startActivity(Intent(this, SettingsActivity::class.java)) })
        bar.addView(navItem("⋯", "مزید") {
            val svc = AuraService.instance
            if (svc != null) svc.overlay.showOrders() else Toast.makeText(this, "پہلے Accessibility میں SEENA چالو کریں", Toast.LENGTH_SHORT).show()
        })
        return bar
    }

    private fun showDiary() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert).setMessage(Diary.today(this)).setPositiveButton("ٹھیک", null).show()
    }

    /* ---------------- the page ---------------- */

    private fun build() {
        content.removeAllViews()
        ui.removeCallbacks(waveRun)
        val svc = AuraService.instance

        // header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(OrbView(this), LinearLayout.LayoutParams(dp(60), dp(60)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(10), 0, dp(10), 0)
        val name = tv("SEENA AI", 26f, Color.WHITE)
        name.typeface = Typeface.DEFAULT_BOLD
        name.letterSpacing = 0.12f
        titles.addView(name)
        val sub = tv("Your Smart AI Assistant", 11f, Neo.cyan)
        sub.typeface = Typeface.MONOSPACE
        titles.addView(sub)
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(smallBtn(if (edit) "✔ ہو گیا" else "✎ ترمیم", if (edit) Neo.green else Neo.goldHi) { edit = !edit; build() })
        content.addView(head)
        val hp = head.layoutParams as LinearLayout.LayoutParams
        hp.setMargins(0, 0, 0, dp(14))
        head.layoutParams = hp

        // status card: battery | mode | devices
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val bat = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val online = Net.online(this)
        val mode = Prefs.aiMode(this)
        val stc = card()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun cell(icon: String, big: String, small: String): LinearLayout {
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER
            c.addView(tv("$icon $big", 18f, Color.WHITE))
            c.addView(tv(small, 11f, Neo.dim))
            c.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            return c
        }
        row.addView(cell("🔋", "$bat%", "بیٹری"))
        row.addView(cell(if (online) "🌐" else "📴", if (online) "آن لائن" else "آف لائن", when (mode) { "offline" -> "صرف آف لائن"; "online" -> "AI ہمیشہ"; else -> "خودکار" }))
        row.addView(cell("💡", "${mem.allDevices().size}", "بٹن"))
        stc.addView(row)
        content.addView(stc)

        // hello card: moon + greeting + live wave + always listen
        val hello = card()
        val hr = LinearLayout(this)
        hr.orientation = LinearLayout.HORIZONTAL
        hr.gravity = Gravity.CENTER_VERTICAL
        hr.addView(OrbView(this), LinearLayout.LayoutParams(dp(64), dp(64)))
        val ht = LinearLayout(this)
        ht.orientation = LinearLayout.VERTICAL
        ht.setPadding(dp(10), 0, 0, 0)
        ht.addView(tv("Hello! I am SEENA AI", 17f, Color.WHITE))
        ht.addView(tv("How can I help you today?", 12f, Neo.dim))
        val wv = WaveView(this)
        waveView = wv
        ht.addView(wv, LinearLayout.LayoutParams(-1, dp(34)))
        hr.addView(ht, LinearLayout.LayoutParams(0, -2, 1f))
        hello.addView(hr)
        if (svc == null) {
            hello.addView(smallBtn("Accessibility میں SEENA چالو کریں", Neo.goldHi) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        } else {
            val sw = Switch(this)
            sw.text = "🎙 ہمیشہ سننا (نام لیں: \"سینا\")"
            sw.setTextColor(Color.WHITE)
            sw.textSize = 14f
            sw.isChecked = svc.always
            sw.setPadding(0, dp(8), 0, dp(4))
            sw.setOnCheckedChangeListener { _, on -> svc.setAlwaysListen(on) }
            hello.addView(sw)
            if (mode != "online") hello.addView(tv("✔ Offline Voice Control", 12f, Neo.cyan))
        }
        content.addView(hello)
        ui.post(waveRun)

        // device sections
        for (s in mem.sections()) content.addView(sectionCard(s))
        if (edit) content.addView(smallBtn("＋ نیا سیکشن", Neo.goldHi) { editSection(null) })

        // calls
        val calls = mem.recentCalls(3)
        val c = card()
        c.addView(sectionTitle("کالز (SEENA نے سنبھالی)", "☎"))
        if (calls.isEmpty()) {
            c.addView(tv("جب کوئی کال 10 سیکنڈ تک نہ اٹھے تو SEENA اٹھا کر پیغام ریکارڈ کرتا ہے۔", 12f, Neo.dim))
        } else {
            for (k in calls) {
                c.addView(tv("📞 " + (if (k.name.isNotBlank()) k.name else k.number), 14f, Color.WHITE))
                c.addView(tv(k.summary, 12f, Neo.cyan))
            }
        }
        content.addView(c)

        // diary + learned habits
        val dcard = card()
        dcard.addView(sectionTitle("آج کی ڈائری", "📔"))
        dcard.addView(tv(Diary.today(this), 12f, Neo.text))
        for (h in Diary.habits(this)) {
            val line = tv(String.format("💡 آپ روز %02d:%02d پر کرتے ہیں: ", h.second, h.third) + h.first.take(40), 12f, Neo.goldHi)
            line.setPadding(0, dp(8), 0, 0)
            dcard.addView(line)
            dcard.addView(smallBtn("اسے روز خود چلاؤ", Neo.green) {
                val sc = mem.addSchedule(h.first, h.second, h.third, true)
                Scheduler.arm(this, sc)
                build()
            })
        }
        content.addView(dcard)

        // rules
        val rules = mem.schedules()
        val r = card()
        r.addView(sectionTitle("قوانین (وقت پر خود چلیں)", "⏰"))
        if (rules.isEmpty()) r.addView(tv("بٹن کی ⚙ سیٹنگ میں ON/OFF کا وقت لکھیں، یا کہیں: \"روز رات 11 بجے ڈیٹا بند کرو\"", 12f, Neo.dim))
        for (x in rules) r.addView(tv(String.format("%02d:%02d  ", x.hour, x.min) + mem.ruleLabel(x), 13f, Color.WHITE))
        content.addView(r)

        val tip = tv("آواز سے: \"کمرے کی لائٹ آن کرو\"، \"سب لائٹس بند کرو\"۔ ٹوٹی پھوٹی بات بھی سمجھتا ہے، ایپ بند ہو تب بھی چلتا ہے۔", 11f, Neo.dim)
        tip.setPadding(dp(6), dp(4), dp(6), 0)
        content.addView(tip)
    }

    private fun sectionCard(s: Memory.Section): LinearLayout {
        val c = card()
        val head = sectionTitle(s.name, "▣")
        if (edit) {
            head.addView(smallBtn("＋", Neo.green) { editDevice(null, s.id) })
            val rn = smallBtn("✎", Neo.goldHi) { editSection(s) }
            val rp = LinearLayout.LayoutParams(-2, -2)
            rp.setMargins(dp(6), 0, 0, 0)
            head.addView(rn, rp)
        }
        c.addView(head)

        val devs = mem.devices(s.id)
        if (devs.isEmpty()) c.addView(tv("اس سیکشن میں ابھی کوئی بٹن نہیں۔ ✎ دبا کر ＋ سے بٹن بنائیں۔", 12f, Neo.dim))
        var i = 0
        while (i < devs.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val rp = LinearLayout.LayoutParams(-1, -2)
            rp.setMargins(0, dp(10), 0, 0)
            row.layoutParams = rp
            for (j in 0 until 2) {
                val lp = LinearLayout.LayoutParams(0, -2, 1f)
                lp.setMargins(if (j == 0) 0 else dp(10), 0, 0, 0)
                if (i + j < devs.size) row.addView(tile(devs[i + j]), lp) else row.addView(View(this), lp)
            }
            c.addView(row)
            i += 2
        }
        return c
    }

    private fun iconFor(n: String): String {
        val l = n.lowercase()
        return when {
            l.contains("لائٹ") || l.contains("light") || l.contains("بلب") || l.contains("روشنی") -> "💡"
            l.contains("پنکھ") || l.contains("fan") -> "🌀"
            l.contains("اے سی") || l.contains("ac") || l.contains("ایئر") -> "❄️"
            l.contains("گیٹ") || l.contains("دروازہ") || l.contains("lock") || l.contains("تالا") -> "🔒"
            l.contains("موٹر") || l.contains("پمپ") || l.contains("پانی") -> "💧"
            else -> "🔌"
        }
    }

    private fun tileColors(icon: String): IntArray = when (icon) {
        "💡" -> intArrayOf(Color.parseColor("#1E6BFF"), Color.parseColor("#0B2A6B"))
        "🌀" -> intArrayOf(Color.parseColor("#8A3DFF"), Color.parseColor("#2A1066"))
        "❄️" -> intArrayOf(Color.parseColor("#18C964"), Color.parseColor("#0A4A2A"))
        "🔒" -> intArrayOf(Color.parseColor("#FF8A1F"), Color.parseColor("#6B3206"))
        "💧" -> intArrayOf(Color.parseColor("#14B8D6"), Color.parseColor("#0A3B4A"))
        else -> intArrayOf(Color.parseColor("#4A5AA8"), Color.parseColor("#1A2250"))
    }

    /** A device button: icon + name + two tabs, ON and OFF. */
    private fun tile(d: Memory.Device): View {
        val icon = iconFor(d.name)
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, tileColors(icon))
        g.cornerRadius = dp(18).toFloat()
        g.setStroke(dp(if (d.state == 1) 2 else 1), if (d.state == 1) Neo.cyan else Neo.stroke)
        t.background = g
        t.setPadding(dp(10), dp(10), dp(10), dp(10))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(tv(icon, 26f, Color.WHITE))
        val sp = View(this)
        top.addView(sp, LinearLayout.LayoutParams(0, 1, 1f))
        val gear = tv("⚙", 16f, Color.WHITE)
        gear.setOnClickListener { editDevice(d, d.section) }
        top.addView(gear)
        t.addView(top)

        val n = tv(d.name, 14f, Color.WHITE)
        n.typeface = Typeface.DEFAULT_BOLD
        n.maxLines = 2
        t.addView(n)

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        val tp = LinearLayout.LayoutParams(-1, -2)
        tp.setMargins(0, dp(10), 0, 0)
        tabs.layoutParams = tp
        tabs.addView(tab("ON", d, true), LinearLayout.LayoutParams(0, -2, 1f))
        val offLp = LinearLayout.LayoutParams(0, -2, 1f)
        offLp.setMargins(dp(8), 0, 0, 0)
        tabs.addView(tab("OFF", d, false), offLp)
        t.addView(tabs)
        return t
    }

    private fun tab(label: String, d: Memory.Device, on: Boolean): TextView {
        val active = (d.state == 1 && on) || (d.state == 2 && !on)
        val v = tv(label, 14f, Color.WHITE)
        v.gravity = Gravity.CENTER
        v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(0, dp(8), 0, dp(8))
        v.background = if (active) Neo.pill(this, Color.parseColor("#66FFFFFF"), Color.WHITE, 12) else Neo.pill(this, Color.parseColor("#22000000"), Color.parseColor("#66FFFFFF"), 12)
        v.setOnClickListener { trigger(d, on, v) }
        return v
    }

    private fun trigger(d: Memory.Device, on: Boolean, v: TextView) {
        v.text = "..."
        thread {
            val r = HomeAuto.runNow(this, d, on)
            runOnUiThread {
                Toast.makeText(this, (if (r.ok) "✓ " else "✗ ") + d.name + (if (on) " ON" else " OFF") + (if (r.ok) "" else "  (" + r.msg + ")"), Toast.LENGTH_SHORT).show()
                build()
            }
        }
    }

    /* ---------------- editors ---------------- */

    private fun dialog(): AlertDialog.Builder = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)

    private fun field(hintText: String, value: String): EditText {
        val e = EditText(this)
        e.hint = hintText
        e.setText(value)
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Neo.dim)
        e.textSize = 14f
        e.setSingleLine(true)
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        return e
    }

    private fun editSection(s: Memory.Section?) {
        val e = field("سیکشن کا نام", s?.name ?: "")
        e.inputType = InputType.TYPE_CLASS_TEXT
        val b = dialog().setTitle(if (s == null) "نیا سیکشن" else "سیکشن").setView(e)
            .setPositiveButton("محفوظ") { _, _ ->
                val n = e.text.toString().trim()
                if (n.isNotEmpty()) { if (s == null) mem.addSection(n) else mem.renameSection(s.id, n); build() }
            }
            .setNegativeButton("منسوخ", null)
        if (s != null) b.setNeutralButton("حذف") { _, _ -> mem.deleteSection(s.id); build() }
        b.show()
    }

    /** Device editor: name, Tasmota helper, two tabs (ON link / OFF link) and offline timers. */
    private fun editDevice(d: Memory.Device?, sectionId: Long) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(8), dp(18), 0)
        val nameF = field("بٹن کا نام (مثلاً کمرے کی لائٹ)", d?.name ?: "")
        nameF.inputType = InputType.TYPE_CLASS_TEXT
        box.addView(nameF)

        var onUrl = d?.onUrl ?: ""
        var offUrl = d?.offUrl ?: ""
        var tabOn = true
        val urlF = field("http://...  (ON کے لیے لنک)", onUrl)
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        val tOn = tv("ON", 14f, Color.WHITE)
        val tOff = tv("OFF", 14f, Color.WHITE)
        fun paint() {
            tOn.background = if (tabOn) Neo.pill(this, Neo.gold, 0, 12) else Neo.pill(this, 0, Neo.stroke, 12)
            tOff.background = if (!tabOn) Neo.pill(this, Neo.gold, 0, 12) else Neo.pill(this, 0, Neo.stroke, 12)
            urlF.hint = if (tabOn) "http://...  (ON کے لیے لنک)" else "http://...  (OFF کے لیے لنک)"
        }
        for (t in listOf(tOn, tOff)) { t.gravity = Gravity.CENTER; t.setPadding(0, dp(8), 0, dp(8)) }
        tOn.setOnClickListener {
            if (!tabOn) { offUrl = urlF.text.toString().trim(); tabOn = true; urlF.setText(onUrl); paint() }
        }
        tOff.setOnClickListener {
            if (tabOn) { onUrl = urlF.text.toString().trim(); tabOn = false; urlF.setText(offUrl); paint() }
        }
        val l1 = LinearLayout.LayoutParams(0, -2, 1f)
        val l2 = LinearLayout.LayoutParams(0, -2, 1f)
        l2.setMargins(dp(8), 0, 0, 0)
        tabs.addView(tOn, l1)
        tabs.addView(tOff, l2)
        val tp = LinearLayout.LayoutParams(-1, -2)
        tp.setMargins(0, dp(14), 0, dp(8))
        box.addView(tabs, tp)
        box.addView(urlF)
        paint()

        // Tasmota helper: IP + relay number -> both links
        val ipF = field("Tasmota کا IP (مثلاً 10.154.104.141)", "")
        ipF.inputType = InputType.TYPE_CLASS_TEXT
        val rlF = field("رِلے نمبر (1 یا 2 ...)", "")
        rlF.inputType = InputType.TYPE_CLASS_NUMBER
        val mk = smallBtn("⚡ Tasmota لنک خود بناؤ", Neo.cyan) {
            val ip = ipF.text.toString().trim()
            val rn = rlF.text.toString().trim().ifEmpty { "1" }
            if (ip.isNotEmpty()) {
                onUrl = "http://$ip/cm?cmnd=Power$rn%20On"
                offUrl = "http://$ip/cm?cmnd=Power$rn%20Off"
                urlF.setText(if (tabOn) onUrl else offUrl)
            }
        }
        val ipp = LinearLayout.LayoutParams(-1, -2)
        ipp.setMargins(0, dp(12), 0, 0)
        box.addView(ipF, ipp)
        box.addView(rlF)
        val mkp = LinearLayout.LayoutParams(-2, -2)
        mkp.setMargins(0, dp(6), 0, 0)
        box.addView(mk, mkp)

        val test = smallBtn("▶ اس لنک کو آزمائیں", Neo.cyan) {
            val u = urlF.text.toString().trim()
            thread {
                val r = HomeAuto.fire(u)
                runOnUiThread { Toast.makeText(this, (if (r.ok) "✓ " else "✗ ") + r.msg, Toast.LENGTH_SHORT).show() }
            }
        }
        val tsp = LinearLayout.LayoutParams(-2, -2)
        tsp.setMargins(0, dp(10), 0, 0)
        box.addView(test, tsp)

        // offline timers
        box.addView(tv("⏰ شیڈول (آف لائن، روز): وقت 24 گھنٹے میں، مثلاً 19:30", 12f, Neo.goldHi))
        val onT = field("ON کا وقت  HH:MM", "")
        onT.inputType = InputType.TYPE_CLASS_TEXT
        val offT = field("OFF کا وقت  HH:MM", "")
        offT.inputType = InputType.TYPE_CLASS_TEXT
        if (d != null) for (sc in mem.deviceSchedules(d.id)) {
            val tm = String.format("%02d:%02d", sc.hour, sc.min)
            if (sc.goal.endsWith(":1")) onT.setText(tm) else offT.setText(tm)
        }
        box.addView(onT)
        box.addView(offT)
        box.addView(tv("لنک کے شروع میں POST لکھیں تو POST بھیجے گا۔ http:// نہ لکھیں تو خود لگ جاتا ہے۔ فون اور بٹن ایک ہی Wi-Fi پر ہوں۔", 11f, Neo.dim))

        fun readBack() {
            if (tabOn) onUrl = urlF.text.toString().trim() else offUrl = urlF.text.toString().trim()
        }

        val sv = ScrollView(this)
        sv.addView(box)
        val b = dialog().setTitle(if (d == null) "نیا بٹن" else "بٹن کی سیٹنگ").setView(sv)
            .setPositiveButton("محفوظ") { _, _ ->
                readBack()
                val n = nameF.text.toString().trim()
                if (n.isNotEmpty()) {
                    val devId: Long = if (d == null) mem.addDevice(sectionId, n, onUrl, offUrl) else { mem.updateDevice(d.id, n, onUrl, offUrl); d.id }
                    for (old in mem.deviceSchedules(devId)) { Scheduler.cancel(this, old.id); mem.deleteSchedule(old.id) }
                    for (pr in listOf(Pair(onT.text.toString(), "1"), Pair(offT.text.toString(), "0"))) {
                        val m = Regex("^(\\d{1,2}):(\\d{2})$").find(pr.first.trim())
                        if (m != null) {
                            val h = m.groupValues[1].toInt()
                            val mi = m.groupValues[2].toInt()
                            if (h in 0..23 && mi in 0..59) Scheduler.arm(this, mem.addSchedule("DEV:$devId:${pr.second}", h, mi, true))
                        }
                    }
                    build()
                }
            }
            .setNegativeButton("منسوخ", null)
        if (d != null) b.setNeutralButton("حذف") { _, _ ->
            for (old in mem.deviceSchedules(d.id)) { Scheduler.cancel(this, old.id); mem.deleteSchedule(old.id) }
            mem.deleteDevice(d.id)
            build()
        }
        b.show()
    }
}
