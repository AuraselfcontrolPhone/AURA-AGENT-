package com.aura.agent

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.provider.CallLog
import android.provider.ContactsContract
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Answers about the phone itself, with no internet and no API. */
object LocalFacts {
    private val days = arrayOf("اتوار", "پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ")
    private val months = arrayOf("جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون", "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر")

    fun answer(ctx: Context, text: String): String? {
        val raw = text.lowercase()
        val t = Fuzzy.norm(text)
        fun has(vararg w: String): Boolean = w.any { raw.contains(it) || t.contains(Fuzzy.norm(it)) }
        val mem = Memory.get(ctx)
        when {
            has("ڈائری", "diary") -> return Diary.today(ctx)
            has("بیٹری", "battery") -> {
                val b = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                return "🔋 بیٹری ${b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}% ہے۔"
            }
            has("کتنے بجے", "وقت کیا", "ٹائم کیا", "what time") ->
                return "🕒 ابھی " + SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date()) + " بجے ہیں۔"
            has("تاریخ", "کون سا دن", "کیا دن", "today date") -> {
                val c = Calendar.getInstance()
                return "📅 آج " + days[c.get(Calendar.DAY_OF_WEEK) - 1] + "، " + c.get(Calendar.DAY_OF_MONTH) + " " + months[c.get(Calendar.MONTH)] + " " + c.get(Calendar.YEAR) + " ہے۔"
            }
            has("اسٹوریج", "جگہ خالی", "storage") -> {
                val st = StatFs(Environment.getDataDirectory().path)
                return "💾 فون میں %.1f GB جگہ خالی ہے۔".format(st.availableBytes / 1073741824.0)
            }
            has("کتنی ایپس", "کتنے ایپس", "how many apps") -> return "📱 فون میں ${mem.appCount()} ایپس ہیں۔"
            has("کس کا میسج", "میسج آیا", "کس نے میسج", "new message") -> {
                val m = mem.recentMessages(3)
                if (m.isEmpty()) return "ابھی کوئی واٹس ایپ میسج میں نے نہیں دیکھا۔"
                return "💬 آخری میسج:\n" + m.joinToString("\n") { "• " + it.first + ": " + it.second.take(80) }
            }
            has("مس کال", "missed call", "کس کی کال") -> return missed(ctx)
        }
        val mm = Regex("(.+?)\\s*کا نمبر").find(text)
        if (mm != null) return contact(ctx, mm.groupValues[1].trim().split(" ").last())
        return null
    }

    private fun missed(ctx: Context): String {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return "کال لاگ کی اجازت نہیں ہے (سیٹنگ میں 'اجازتیں دیں')۔"
        val out = ArrayList<String>()
        try {
            ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.DATE),
                CallLog.Calls.TYPE + "=?", arrayOf(CallLog.Calls.MISSED_TYPE.toString()), CallLog.Calls.DATE + " DESC")?.use {
                while (it.moveToNext() && out.size < 3) {
                    val nm = it.getString(1) ?: it.getString(0)
                    out.add("• " + nm + "  " + SimpleDateFormat("dd/MM hh:mm a", Locale.ENGLISH).format(Date(it.getLong(2))))
                }
            }
        } catch (e: Exception) {}
        return if (out.isEmpty()) "کوئی مس کال نہیں۔" else "📞 مس کالز:\n" + out.joinToString("\n")
    }

    private fun contact(ctx: Context, name: String): String {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return "کانٹیکٹس کی اجازت نہیں ہے۔"
        val out = ArrayList<String>()
        try {
            ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$name%"), null)?.use {
                while (it.moveToNext() && out.size < 3) out.add("• " + it.getString(0) + ": " + it.getString(1))
            }
        } catch (e: Exception) {}
        return if (out.isEmpty()) "\"$name\" نام کا کانٹیکٹ نہیں ملا۔" else "📇\n" + out.joinToString("\n")
    }
}

/** A short daily diary written by the phone itself (no AI): what you did and when, plus habit suggestions. */
object Diary {
    fun today(ctx: Context): String {
        val mem = Memory.get(ctx)
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        val start = c.timeInMillis
        val orders = mem.recentOrders(200).filter { it.ts >= start }.reversed()
        val calls = mem.recentCalls(20).filter { it.ts >= start }
        val msgs = mem.recentMessages(100).filter { it.third >= start }
        if (orders.isEmpty() && calls.isEmpty() && msgs.isEmpty()) return "📔 آج ابھی کچھ نہیں ہوا۔"
        val sb = StringBuilder("📔 آج کی ڈائری\n")
        sb.append("${orders.size} حکم (${orders.count { it.status == "ok" }} کامیاب)")
        if (calls.isNotEmpty()) sb.append("، ${calls.size} کال سنبھالی")
        if (msgs.isNotEmpty()) sb.append("، ${msgs.size} واٹس ایپ میسج آئے")
        sb.append("\n")
        val f = SimpleDateFormat("hh:mm a", Locale.ENGLISH)
        orders.takeLast(12).forEach { sb.append("• ").append(f.format(Date(it.ts))).append("  ").append(it.text.take(40)).append(if (it.status == "ok") " ✓" else " ✗").append("\n") }
        return sb.toString().trim()
    }

    /** Things you do again and again at the same time of day -> (command, hour, minute). */
    fun habits(ctx: Context): List<Triple<String, Int, Int>> {
        val mem = Memory.get(ctx)
        val byText = HashMap<String, MutableList<Long>>()
        for (o in mem.recentOrders(400)) if (o.status == "ok") byText.getOrPut(Fuzzy.norm(o.text)) { ArrayList() }.add(o.ts)
        val have = mem.schedules().map { Fuzzy.norm(it.goal) }
        val out = ArrayList<Triple<String, Int, Int>>()
        for ((txt, list) in byText) {
            if (list.size < 3 || have.contains(txt)) continue
            val mins = list.map { val cc = Calendar.getInstance(); cc.timeInMillis = it; cc.get(Calendar.HOUR_OF_DAY) * 60 + cc.get(Calendar.MINUTE) }.sorted()
            val med = mins[mins.size / 2]
            val close = list.filter { val cc = Calendar.getInstance(); cc.timeInMillis = it; Math.abs(cc.get(Calendar.HOUR_OF_DAY) * 60 + cc.get(Calendar.MINUTE) - med) <= 45 }
            val days = close.map { it / 86400000L }.toSet().size
            if (close.size >= 3 && days >= 3) out.add(Triple(txt, med / 60, med % 60))
            if (out.size >= 3) break
        }
        return out
    }
}
