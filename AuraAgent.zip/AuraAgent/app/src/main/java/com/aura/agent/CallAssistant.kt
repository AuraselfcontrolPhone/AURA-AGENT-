package com.aura.agent

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Call manager. Rule: if you miss a call from a number and the SAME number calls again soon,
 * SAHIB answers the second call, tells the caller it is an AI assistant, listens, talks naturally,
 * takes a message, hangs up and saves a summary in the Calls tab.
 *
 * Android does not let apps tap into call audio directly, so SAHIB uses the speakerphone:
 * it speaks through the speaker and listens through the microphone. Quality depends on the phone.
 */
class CallAssistant(private val svc: AuraService) {
    private val h = Handler(Looper.getMainLooper())
    private var ringing = false
    private var ringNumber = ""
    private var offhook = false
    private var pending: Runnable? = null
    private var job: Job? = null

    @Volatile var active = false

    private fun digits(n: String): String = n.filter { it.isDigit() }.takeLast(10)

    fun onPhoneState(state: String, number: String?) {
        if (!number.isNullOrBlank()) ringNumber = number
        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                if (!ringing) { ringing = true; offhook = false }
                scheduleAutoAnswer()
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                offhook = true
                cancelPending()
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                if (ringing && !offhook && digits(ringNumber).isNotEmpty()) {
                    Memory.get(svc).markMissed(digits(ringNumber))
                }
                active = false
                ringing = false
                offhook = false
                ringNumber = ""
                cancelPending()
            }
        }
    }

    private fun cancelPending() {
        pending?.let { h.removeCallbacks(it) }
        pending = null
    }

    private fun scheduleAutoAnswer() {
        if (!Prefs.callAuto(svc) || active || pending != null) return
        val n = digits(ringNumber)
        if (n.isEmpty()) return
        val windowMs = Prefs.getInt(svc, "callWindowMin", 30) * 60_000L
        if (!Memory.get(svc).wasMissedRecently(n, windowMs)) return
        val delaySec = Prefs.getInt(svc, "callDelaySec", 3)
        val r = Runnable { pending = null; answerNow(n) }
        pending = r
        h.postDelayed(r, delaySec * 1000L)
    }

    private fun answerNow(n: String) {
        if (!ringing || offhook) return
        if (svc.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            svc.overlay.say("کال اٹھانے کی اجازت نہیں ہے۔ SAHIB ایپ کی سیٹنگ میں اجازتیں دیں۔")
            return
        }
        val tm = svc.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        try { tm.acceptRingingCall() } catch (e: Exception) { return }
        active = true
        Memory.get(svc).clearMissed(n)
        job = svc.scope.launch { session(n) }
    }

    /* ---------------- the conversation ---------------- */

    @Suppress("DEPRECATION")
    private suspend fun session(n: String) {
        val owner = Prefs.owner(svc)
        val brief = Prefs.brief(svc)
        val name = nameOf(ringNumber.ifEmpty { n })
        val audio = svc.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try { svc.startForegroundService(Intent(svc, CallService::class.java)) } catch (e: Exception) {}

        var waited = 0
        while (!offhook && waited < 40) { delay(100); waited++ }
        delay(500)
        try {
            audio.isSpeakerphoneOn = true
            audio.setStreamVolume(AudioManager.STREAM_VOICE_CALL, audio.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0)
        } catch (e: Exception) {}

        val transcript = StringBuilder()
        var summary = ""
        var callerName = name
        try {
            val who = if (owner.isBlank()) "اس نمبر کے مالک" else owner
            val greet = "السلام علیکم! میں $who کا اے آئی اسسٹنٹ، صاحب بول رہا ہوں۔ وہ ابھی کال نہیں لے سکتے۔ آپ بتائیں، میں ان کے لیے آپ کا پیغام لکھ لیتا ہوں۔"
            Speaker.speak(svc, greet, true)
            transcript.append("SAHIB: ").append(greet).append('\n')

            var silent = 0
            for (turn in 1..8) {
                if (!active) break
                val wav = Mic.listen(14_000, 7_000) { active }
                if (!active) break
                if (wav == null) {
                    silent++
                    if (silent >= 2) {
                        Speaker.speak(svc, "ٹھیک ہے، میں آپ کی کال کا ذکر کر دوں گا۔ خدا حافظ۔", true)
                        break
                    }
                    Speaker.speak(svc, "جی، مجھے آپ کی آواز نہیں آئی۔ آپ بتائیں، میں سن رہا ہوں۔", true)
                    continue
                }
                silent = 0
                val r = withContext(Dispatchers.IO) {
                    AiClient.callTurn(svc, wav, owner, brief, transcript.toString(), callerName)
                }
                val said = r.optString("transcript")
                val reply = r.optString("reply")
                if (said.isNotBlank()) transcript.append("کالر: ").append(said).append('\n')
                if (r.optString("summary").isNotBlank()) summary = r.optString("summary")
                if (r.optString("caller_name").isNotBlank()) callerName = r.optString("caller_name")
                if (reply.isNotBlank()) {
                    transcript.append("SAHIB: ").append(reply).append('\n')
                    Speaker.speak(svc, reply, true)
                }
                if (r.optBoolean("end_call", false)) break
            }
        } catch (e: Exception) {
            transcript.append("(خرابی: ").append(e.message).append(")\n")
        } finally {
            val still = active
            active = false
            if (still) {
                try {
                    val tm = svc.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                    tm.endCall()
                } catch (e: Exception) {}
            }
            try { audio.isSpeakerphoneOn = false } catch (e: Exception) {}
            try { svc.stopService(Intent(svc, CallService::class.java)) } catch (e: Exception) {}

            val num = ringNumber.ifEmpty { n }
            val title = if (callerName.isNotBlank()) callerName else num
            val sum = if (summary.isBlank()) "پیغام نہیں ملا" else summary
            Memory.get(svc).addCall(num, callerName, sum, transcript.toString())
            notifyOwner("📞 $title", sum)
        }
    }

    private fun notifyOwner(title: String, text: String) {
        svc.overlay.say("$title: $text")
        try {
            val nm = svc.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("aura_msg", "SAHIB Messages", NotificationManager.IMPORTANCE_HIGH))
            val n = android.app.Notification.Builder(svc, "aura_msg")
                .setContentTitle(title).setContentText(text)
                .setStyle(android.app.Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.ic_menu_call).build()
            nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
        } catch (e: Exception) {}
    }

    private fun nameOf(number: String): String {
        if (number.isBlank() || svc.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return ""
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            val c = svc.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            var r = ""
            if (c != null) { if (c.moveToFirst()) r = c.getString(0) ?: ""; c.close() }
            r
        } catch (e: Exception) { "" }
    }
}
