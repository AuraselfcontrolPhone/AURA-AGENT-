package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SinaDao {
    // Smart Home Buttons
    @Query("SELECT * FROM smart_buttons ORDER BY roomSection ASC, sortOrder ASC, id ASC")
    fun observeButtons(): Flow<List<SmartButtonEntity>>

    @Query("SELECT * FROM smart_buttons ORDER BY roomSection ASC, sortOrder ASC, id ASC")
    suspend fun getAllButtonsSync(): List<SmartButtonEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertButton(button: SmartButtonEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertButtons(buttons: List<SmartButtonEntity>)

    @Update
    suspend fun updateButton(button: SmartButtonEntity)

    @Delete
    suspend fun deleteButton(button: SmartButtonEntity)

    @Query("SELECT COUNT(*) FROM smart_buttons")
    suspend fun getButtonCount(): Int

    // Device & Visual Memory ("جو چیز ایک بار دیکھ لی وہ یاد رکھے")
    @Query("SELECT * FROM device_memories ORDER BY updatedAt DESC LIMIT 250")
    fun observeMemories(): Flow<List<DeviceMemoryEntity>>

    @Query("SELECT * FROM device_memories ORDER BY hitCount DESC, updatedAt DESC LIMIT 120")
    suspend fun getTopMemoriesSync(): List<DeviceMemoryEntity>

    @Query("SELECT * FROM device_memories WHERE memoryKey = :key LIMIT 1")
    suspend fun getMemoryByKey(key: String): DeviceMemoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMemory(memory: DeviceMemoryEntity)

    @Query("DELETE FROM device_memories WHERE memoryType = :type")
    suspend fun clearMemoriesByType(type: String)

    // Command Reports
    @Query("SELECT * FROM command_reports ORDER BY timestamp DESC LIMIT 50")
    fun observeReports(): Flow<List<CommandReportEntity>>

    @Insert
    suspend fun insertReport(report: CommandReportEntity)

    @Query("DELETE FROM command_reports")
    suspend fun clearReports()

    // Call Guard Records (2nd-ring auto answer)
    @Query("SELECT * FROM call_records ORDER BY timestamp DESC LIMIT 50")
    fun observeCallRecords(): Flow<List<CallRecordEntity>>

    @Query("SELECT * FROM call_records WHERE phoneNumber = :number ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestCallForNumber(number: String): CallRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCallRecord(record: CallRecordEntity): Long

    @Update
    suspend fun updateCallRecord(record: CallRecordEntity)

    // Q&A Messages
    @Query("SELECT * FROM qa_messages ORDER BY timestamp ASC")
    fun observeQaMessages(): Flow<List<QaMessageEntity>>

    @Insert
    suspend fun insertQaMessage(message: QaMessageEntity): Long

    @Query("DELETE FROM qa_messages")
    suspend fun clearQaMessages()
}
