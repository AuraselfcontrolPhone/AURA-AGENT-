package com.aura.agent

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlin.concurrent.thread

/**
 * Reads WhatsApp message notifications (needs "Notification access"), remembers them,
 * and can send a suitable automatic reply through the notification's own reply button.
 * Works while the screen is off.
 */
class NotifListener : NotificationListenerService() {
    private val lastReply = HashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg != "com.whatsapp" && pkg != "com.whatsapp.w4b") return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras
        if (ex.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)) return
        val title = ex.getString(Notification.EXTRA_TITLE) ?: return
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        if (text.contains("new messages", true) || text.contains("نئے میسج")) return

        val mem = Memory.get(this)
        mem.addMessage(title, text)
        if (!Prefs.autoReply(this)) return

        val quick = mem.matchQuick(text)                                  // your own words -> your own reply, offline
        val gap = if (quick != null) 8_000L else 30 * 60_000L             // default reply: once per person per 30 min
        val now = System.currentTimeMillis()
        if (now - (lastReply[title] ?: 0L) < gap) return
        lastReply[title] = now
        thread { send(n, quick ?: chooseReply(text)) }
    }

    /** Offline: a suitable canned reply. Online (and allowed): a short AI-written reply. */
    private fun chooseReply(incoming: String): String {
        val base = Prefs.autoReplyText(this)
        val low = Fuzzy.norm(incoming)
        if (Prefs.getBool(this, "autoReplyAI", false) && Net.aiOk(this)) {
            try {
                val r = AiClient.ask(this, "Write ONE short, polite WhatsApp reply (same language as the message) saying I am busy and will reply soon. Message: \"$incoming\"", "", emptyList())
                if (r.isNotBlank()) return r.take(200) + " (سینا کا خودکار جواب)"
            } catch (e: Exception) {}
        }
        if (low.contains("سلام")) return "وعلیکم السلام! " + base
        if (low.contains("کہاں") || low.contains("کب") || low.contains("کیا") || incoming.contains("?") || incoming.contains("؟")) return "آپ کا پیغام مل گیا۔ " + base
        return base
    }

    private fun send(n: Notification, reply: String) {
        val actions = n.actions ?: return
        for (a in actions) {
            val inputs = a.remoteInputs ?: continue
            val intent = Intent()
            val bundle = Bundle()
            for (r in inputs) bundle.putCharSequence(r.resultKey, reply)
            RemoteInput.addResultsToIntent(inputs, intent, bundle)
            try { a.actionIntent.send(this, 0, intent); return } catch (e: Exception) {}
        }
    }
}
