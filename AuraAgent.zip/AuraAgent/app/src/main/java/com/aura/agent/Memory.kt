package com.aura.agent

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray

/**
 * SINA's memory:
 *  - recipes: exact step lists that worked (replayed instantly, no AI call)
 *  - elements: which buttons are used per app
 *  - notes: facts the AI chose to remember about an app
 *  - orders: history of every command
 */
class Memory private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "aura_mem.db", null, 6) {

    class Order(val id: Long, val text: String, val ts: Long, val status: String, val ms: Long, val fast: Boolean)
    class Call(val id: Long, val number: String, val name: String, val ts: Long, val summary: String, val transcript: String)
    class Quick(val id: Long, val keywords: String, val reply: String)
    class Section(val id: Long, val name: String)
    class Device(val id: Long, val section: Long, val name: String, val onUrl: String, val offUrl: String, val state: Int)
    class Sched(val id: Long, val goal: String, val hour: Int, val min: Int, val daily: Boolean)

    companion object {
        @Volatile private var inst: Memory? = null
        fun get(ctx: Context): Memory =
            inst ?: synchronized(this) { inst ?: Memory(ctx.applicationContext).also { inst = it } }

        private fun norm(s: String) =
            s.lowercase().replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").replace(Regex("\\s+"), " ").trim()
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS recipes(goal TEXT PRIMARY KEY, steps TEXT, uses INTEGER, ts INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS elements(pkg TEXT, label TEXT, uses INTEGER, PRIMARY KEY(pkg,label))")
        db.execSQL("CREATE TABLE IF NOT EXISTS notes(pkg TEXT, note TEXT, ts INTEGER, PRIMARY KEY(pkg,note))")
        db.execSQL("CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT, ts INTEGER, status TEXT, ms INTEGER, steps INTEGER, fast INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS calls(id INTEGER PRIMARY KEY AUTOINCREMENT, number TEXT, name TEXT, ts INTEGER, summary TEXT, transcript TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS missed(number TEXT PRIMARY KEY, ts INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS sections(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, ord INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS devices(id INTEGER PRIMARY KEY AUTOINCREMENT, section INTEGER, name TEXT, on_url TEXT, off_url TEXT, state INTEGER, ord INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS apps(pkg TEXT PRIMARY KEY, label TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS phone_map(area TEXT PRIMARY KEY, labels TEXT, ts INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, sender TEXT, text TEXT, ts INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS qa(q TEXT PRIMARY KEY, a TEXT, ts INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS quick(id INTEGER PRIMARY KEY AUTOINCREMENT, keywords TEXT, reply TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS kb(id INTEGER PRIMARY KEY AUTOINCREMENT, chunk TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS schedules(id INTEGER PRIMARY KEY AUTOINCREMENT, goal TEXT, hour INTEGER, min INTEGER, daily INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        onCreate(db)   // only adds missing tables, keeps your devices, orders and memory
    }

    /* ---------- recipes ---------- */

    fun saveRecipe(goal: String, stepsJson: String) {
        val key = norm(goal)
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO recipes VALUES(?,?,COALESCE((SELECT uses FROM recipes WHERE goal=?),0)+1,?)",
            arrayOf<Any?>(key, stepsJson, key, System.currentTimeMillis())
        )
    }

    fun findRecipeJson(goal: String): String? {
        readableDatabase.rawQuery("SELECT steps FROM recipes WHERE goal=?", arrayOf(norm(goal))).use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }

    fun deleteRecipe(goal: String) {
        writableDatabase.execSQL("DELETE FROM recipes WHERE goal=?", arrayOf<Any?>(norm(goal)))
    }

    fun recipeCount(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM recipes", null).use { return if (it.moveToFirst()) it.getInt(0) else 0 }
    }

    private fun lines(json: String): String {
        val a = JSONArray(json)
        val sb = StringBuilder()
        for (i in 0 until a.length()) {
            val s = a.getJSONObject(i)
            sb.append(i + 1).append(". ").append(s.getString("t")).append(' ')
                .append(s.optString("label").ifEmpty { s.optString("v") }).append('\n')
        }
        return sb.toString().trim()
    }

    /** A similar (not identical) earlier goal, as readable steps, to give the AI a head start. */
    fun nearRecipe(goal: String): String? {
        val a = norm(goal).split(" ").toSet()
        var best: String? = null
        var bestScore = 0.0
        readableDatabase.rawQuery("SELECT goal, steps FROM recipes", null).use {
            while (it.moveToNext()) {
                val b = it.getString(0).split(" ").toSet()
                if (b == a) continue
                val score = a.intersect(b).size.toDouble() / a.union(b).size.coerceAtLeast(1)
                if (score > bestScore) { bestScore = score; best = it.getString(1) }
            }
        }
        val s = best
        return if (bestScore >= 0.6 && s != null) lines(s) else null
    }

    /* ---------- elements & notes ---------- */

    fun bumpElement(pkg: String, label: String) {
        if (label.isBlank()) return
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO elements VALUES(?,?,COALESCE((SELECT uses FROM elements WHERE pkg=? AND label=?),0)+1)",
            arrayOf<Any?>(pkg, label, pkg, label)
        )
    }

    fun hints(pkg: String): String {
        val sb = StringBuilder()
        readableDatabase.rawQuery(
            "SELECT label FROM elements WHERE pkg=? ORDER BY uses DESC LIMIT 12", arrayOf(pkg)
        ).use { while (it.moveToNext()) sb.append("\"").append(it.getString(0)).append("\" ") }
        return sb.toString().trim()
    }

    fun addNote(pkg: String, note: String) {
        if (note.isBlank()) return
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO notes VALUES(?,?,?)", arrayOf<Any?>(pkg, note.take(200), System.currentTimeMillis())
        )
    }

    fun notes(pkg: String): String {
        val sb = StringBuilder()
        readableDatabase.rawQuery(
            "SELECT note FROM notes WHERE pkg=? ORDER BY ts DESC LIMIT 8", arrayOf(pkg)
        ).use { while (it.moveToNext()) sb.append("- ").append(it.getString(0)).append('\n') }
        return sb.toString().trim()
    }

    /* ---------- orders ---------- */

    fun addOrder(text: String): Long {
        val db = writableDatabase
        db.execSQL("INSERT INTO orders(text,ts,status,ms,steps,fast) VALUES(?,?,?,?,?,?)",
            arrayOf<Any?>(text, System.currentTimeMillis(), "run", 0, 0, 0))
        db.rawQuery("SELECT last_insert_rowid()", null).use { return if (it.moveToFirst()) it.getLong(0) else 0L }
    }

    fun finishOrder(id: Long, status: String, ms: Long, steps: Int, fast: Boolean) {
        writableDatabase.execSQL("UPDATE orders SET status=?, ms=?, steps=?, fast=? WHERE id=?",
            arrayOf<Any?>(status, ms, steps, if (fast) 1 else 0, id))
    }

    fun recentOrders(limit: Int): List<Order> {
        val out = ArrayList<Order>()
        readableDatabase.rawQuery(
            "SELECT id,text,ts,status,ms,fast FROM orders ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())
        ).use {
            while (it.moveToNext()) out.add(Order(it.getLong(0), it.getString(1), it.getLong(2), it.getString(3), it.getLong(4), it.getInt(5) == 1))
        }
        return out
    }

    /* ---------- calls ---------- */

    fun markMissed(number: String) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO missed VALUES(?,?)", arrayOf<Any?>(number, System.currentTimeMillis()))
    }

    fun clearMissed(number: String) {
        writableDatabase.execSQL("DELETE FROM missed WHERE number=?", arrayOf<Any?>(number))
    }

    fun wasMissedRecently(number: String, windowMs: Long): Boolean {
        readableDatabase.rawQuery("SELECT ts FROM missed WHERE number=?", arrayOf(number)).use {
            return it.moveToFirst() && System.currentTimeMillis() - it.getLong(0) <= windowMs
        }
    }

    fun addCall(number: String, name: String, summary: String, transcript: String) {
        writableDatabase.execSQL("INSERT INTO calls(number,name,ts,summary,transcript) VALUES(?,?,?,?,?)",
            arrayOf<Any?>(number, name, System.currentTimeMillis(), summary, transcript))
    }

    fun recentCalls(limit: Int): List<Call> {
        val out = ArrayList<Call>()
        readableDatabase.rawQuery("SELECT id,number,name,ts,summary,transcript FROM calls ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())).use {
            while (it.moveToNext()) out.add(Call(it.getLong(0), it.getString(1), it.getString(2), it.getLong(3), it.getString(4), it.getString(5)))
        }
        return out
    }

    /* ---------- schedules ---------- */

    fun addSchedule(goal: String, hour: Int, min: Int, daily: Boolean): Sched {
        val db = writableDatabase
        db.execSQL("INSERT INTO schedules(goal,hour,min,daily) VALUES(?,?,?,?)", arrayOf<Any?>(goal, hour, min, if (daily) 1 else 0))
        db.rawQuery("SELECT last_insert_rowid()", null).use {
            val id = if (it.moveToFirst()) it.getLong(0) else 0L
            return Sched(id, goal, hour, min, daily)
        }
    }

    fun schedules(): List<Sched> {
        val out = ArrayList<Sched>()
        readableDatabase.rawQuery("SELECT id,goal,hour,min,daily FROM schedules ORDER BY hour,min", null).use {
            while (it.moveToNext()) out.add(Sched(it.getLong(0), it.getString(1), it.getInt(2), it.getInt(3), it.getInt(4) == 1))
        }
        return out
    }

    fun schedule(id: Long): Sched? {
        readableDatabase.rawQuery("SELECT id,goal,hour,min,daily FROM schedules WHERE id=?", arrayOf(id.toString())).use {
            return if (it.moveToFirst()) Sched(it.getLong(0), it.getString(1), it.getInt(2), it.getInt(3), it.getInt(4) == 1) else null
        }
    }

    fun deleteSchedule(id: Long) {
        writableDatabase.execSQL("DELETE FROM schedules WHERE id=?", arrayOf<Any?>(id))
    }

    /* ---------- home automation: sections + devices (each device has an ON url and an OFF url) ---------- */

    fun sections(): List<Section> {
        val out = ArrayList<Section>()
        readableDatabase.rawQuery("SELECT id,name FROM sections ORDER BY ord,id", null).use {
            while (it.moveToNext()) out.add(Section(it.getLong(0), it.getString(1)))
        }
        return out
    }

    fun addSection(name: String): Long {
        val db = writableDatabase
        db.execSQL("INSERT INTO sections(name,ord) VALUES(?,?)", arrayOf<Any?>(name, System.currentTimeMillis() / 1000))
        db.rawQuery("SELECT last_insert_rowid()", null).use { return if (it.moveToFirst()) it.getLong(0) else 0L }
    }

    fun renameSection(id: Long, name: String) {
        writableDatabase.execSQL("UPDATE sections SET name=? WHERE id=?", arrayOf<Any?>(name, id))
    }

    fun deleteSection(id: Long) {
        val db = writableDatabase
        db.execSQL("DELETE FROM devices WHERE section=?", arrayOf<Any?>(id))
        db.execSQL("DELETE FROM sections WHERE id=?", arrayOf<Any?>(id))
    }

    fun devices(section: Long): List<Device> {
        val out = ArrayList<Device>()
        readableDatabase.rawQuery("SELECT id,section,name,on_url,off_url,state FROM devices WHERE section=? ORDER BY ord,id", arrayOf(section.toString())).use {
            while (it.moveToNext()) out.add(Device(it.getLong(0), it.getLong(1), it.getString(2), it.getString(3) ?: "", it.getString(4) ?: "", it.getInt(5)))
        }
        return out
    }

    fun allDevices(): List<Device> {
        val out = ArrayList<Device>()
        readableDatabase.rawQuery("SELECT id,section,name,on_url,off_url,state FROM devices ORDER BY id", null).use {
            while (it.moveToNext()) out.add(Device(it.getLong(0), it.getLong(1), it.getString(2), it.getString(3) ?: "", it.getString(4) ?: "", it.getInt(5)))
        }
        return out
    }

    fun addDevice(section: Long, name: String, onUrl: String, offUrl: String): Long {
        val db = writableDatabase
        db.execSQL("INSERT INTO devices(section,name,on_url,off_url,state,ord) VALUES(?,?,?,?,0,?)",
            arrayOf<Any?>(section, name, onUrl, offUrl, System.currentTimeMillis() / 1000))
        db.rawQuery("SELECT last_insert_rowid()", null).use { return if (it.moveToFirst()) it.getLong(0) else 0L }
    }

    fun updateDevice(id: Long, name: String, onUrl: String, offUrl: String) {
        writableDatabase.execSQL("UPDATE devices SET name=?, on_url=?, off_url=? WHERE id=?", arrayOf<Any?>(name, onUrl, offUrl, id))
    }

    fun setDeviceState(id: Long, state: Int) {
        writableDatabase.execSQL("UPDATE devices SET state=? WHERE id=?", arrayOf<Any?>(state, id))
    }

    fun deleteDevice(id: Long) {
        writableDatabase.execSQL("DELETE FROM devices WHERE id=?", arrayOf<Any?>(id))
    }

    fun seedDefaultsIfEmpty() {
        if (sections().isNotEmpty()) return
        val s1 = addSection("لائٹس")
        addDevice(s1, "کمرے کی لائٹ", "", "")
        addDevice(s1, "صحن کی لائٹ", "", "")
        val s2 = addSection("پنکھے اور ایپلائنسز")
        addDevice(s2, "پنکھا", "", "")
        val s3 = addSection("گیٹ اور سیکیورٹی")
        addDevice(s3, "گیٹ", "", "")
    }

    /* ---------- the phone study: installed apps + what is where ---------- */

    fun replaceApps(apps: List<Pair<String, String>>) {
        val db = writableDatabase
        db.execSQL("DELETE FROM apps")
        apps.forEach { db.execSQL("INSERT OR REPLACE INTO apps VALUES(?,?)", arrayOf<Any?>(it.first, it.second)) }
    }

    fun appCount(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM apps", null).use { return if (it.moveToFirst()) it.getInt(0) else 0 }
    }

    fun appLabels(limit: Int): String {
        val sb = StringBuilder()
        readableDatabase.rawQuery("SELECT label FROM apps ORDER BY label LIMIT ?", arrayOf(limit.toString())).use {
            while (it.moveToNext()) sb.append(it.getString(0)).append(", ")
        }
        return sb.toString().trimEnd(',', ' ')
    }

    /** Best matching installed app package for a spoken/typed name. */
    fun findApp(query: String): String? {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return null
        var best: String? = null
        var bestScore = 0
        readableDatabase.rawQuery("SELECT pkg,label FROM apps", null).use {
            while (it.moveToNext()) {
                val l = it.getString(1).lowercase()
                val score = when {
                    l == q -> 100
                    l.startsWith(q) -> 80
                    l.contains(q) -> 60
                    q.contains(l) && l.length >= 3 -> 50
                    it.getString(0).lowercase().contains(q) -> 30
                    else -> 0
                }
                if (score > bestScore) { bestScore = score; best = it.getString(0) }
            }
        }
        return best
    }

    fun saveMap(area: String, labels: String) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO phone_map VALUES(?,?,?)", arrayOf<Any?>(area, labels, System.currentTimeMillis()))
    }

    fun mapText(): String {
        val sb = StringBuilder()
        readableDatabase.rawQuery("SELECT area,labels FROM phone_map", null).use {
            while (it.moveToNext()) sb.append(it.getString(0)).append(": ").append(it.getString(1).take(700)).append('\n')
        }
        return sb.toString().trim()
    }

    /* ---------- offline brain: answers, messages, knowledge, similar orders ---------- */

    fun recipeUses(goal: String): Int {
        readableDatabase.rawQuery("SELECT uses FROM recipes WHERE goal=?", arrayOf(norm(goal))).use { return if (it.moveToFirst()) it.getInt(0) else 0 }
    }

    fun addMessage(sender: String, text: String) {
        val db = writableDatabase
        db.execSQL("INSERT INTO messages(sender,text,ts) VALUES(?,?,?)", arrayOf<Any?>(sender, text.take(300), System.currentTimeMillis()))
        db.execSQL("DELETE FROM messages WHERE id < (SELECT MAX(id) FROM messages) - 200")
    }

    fun recentMessages(limit: Int): List<Triple<String, String, Long>> {
        val out = ArrayList<Triple<String, String, Long>>()
        readableDatabase.rawQuery("SELECT sender,text,ts FROM messages ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())).use {
            while (it.moveToNext()) out.add(Triple(it.getString(0), it.getString(1), it.getLong(2)))
        }
        return out
    }

    fun cacheAnswer(q: String, a: String) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO qa VALUES(?,?,?)", arrayOf<Any?>(Fuzzy.norm(q), a, System.currentTimeMillis()))
    }

    /** Same or very similar question asked before -> the stored answer, no internet needed. */
    fun cachedAnswer(q: String): String? {
        val nq = Fuzzy.norm(q)
        var best: String? = null
        var bestScore = 0.0
        readableDatabase.rawQuery("SELECT q,a FROM qa", null).use {
            while (it.moveToNext()) {
                val sc = if (it.getString(0) == nq) 1.0 else Fuzzy.similarity(nq, it.getString(0))
                if (sc > bestScore) { bestScore = sc; best = it.getString(1) }
            }
        }
        return if (bestScore >= 0.8) best else null
    }

    fun kbClear() { writableDatabase.execSQL("DELETE FROM kb") }
    fun kbAdd(chunk: String) { writableDatabase.execSQL("INSERT INTO kb(chunk) VALUES(?)", arrayOf<Any?>(chunk)) }
    fun kbAll(): List<String> {
        val out = ArrayList<String>()
        readableDatabase.rawQuery("SELECT chunk FROM kb", null).use { while (it.moveToNext()) out.add(it.getString(0)) }
        return out
    }

    /** A past successful order that is similar to a (maybe broken) sentence. */
    fun bestOrder(text: String): String? {
        var best: String? = null
        var bestScore = 0.0
        for (o in recentOrders(300)) {
            if (o.status != "ok") continue
            val sc = Fuzzy.similarity(text, o.text)
            if (sc > bestScore) { bestScore = sc; best = o.text }
        }
        return if (bestScore >= 0.6) best else null
    }

    fun device(id: Long): Device? {
        readableDatabase.rawQuery("SELECT id,section,name,on_url,off_url,state FROM devices WHERE id=?", arrayOf(id.toString())).use {
            return if (it.moveToFirst()) Device(it.getLong(0), it.getLong(1), it.getString(2), it.getString(3) ?: "", it.getString(4) ?: "", it.getInt(5)) else null
        }
    }

    fun deviceSchedules(deviceId: Long): List<Sched> = schedules().filter { it.goal.startsWith("DEV:$deviceId:") }

    fun ruleLabel(s: Sched): String {
        if (s.goal.startsWith("DEV:")) {
            val p = s.goal.split(":")
            val d = p.getOrNull(1)?.toLongOrNull()?.let { device(it) }
            return (d?.name ?: "بٹن") + (if (p.getOrNull(2) == "1") " ON" else " OFF")
        }
        return s.goal
    }

    /* ---------- quick messages: your own words -> your own reply (offline) ---------- */

    fun quicks(): List<Quick> {
        val out = ArrayList<Quick>()
        readableDatabase.rawQuery("SELECT id,keywords,reply FROM quick ORDER BY id", null).use {
            while (it.moveToNext()) out.add(Quick(it.getLong(0), it.getString(1), it.getString(2)))
        }
        return out
    }

    fun addQuick(keywords: String, reply: String) {
        writableDatabase.execSQL("INSERT INTO quick(keywords,reply) VALUES(?,?)", arrayOf<Any?>(keywords, reply))
    }

    fun updateQuick(id: Long, keywords: String, reply: String) {
        writableDatabase.execSQL("UPDATE quick SET keywords=?, reply=? WHERE id=?", arrayOf<Any?>(keywords, reply, id))
    }

    fun deleteQuick(id: Long) {
        writableDatabase.execSQL("DELETE FROM quick WHERE id=?", arrayOf<Any?>(id))
    }

    /** The reply of the quick message whose words appear (even badly spelt) in the incoming text. */
    fun matchQuick(text: String): String? {
        val words = Fuzzy.tokens(text)
        var best: String? = null
        var bestScore = 0
        for (q in quicks()) {
            for (kw in q.keywords.split(",", "،", "\n")) {
                val kt = Fuzzy.tokens(kw)
                if (kt.isEmpty()) continue
                if (kt.all { Fuzzy.tokenMatch(it, words) } && kt.size > bestScore) { bestScore = kt.size; best = q.reply }
            }
        }
        return best
    }
}
