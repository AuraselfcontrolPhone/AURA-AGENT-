package com.aura.agent

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume

/** A window root that handles the BACK key itself (first back hides the keyboard, second closes). */
private class KeyRoot(c: Context, val onBack: () -> Unit) : LinearLayout(c) {
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) onBack()
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}

/**
 * The whole interface, drawn over every app (ghost mode = invisible until touched):
 *  - orb at the bottom: tap / swipe up = chat, HOLD = record a voice message (release to send)
 *  - glowing edge on the right: swipe right-to-left = drawer (Orders, Calls, Rules)
 *  - while AURA works: a status pill with 🎙 (speak a correction), ✎ (type a correction) and Stop
 */
class ChatOverlay(
    private val ctx: Context,
    private val onGoal: (String) -> Unit,
    private val onStop: () -> Unit,
    private val onVoice: (File) -> Unit
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    private val ui = Handler(Looper.getMainLooper())
    private val recorder = VoiceRecorder(ctx)
    private val winType = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
    private val nf = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
    private val focusFlag = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

    private class Item(val kind: Int, val text: String) // 0 = you, 1 = AURA, 2 = step

    private val items = ArrayList<Item>()

    private var orbBox: View? = null
    private var orbView: OrbView? = null
    private var edgeV: View? = null
    private var panelV: View? = null
    private var panelInput: EditText? = null
    private var panelH = 0
    private var kbShown = false
    private var ordersV: View? = null
    private var drawerTab = 0
    private var statusV: View? = null
    private var statusTv: TextView? = null
    private var yesB: TextView? = null
    private var noB: TextView? = null
    private var guideV: View? = null
    private var guideInput: EditText? = null
    private var chatList: LinearLayout? = null
    private var chatScroll: ScrollView? = null
    private var recBox: View? = null
    private var wave: WaveView? = null
    private var recHint: TextView? = null
    private var recording = false
    private var running = false

    private val hintHold = "چھوڑیں = بھیجیں   |   بائیں کھینچیں = منسوخ"
    private val hintCancel = "منسوخ ہو جائے گا"

    private val hideStatus = Runnable { remove(statusV); statusV = null; statusTv = null }

    private val ticker: Runnable = object : Runnable {
        override fun run() {
            if (!recording) return
            val l = recorder.level()
            wave?.push(l)
            orbView?.setLevel(l)
            ui.postDelayed(this, 60)
        }
    }

    /* ---------------- helpers ---------------- */

    private fun dp(v: Int): Int = Neo.dp(ctx, v)
    private fun screenW(): Int = ctx.resources.displayMetrics.widthPixels
    private fun screenH(): Int = ctx.resources.displayMetrics.heightPixels
    private fun ghost(): Boolean = Prefs.ghost(ctx)

    private fun lp(w: Int, h: Int, flags: Int, gravity: Int, y: Int): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(w, h, winType, flags, PixelFormat.TRANSLUCENT)
        p.gravity = gravity
        p.y = y
        return p
    }

    private fun add(v: View, p: WindowManager.LayoutParams) { try { wm.addView(v, p) } catch (e: Exception) {} }
    private fun remove(v: View?) { if (v != null) { try { wm.removeView(v) } catch (e: Exception) {} } }

    private fun tv(t: String, size: Float, color: Int): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        return v
    }

    private fun circleBtn(label: String, fill: Int, sizeDp: Int): TextView {
        val v = tv(label, 18f, Color.WHITE)
        v.gravity = Gravity.CENTER
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        d.setColor(fill)
        v.background = d
        v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return v
    }

    private fun hideKeyboardOf(e: EditText?) {
        if (e != null) {
            try { imm.hideSoftInputFromWindow(e.windowToken, 0) } catch (x: Exception) {}
            e.clearFocus()
        }
        kbShown = false
    }

    /* ---------------- idle UI: orb + edge ---------------- */

    fun showIdle() {
        ui.post {
            if (running || panelV != null) return@post
            if (orbBox == null) {
                val b = buildOrb()
                add(b, lp(dp(76), dp(76), nf, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, dp(48)))
                orbBox = b
            }
            if (edgeV == null) {
                val e = buildEdge()
                add(e, lp(dp(22), (screenH() * 0.36f).toInt(), nf, Gravity.RIGHT or Gravity.CENTER_VERTICAL, 0))
                edgeV = e
            }
        }
    }

    private fun hideIdleNow() {
        remove(orbBox); orbBox = null; orbView = null
        remove(edgeV); edgeV = null
    }

    private fun buildOrb(): View {
        val orb = OrbView(ctx)
        orbView = orb
        val box = FrameLayout(ctx)
        box.addView(orb, FrameLayout.LayoutParams(-1, -1))
        box.alpha = if (ghost()) 0f else 1f
        var downX = 0f
        var downY = 0f
        var holding = false
        var handled = false
        var cancelled = false
        val longPress = Runnable {
            holding = true
            if (!beginRecord(dp(136))) { holding = false; handled = true }
        }
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    holding = false; handled = false; cancelled = false
                    box.animate().alpha(1f).setDuration(120).start()
                    ui.postDelayed(longPress, 380)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (holding) {
                        val c = Math.abs(e.rawX - downX) > dp(90)
                        if (c != cancelled) { cancelled = c; recHint?.text = if (c) hintCancel else hintHold }
                    } else if (!handled && downY - e.rawY > dp(40)) {
                        handled = true
                        ui.removeCallbacks(longPress)
                        showPanel()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    ui.removeCallbacks(longPress)
                    if (ghost()) box.animate().alpha(0f).setDuration(600).start()
                    if (holding) {
                        endRecord(!cancelled)
                    } else if (!handled && Math.abs(e.rawY - downY) < dp(10) && Math.abs(e.rawX - downX) < dp(10)) {
                        showPanel()
                    }
                }
            }
            true
        }
        return box
    }

    private fun buildEdge(): View {
        val line = View(ctx)
        line.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0, Neo.cyan, Neo.gold, 0))
        val box = FrameLayout(ctx)
        box.addView(line, FrameLayout.LayoutParams(dp(3), -1, Gravity.RIGHT))
        box.alpha = if (ghost()) 0f else 1f
        var downX = 0f
        var opened = false
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; opened = false
                    box.animate().alpha(1f).setDuration(120).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!opened && downX - e.rawX > dp(46)) { opened = true; showOrders() }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (ghost()) box.animate().alpha(0f).setDuration(600).start()
                }
            }
            true
        }
        return box
    }

    /* ---------------- voice recording ---------------- */

    private fun beginRecord(yOff: Int): Boolean {
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            say("مائیک کی اجازت نہیں ہے۔ AURA ایپ کھول کر 'اجازتیں دیں' دبائیں۔")
            return false
        }
        if (!recorder.start()) { say("مائیک شروع نہیں ہوا"); return false }
        recording = true
        orbView?.setState(OrbView.State.LISTEN)
        showRecBar(yOff)
        ui.post(ticker)
        return true
    }

    private fun endRecord(send: Boolean) {
        if (!recording) return
        recording = false
        ui.removeCallbacks(ticker)
        remove(recBox); recBox = null; wave = null; recHint = null
        orbView?.setState(OrbView.State.IDLE)
        orbView?.setLevel(0f)
        val f = recorder.stop()
        if (!send || f == null || f.length() < 3000) { f?.delete(); return }
        onVoice(f)
    }

    private fun showRecBar(yOff: Int) {
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.HORIZONTAL
        root.gravity = Gravity.CENTER_VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.background = Neo.panel(ctx, 24, 24)
        root.setPadding(dp(14), dp(8), dp(14), dp(8))
        val dot = View(ctx)
        val dd = GradientDrawable()
        dd.shape = GradientDrawable.OVAL
        dd.setColor(Neo.red)
        dot.background = dd
        root.addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)))
        val w = WaveView(ctx)
        val wp = LinearLayout.LayoutParams(dp(150), dp(30))
        wp.setMargins(dp(10), 0, dp(10), 0)
        root.addView(w, wp)
        val h = tv(hintHold, 11f, Neo.dim)
        root.addView(h)
        wave = w
        recHint = h
        add(root, lp(-2, -2, nf or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, yOff))
        recBox = root
    }

    /* ---------------- chat panel ---------------- */

    fun showPanel() {
        ui.post {
            if (panelV != null || running) return@post
            hideIdleNow()
            hideOrdersNow()
            panelH = (screenH() * 0.62f).toInt()
            val root = buildPanel()
            val p = lp(-1, panelH, focusFlag, Gravity.BOTTOM, 0)
            p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            add(root, p)
            panelV = root
            root.translationY = panelH.toFloat()
            root.animate().translationY(0f).setDuration(220).start()
            chatScroll?.post { chatScroll?.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun hidePanelNow() {
        if (recording) endRecord(false)
        hideKeyboardOf(panelInput)
        remove(panelV)
        panelV = null; panelInput = null; chatList = null; chatScroll = null
    }

    private fun closePanel() {
        hidePanelNow()
        showIdle()
    }

    private fun sendText(t: String) {
        val s = t.trim()
        if (s.isEmpty()) return
        addUser(s)
        closePanel()
        onGoal(s)
    }

    private fun buildPanel(): View {
        val root = KeyRoot(ctx) { if (kbShown) hideKeyboardOf(panelInput) else closePanel() }
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.background = Neo.panel(ctx, 28)
        root.setPadding(dp(16), dp(12), dp(16), dp(12))
        root.addOnLayoutChangeListener { _, _, top, _, bottom, _, _, _, _ ->
            kbShown = (bottom - top) < panelH * 0.85f
        }

        // header
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(OrbView(ctx), LinearLayout.LayoutParams(dp(46), dp(46)))
        val titles = LinearLayout(ctx)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(10), 0, dp(10), 0)
        val t1 = tv("AURA", 20f, Neo.goldHi)
        t1.typeface = Typeface.DEFAULT_BOLD
        t1.letterSpacing = 0.15f
        val t2 = tv("AI AGENT · " + Prefs.model(ctx), 10f, Neo.cyan)
        t2.typeface = Typeface.MONOSPACE
        titles.addView(t1)
        titles.addView(t2)
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        val drawerBtn = tv("☰", 20f, Neo.goldHi)
        drawerBtn.setPadding(dp(12), dp(2), dp(12), dp(2))
        drawerBtn.background = Neo.pill(ctx, 0, Neo.stroke, 14)
        drawerBtn.setOnClickListener { showOrders() }
        head.addView(drawerBtn)
        val kbBtn = tv("⌨▾", 16f, Neo.cyan)
        kbBtn.setPadding(dp(12), dp(4), dp(8), dp(4))
        kbBtn.setOnClickListener { hideKeyboardOf(panelInput) }
        head.addView(kbBtn)
        val close = tv("✕", 20f, Neo.dim)
        close.setPadding(dp(8), 0, 0, 0)
        close.setOnClickListener { closePanel() }
        head.addView(close)
        root.addView(head)

        val div = View(ctx)
        div.setBackgroundColor(Neo.line)
        val dpm = LinearLayout.LayoutParams(-1, dp(1))
        dpm.setMargins(0, dp(8), 0, dp(6))
        root.addView(div, dpm)

        // chat
        val list = LinearLayout(ctx)
        list.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        sv.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN && kbShown) hideKeyboardOf(panelInput)
            false
        }
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        chatList = list
        chatScroll = sv
        if (items.isEmpty()) items.add(Item(1, "جی استاد! حکم دیں، یا کچھ بھی پوچھیں۔ لکھیں، یا 🎙 دبا کر بولیں۔"))
        items.forEach { list.addView(itemView(it)) }

        // quick chips
        val chipsRow = LinearLayout(ctx)
        chipsRow.orientation = LinearLayout.HORIZONTAL
        listOf("وائی فائی آن کرو", "بلوٹوتھ آن کرو", "ٹارچ آن کرو", "آج کیا تاریخ ہے؟", "مجھے کس کا میسج آیا؟").forEach { c ->
            val chip = tv(c, 12f, Neo.text)
            chip.background = Neo.pill(ctx, 0, Neo.stroke, 14)
            chip.setPadding(dp(12), dp(4), dp(12), dp(4))
            chip.setOnClickListener { sendText(c) }
            val cp = LinearLayout.LayoutParams(-2, -2)
            cp.setMargins(0, 0, dp(8), 0)
            chipsRow.addView(chip, cp)
        }
        val chipsScroll = HorizontalScrollView(ctx)
        chipsScroll.isHorizontalScrollBarEnabled = false
        chipsScroll.addView(chipsRow)
        val csp = LinearLayout.LayoutParams(-1, -2)
        csp.setMargins(0, dp(6), 0, dp(8))
        root.addView(chipsScroll, csp)

        // input row
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val input = EditText(ctx)
        input.hint = "حکم دیں یا سوال پوچھیں..."
        input.setHintTextColor(Neo.dim)
        input.setTextColor(Color.WHITE)
        input.textSize = 15f
        input.setSingleLine(true)
        input.imeOptions = EditorInfo.IME_ACTION_SEND
        input.background = Neo.pill(ctx, Neo.card, Neo.stroke, 24)
        input.setPadding(dp(16), dp(8), dp(16), dp(8))
        input.setOnEditorActionListener { _, _, _ -> sendText(input.text.toString()); true }
        panelInput = input
        val ip = LinearLayout.LayoutParams(0, -2, 1f)
        ip.setMargins(0, 0, dp(8), 0)
        row.addView(input, ip)

        val mic = circleBtn("🎙", Neo.cyan, 46)
        val mp = LinearLayout.LayoutParams(dp(46), dp(46))
        mp.setMargins(0, 0, dp(8), 0)
        var dx0 = 0f
        var cancelled = false
        mic.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx0 = e.rawX; cancelled = false
                    v.parent.requestDisallowInterceptTouchEvent(true)
                    beginRecord(panelH + dp(14))
                }
                MotionEvent.ACTION_MOVE -> {
                    if (recording) {
                        val c = Math.abs(e.rawX - dx0) > dp(90)
                        if (c != cancelled) { cancelled = c; recHint?.text = if (c) hintCancel else hintHold }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (recording) {
                        val send = !cancelled
                        endRecord(send)
                        if (send) closePanel()
                    }
                }
            }
            true
        }
        row.addView(mic, mp)

        val send = circleBtn("➤", Neo.gold, 46)
        send.setOnClickListener { sendText(input.text.toString()) }
        row.addView(send, LinearLayout.LayoutParams(dp(46), dp(46)))
        root.addView(row)
        return root
    }

    private fun itemView(it: Item): View {
        val v = tv(it.text, if (it.kind == 2) 12f else 14f, Color.WHITE)
        val p = LinearLayout.LayoutParams(-2, -2)
        p.setMargins(0, dp(4), 0, dp(4))
        v.maxWidth = (screenW() * 0.78f).toInt()
        when (it.kind) {
            0 -> {
                v.background = Neo.pill(ctx, Neo.gold, 0, 18)
                v.setPadding(dp(14), dp(8), dp(14), dp(8))
                p.gravity = Gravity.START
            }
            1 -> {
                v.background = Neo.pill(ctx, Neo.card, Neo.cyan, 18)
                v.setPadding(dp(14), dp(8), dp(14), dp(8))
                p.gravity = Gravity.END
            }
            else -> {
                v.setTextColor(Neo.cyan)
                v.typeface = Typeface.MONOSPACE
                v.alpha = 0.85f
                p.gravity = Gravity.END
            }
        }
        v.layoutParams = p
        return v
    }

    private fun addItem(item: Item) {
        items.add(item)
        if (items.size > 100) items.removeAt(0)
        val l = chatList
        if (l != null) {
            l.addView(itemView(item))
            chatScroll?.post { chatScroll?.fullScroll(View.FOCUS_DOWN) }
        }
    }

    /* ---------------- drawer: Orders / Calls / Rules ---------------- */

    fun showOrders() {
        ui.post {
            if (ordersV != null) return@post
            val w = (screenW() * 0.86f).toInt()
            val root = buildDrawer()
            add(root, lp(w, -1, nf, Gravity.RIGHT or Gravity.TOP, 0))
            ordersV = root
            root.translationX = w.toFloat()
            root.animate().translationX(0f).setDuration(220).start()
        }
    }

    private fun hideOrdersNow() { remove(ordersV); ordersV = null }

    private fun ago(ts: Long): String {
        val s = (System.currentTimeMillis() - ts) / 1000
        return when {
            s < 60 -> "ابھی"
            s < 3600 -> "${s / 60} منٹ پہلے"
            s < 86400 -> "${s / 3600} گھنٹے پہلے"
            else -> "${s / 86400} دن پہلے"
        }
    }

    private fun buildDrawer(): View {
        val mem = Memory.get(ctx)
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.background = Neo.panelLeft(ctx, 26)
        root.setPadding(dp(16), dp(36), dp(16), dp(24))

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val titles = LinearLayout(ctx)
        titles.orientation = LinearLayout.VERTICAL
        val t = tv("AURA", 22f, Neo.goldHi)
        t.typeface = Typeface.DEFAULT_BOLD
        t.letterSpacing = 0.15f
        titles.addView(t)
        titles.addView(tv("سیکھے ہوئے راستے: ${mem.recipeCount()}  ⚡", 11f, Neo.cyan))
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        val close = tv("✕", 20f, Neo.dim)
        close.setPadding(dp(14), 0, 0, 0)
        close.setOnClickListener { hideOrdersNow() }
        head.addView(close)
        var sx = 0f
        head.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) sx = e.rawX
            if (e.action == MotionEvent.ACTION_MOVE && e.rawX - sx > dp(60)) hideOrdersNow()
            false
        }
        root.addView(head)

        val tabsRow = LinearLayout(ctx)
        tabsRow.orientation = LinearLayout.HORIZONTAL
        val tabViews = ArrayList<TextView>()
        val list = LinearLayout(ctx)
        list.orientation = LinearLayout.VERTICAL

        fun fill() {
            list.removeAllViews()
            for (i in tabViews.indices) {
                val on = i == drawerTab
                tabViews[i].setTextColor(if (on) Color.WHITE else Neo.dim)
                tabViews[i].background = if (on) Neo.pill(ctx, Neo.gold, 0, 14) else Neo.pill(ctx, 0, Neo.stroke, 14)
            }
            when (drawerTab) {
                0 -> fillOrders(list, mem)
                1 -> fillCalls(list, mem)
                else -> fillRules(list, mem) { fill() }
            }
        }

        listOf("آرڈرز", "کالز", "قوانین").forEachIndexed { i, name ->
            val tab = tv(name, 14f, Neo.dim)
            tab.setPadding(dp(14), dp(5), dp(14), dp(5))
            tab.setOnClickListener { drawerTab = i; fill() }
            val tp = LinearLayout.LayoutParams(-2, -2)
            tp.setMargins(0, 0, dp(8), 0)
            tabsRow.addView(tab, tp)
            tabViews.add(tab)
        }
        val trp = LinearLayout.LayoutParams(-1, -2)
        trp.setMargins(0, dp(12), 0, dp(10))
        root.addView(tabsRow, trp)

        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        fill()
        return root
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER_VERTICAL
        c.background = Neo.pill(ctx, Neo.card, 0, 16)
        c.setPadding(dp(12), dp(10), dp(12), dp(10))
        return c
    }

    private fun addCard(list: LinearLayout, c: View) {
        val cp = LinearLayout.LayoutParams(-1, -2)
        cp.setMargins(0, 0, 0, dp(8))
        list.addView(c, cp)
    }

    private fun fillOrders(list: LinearLayout, mem: Memory) {
        val orders = mem.recentOrders(30)
        if (orders.isEmpty()) list.addView(tv("ابھی کوئی آرڈر نہیں۔ نیچے کے بٹن سے پہلا آرڈر دیں۔", 14f, Neo.dim))
        orders.forEach { o ->
            val card = card()
            val bar = View(ctx)
            val col = when (o.status) { "ok" -> Neo.green; "fail" -> Neo.red; "stopped" -> Neo.gold; else -> Neo.cyan }
            bar.setBackgroundColor(col)
            card.addView(bar, LinearLayout.LayoutParams(dp(4), dp(36)))
            val col2 = LinearLayout(ctx)
            col2.orientation = LinearLayout.VERTICAL
            col2.setPadding(dp(10), 0, dp(10), 0)
            val title = tv(o.text, 14f, Color.WHITE)
            title.maxLines = 2
            col2.addView(title)
            val icon = when (o.status) { "ok" -> "✓"; "fail" -> "✗"; "stopped" -> "■"; else -> "…" }
            val sec = String.format("%.1f", o.ms / 1000.0)
            col2.addView(tv("$icon  $sec سیکنڈ  •  ${ago(o.ts)}" + (if (o.fast) "  •  ⚡" else ""), 11f, Neo.dim))
            card.addView(col2, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(tv("▶", 18f, Neo.goldHi))
            card.setOnClickListener {
                hideOrdersNow()
                hidePanelNow()
                addUser(o.text)
                onGoal(o.text)
            }
            addCard(list, card)
        }
    }

    private fun fillCalls(list: LinearLayout, mem: Memory) {
        val calls = mem.recentCalls(25)
        if (calls.isEmpty()) list.addView(tv("ابھی کوئی کال AURA نے نہیں سنبھالی۔ جب ایک ہی نمبر سے دوسری بار کال آئے گی اور آپ پہلی بار نہ اٹھائیں گے تو AURA اٹھا لے گا۔", 13f, Neo.dim))
        calls.forEach { c ->
            val card = LinearLayout(ctx)
            card.orientation = LinearLayout.VERTICAL
            card.background = Neo.pill(ctx, Neo.card, 0, 16)
            card.setPadding(dp(14), dp(10), dp(14), dp(10))
            val who = if (c.name.isNotBlank()) c.name + "  " + c.number else c.number
            card.addView(tv("📞 $who", 14f, Color.WHITE))
            card.addView(tv(c.summary, 13f, Neo.cyan))
            card.addView(tv(ago(c.ts) + "  •  دبائیں: پوری بات", 11f, Neo.dim))
            val full = tv(c.transcript, 12f, Neo.text)
            full.visibility = View.GONE
            card.addView(full)
            card.setOnClickListener { full.visibility = if (full.visibility == View.GONE) View.VISIBLE else View.GONE }
            addCard(list, card)
        }
    }

    private fun fillRules(list: LinearLayout, mem: Memory, refresh: () -> Unit) {
        val rules = mem.schedules()
        if (rules.isEmpty()) list.addView(tv("ابھی کوئی قاعدہ نہیں۔ AURA سے کہیں: \"روز رات 11 بجے ڈیٹا بند کرو\"۔", 13f, Neo.dim))
        rules.forEach { r ->
            val card = card()
            val col2 = LinearLayout(ctx)
            col2.orientation = LinearLayout.VERTICAL
            val time = String.format("%02d:%02d", r.hour, r.min) + (if (r.daily) "  روزانہ" else "  ایک بار")
            col2.addView(tv("⏰ $time", 13f, Neo.cyan))
            val g = tv(r.goal, 14f, Color.WHITE)
            g.maxLines = 2
            col2.addView(g)
            card.addView(col2, LinearLayout.LayoutParams(0, -2, 1f))
            val del = tv("حذف", 13f, Neo.red)
            del.setPadding(dp(10), dp(4), dp(10), dp(4))
            del.setOnClickListener {
                Scheduler.cancel(ctx, r.id)
                mem.deleteSchedule(r.id)
                refresh()
            }
            card.addView(del)
            addCard(list, card)
        }
    }

    /* ---------------- status pill (with live guidance) / confirm ---------------- */

    private fun buildStatus(showControls: Boolean, text: String) {
        ui.removeCallbacks(hideStatus)
        remove(statusV)
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.HORIZONTAL
        root.gravity = Gravity.CENTER_VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.background = Neo.panel(ctx, 22, 22)
        root.setPadding(dp(10), dp(8), dp(10), dp(8))
        val o = OrbView(ctx)
        o.setState(OrbView.State.THINK)
        root.addView(o, LinearLayout.LayoutParams(dp(38), dp(38)))
        val t = tv(text, 13f, Neo.text)
        t.maxLines = 3
        t.setPadding(dp(10), 0, dp(10), 0)
        root.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        val yes = tv("ہاں", 14f, Color.WHITE)
        yes.background = Neo.pill(ctx, Neo.gold, 0, 14)
        yes.setPadding(dp(14), dp(6), dp(14), dp(6))
        yes.visibility = View.GONE
        val no = tv("نہیں", 14f, Neo.text)
        no.background = Neo.pill(ctx, 0, Neo.stroke, 14)
        no.setPadding(dp(14), dp(6), dp(14), dp(6))
        no.visibility = View.GONE
        root.addView(yes)
        root.addView(no)
        if (showControls) {
            // hold-to-talk: correct AURA while it works ("not there, do it like this")
            val mic = circleBtn("🎙", Neo.cyan, 36)
            val mp = LinearLayout.LayoutParams(dp(36), dp(36))
            mp.setMargins(dp(6), 0, 0, 0)
            var dx0 = 0f
            var cancelled = false
            mic.setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        dx0 = e.rawX; cancelled = false
                        v.parent.requestDisallowInterceptTouchEvent(true)
                        beginRecord(dp(206))
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (recording) {
                            val c = Math.abs(e.rawX - dx0) > dp(90)
                            if (c != cancelled) { cancelled = c; recHint?.text = if (c) hintCancel else hintHold }
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { if (recording) endRecord(!cancelled) }
                }
                true
            }
            root.addView(mic, mp)
            val pen = circleBtn("✎", Neo.card, 36)
            pen.setOnClickListener { showGuideInput() }
            val pp = LinearLayout.LayoutParams(dp(36), dp(36))
            pp.setMargins(dp(6), 0, 0, 0)
            root.addView(pen, pp)
            val stop = tv("رکو", 14f, Color.WHITE)
            stop.background = Neo.pill(ctx, Neo.red, 0, 14)
            stop.setPadding(dp(12), dp(6), dp(12), dp(6))
            stop.setOnClickListener { onStop() }
            val sp = LinearLayout.LayoutParams(-2, -2)
            sp.setMargins(dp(6), 0, 0, 0)
            root.addView(stop, sp)
        }
        statusTv = t
        yesB = yes
        noB = no
        val w = Math.min(screenW() - dp(24), dp(360))
        add(root, lp(w, -2, nf, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, dp(140)))
        statusV = root
    }

    /** Small input window to type a correction while AURA is working. */
    fun showGuideInput() {
        ui.post {
            if (guideV != null) return@post
            val root = KeyRoot(ctx) { hideGuideNow() }
            root.orientation = LinearLayout.HORIZONTAL
            root.gravity = Gravity.CENTER_VERTICAL
            root.layoutDirection = View.LAYOUT_DIRECTION_RTL
            root.background = Neo.panel(ctx, 22, 22)
            root.setPadding(dp(12), dp(8), dp(12), dp(8))
            val input = EditText(ctx)
            input.hint = "AURA کو بتائیں کیا کرنا ہے..."
            input.setHintTextColor(Neo.dim)
            input.setTextColor(Color.WHITE)
            input.textSize = 15f
            input.setSingleLine(true)
            input.imeOptions = EditorInfo.IME_ACTION_SEND
            input.background = Neo.pill(ctx, Neo.card, Neo.stroke, 20)
            input.setPadding(dp(14), dp(6), dp(14), dp(6))
            input.setOnEditorActionListener { _, _, _ -> submitGuide(input.text.toString()); true }
            val ip = LinearLayout.LayoutParams(0, -2, 1f)
            ip.setMargins(0, 0, dp(8), 0)
            root.addView(input, ip)
            val send = circleBtn("➤", Neo.gold, 42)
            send.setOnClickListener { submitGuide(input.text.toString()) }
            root.addView(send, LinearLayout.LayoutParams(dp(42), dp(42)))
            val w = Math.min(screenW() - dp(24), dp(360))
            val p = lp(w, -2, focusFlag, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, dp(206))
            p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
            add(root, p)
            guideV = root
            guideInput = input
            input.requestFocus()
        }
    }

    private fun submitGuide(t: String) {
        val s = t.trim()
        if (s.isEmpty()) return
        hideGuideNow()
        addUser("✋ $s")
        onGoal(s)
    }

    private fun hideGuideNow() {
        hideKeyboardOf(guideInput)
        remove(guideV)
        guideV = null; guideInput = null
    }

    fun setRunning(on: Boolean) {
        ui.post {
            running = on
            if (on) {
                hidePanelNow(); hideOrdersNow(); hideIdleNow()
                buildStatus(true, "AURA کام شروع کر رہا ہے...")
            } else {
                hideGuideNow()
                val first = (statusV as? LinearLayout)?.getChildAt(0)
                if (first is OrbView) first.setState(OrbView.State.IDLE)
                ui.postDelayed(hideStatus, 3500)
                showIdle()
            }
        }
    }

    /** "Working on it" pill without controls (e.g. while a voice message is being understood). */
    fun setThinking(on: Boolean, msg: String) {
        ui.post {
            if (on) buildStatus(false, msg) else { ui.removeCallbacks(hideStatus); remove(statusV); statusV = null }
        }
    }

    /** AURA needs your help: show the question and open the typing box (you can also hold 🎙 to answer). */
    fun askUser(question: String) {
        ui.post {
            addItem(Item(1, question))
            if (statusV == null) buildStatus(true, question)
            statusTv?.text = question
            showGuideInput()
        }
    }

    suspend fun confirm(question: String): Boolean = suspendCancellableCoroutine { cont ->
        ui.post {
            if (statusV == null) buildStatus(true, question)
            statusTv?.text = question
            yesB?.visibility = View.VISIBLE
            noB?.visibility = View.VISIBLE
            fun answer(v: Boolean) {
                yesB?.visibility = View.GONE
                noB?.visibility = View.GONE
                if (cont.isActive) cont.resume(v)
            }
            yesB?.setOnClickListener { answer(true) }
            noB?.setOnClickListener { answer(false) }
        }
    }

    /* ---------------- messages ---------------- */

    fun addUser(text: String) { ui.post { addItem(Item(0, text)) } }

    /** A step line (small, monospace). */
    fun log(line: String) {
        ui.post {
            addItem(Item(2, line))
            statusTv?.text = line
        }
    }

    /** A message from AURA (results, answers, errors). Shows a pill if nothing else is on screen. */
    fun say(text: String) {
        ui.post {
            addItem(Item(1, text))
            if (statusV != null) statusTv?.text = text
            else if (panelV == null) { buildStatus(false, text); ui.postDelayed(hideStatus, 4500) }
        }
    }

    fun destroy() {
        ui.removeCallbacks(ticker)
        ui.removeCallbacks(hideStatus)
        if (recording) endRecord(false)
        hideIdleNow(); hidePanelNow(); hideOrdersNow(); hideGuideNow()
        remove(statusV); statusV = null
    }
}
