package com.aura.agent

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import kotlinx.coroutines.delay

/**
 * Phone actions that need NO internet and NO AI: Wi-Fi, hotspot, mobile data, Bluetooth, airplane mode,
 * torch, volume, lock the screen, home/back, open an app. Understands broken Urdu/English.
 * Returns a short report, "" if it already told the user something, or null if the sentence is not one of these.
 */
object LocalActions {
    private val onList = listOf("آن", "چالو", "جلاو", "کھولو", "کھول", "چلاو", "on", "start").map { Fuzzy.norm(it) }
    private val offList = listOf("بند", "آف", "بجھاو", "روکو", "off", "stop", "close").map { Fuzzy.norm(it) }
    private val openVerbs = listOf("کھولو", "کھول", "چلاو", "اوپن", "open", "launch").map { Fuzzy.norm(it) }

    private fun isWord(w: String, list: List<String>): Boolean =
        list.any { it == w || (it.length > 3 && w.length > 3 && Fuzzy.ratio(w, it) >= 0.8) }

    private val aliases: List<Pair<List<String>, String>> = listOf(
        Pair(listOf("یوٹیوب", "youtube"), "YouTube"),
        Pair(listOf("واٹس ایپ", "واٹس اپ", "واٹسایپ", "وٹس ایپ", "whatsapp"), "WhatsApp"),
        Pair(listOf("کروم", "chrome", "براؤزر"), "Chrome"),
        Pair(listOf("کیمرہ", "کیمرا", "camera"), "Camera"),
        Pair(listOf("گیلری", "gallery", "تصویریں"), "Gallery"),
        Pair(listOf("سیٹنگ", "سیٹنگز", "settings"), "Settings"),
        Pair(listOf("فیس بک", "facebook"), "Facebook"),
        Pair(listOf("ٹک ٹاک", "tiktok"), "TikTok"),
        Pair(listOf("ٹیلی گرام", "telegram"), "Telegram"),
        Pair(listOf("میسنجر", "messenger"), "Messenger"),
        Pair(listOf("گوگل میپس", "میپس", "نقشہ", "maps"), "Maps"),
        Pair(listOf("پلے اسٹور", "play store"), "Play Store"),
        Pair(listOf("کیلکولیٹر", "calculator"), "Calculator"),
        Pair(listOf("گھڑی", "clock", "الارم"), "Clock"),
        Pair(listOf("فون", "ڈائلر", "phone"), "Phone"),
        Pair(listOf("میسجز", "میسج", "messages"), "Messages"),
        Pair(listOf("کانٹیکٹس", "رابطے", "contacts"), "Contacts"),
        Pair(listOf("جی میل", "gmail"), "Gmail"),
        Pair(listOf("انسٹاگرام", "instagram"), "Instagram"),
        Pair(listOf("اسنیپ چیٹ", "snapchat"), "Snapchat")
    ).map { p -> Pair(p.first.map { Fuzzy.norm(it) }, p.second) }

    private val tileAliases = mapOf(
        "wifi" to listOf("wifi", "wlan", "وائی فائی"),
        "bt" to listOf("bluetooth", "بلوٹوتھ"),
        "hotspot" to listOf("hotspot", "tethering", "ہاٹ سپاٹ"),
        "data" to listOf("mobile data", "cellular data", "data", "ڈیٹا"),
        "airplane" to listOf("airplane", "flight mode", "aeroplane", "ہوائی جہاز")
    )

    private var torchOn = false

    suspend fun handle(svc: AuraService, text: String): String? {
        val words = Fuzzy.tokens(text)
        if (words.isEmpty()) return null
        val off = words.any { isWord(it, offList) }
        val on = !off && words.any { isWord(it, onList) }
        val want: Boolean? = if (on) true else if (off) false else null
        fun has(vararg keys: String): Boolean = keys.any { k ->
            val kt = Fuzzy.tokens(k)
            kt.isNotEmpty() && kt.all { Fuzzy.tokenMatch(it, words) }
        }

        // lock / screen off
        if (has("اسکرین بند", "سکرین بند", "اسکرین آف", "سکرین آف", "فون لاک", "اسکرین لاک", "lock screen", "screen off")) {
            return if (svc.globalAction("lock_screen")) "🔒 اسکرین بند کر دی" else "✗ اس فون پر اسکرین بند نہیں ہو سکی"
        }
        // torch
        if (has("ٹارچ", "torch", "flashlight", "فلیش لائٹ")) {
            return try { torch(svc, want) } catch (e: Exception) { "✗ ٹارچ نہیں چلی" }
        }
        // volume
        if (has("آواز بڑھاو", "والیوم بڑھاو", "آواز تیز", "volume up")) { volume(svc, true); return "🔊 آواز بڑھا دی" }
        if (has("آواز کم", "والیوم کم", "آواز دھیمی", "volume down")) { volume(svc, false); return "🔉 آواز کم کر دی" }
        // navigation
        if (has("ہوم پر جاو", "ہوم اسکرین", "go home")) { svc.globalAction("home"); return "🏠 ہوم" }
        if (has("پیچھے جاو", "واپس جاو", "back")) { svc.globalAction("back"); return "◀ پیچھے" }
        if (has("اسکرین شاٹ", "سکرین شاٹ", "screenshot")) { return if (svc.globalAction("screenshot")) "📸 اسکرین شاٹ لے لیا" else "✗ اس فون پر اسکرین شاٹ نہیں ہو سکا" }

        // Quick Settings switches
        val tile = when {
            has("وائی فائی", "وائفائی", "wifi", "wi fi") -> Pair("wifi", "وائی فائی")
            has("بلوٹوتھ", "bluetooth") -> Pair("bt", "بلوٹوتھ")
            has("ہاٹ سپاٹ", "ہاٹسپاٹ", "hotspot") -> Pair("hotspot", "ہاٹ سپاٹ")
            has("ایئرپلین", "ہوائی جہاز", "airplane", "فلائٹ موڈ") -> Pair("airplane", "ایئرپلین موڈ")
            has("موبائل ڈیٹا", "ڈیٹا", "انٹرنیٹ", "internet", "mobile data") -> Pair("data", "موبائل ڈیٹا")
            else -> null
        }
        if (tile != null && words.size <= 6) {
            if (!svc.prepareScreen()) return ""
            return setTile(svc, tile.first, tile.second, want)
        }

        // open an app (short commands only; longer tasks go to the AI)
        if (words.size <= 5 && words.any { isWord(it, openVerbs) }) {
            var label: String? = null
            for (a in aliases) {
                if (a.first.any { k -> val kt = Fuzzy.tokens(k); kt.isNotEmpty() && kt.all { Fuzzy.tokenMatch(it, words) } }) { label = a.second; break }
            }
            if (label == null) {
                for (w in words) {
                    if (w.length >= 3 && !isWord(w, openVerbs) && Memory.get(svc).findApp(w) != null) { label = w; break }
                }
            }
            if (label != null) {
                if (!svc.prepareScreen()) return ""
                return if (svc.openApp(label)) "📱 $label کھول دیا" else "✗ $label ایپ نہیں ملی"
            }
        }
        return null
    }

    private fun torch(svc: AuraService, want: Boolean?): String {
        val cm = svc.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return "✗ اس فون میں فلیش نہیں ملا"
        val on = want ?: !torchOn
        cm.setTorchMode(id, on)
        torchOn = on
        return "🔦 ٹارچ " + (if (on) "آن" else "بند")
    }

    private fun volume(svc: AuraService, up: Boolean) {
        val am = svc.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
    }

    private fun findTile(s: ScreenSnapshot?, type: String): UiNode? {
        if (s == null) return null
        val al = tileAliases[type] ?: return null
        return s.nodes.firstOrNull { n ->
            val l = (n.label() + " " + n.desc).lowercase().replace(Regex("[\\-\\u2010-\\u2015]"), "")
            (n.clickable || n.checkable) && al.any { l.contains(it) }
        }
    }

    private fun stateOf(n: UiNode): Boolean? {
        if (n.checkable) return n.isOn
        val d = (n.desc + " " + n.text).lowercase()
        return when {
            d.contains("off") || d.contains("بند") -> false
            d.contains(" on") || d.endsWith("on") || d.contains("چالو") -> true
            else -> null
        }
    }

    /** Opens Quick Settings, finds the tile, taps it only if needed, closes. No AI involved. */
    private suspend fun setTile(svc: AuraService, type: String, name: String, want: Boolean?): String {
        svc.globalAction("quick_settings")
        delay(1000)
        var node = findTile(svc.snapshot(), type)
        if (node == null) {
            val m = svc.resources.displayMetrics
            svc.swipeRaw(m.widthPixels / 2f, 8f, m.widthPixels / 2f, m.heightPixels * 0.75f, 350)
            delay(800)
            node = findTile(svc.snapshot(), type)
        }
        if (node == null) {
            svc.globalAction("back")
            return "✗ $name کی ٹائل Quick Settings میں نہیں ملی (اسے ایڈیٹ کر کے شامل کریں)"
        }
        val st = stateOf(node)
        val msg: String
        if (want != null && st != null && st == want) {
            msg = "✓ $name پہلے سے " + (if (want) "آن" else "بند") + " ہے"
        } else {
            svc.click(node)
            delay(700)
            msg = "✓ $name " + (if (want == null) "تبدیل کیا" else if (want) "آن کر دیا" else "بند کر دیا")
        }
        svc.globalAction("back")
        return msg
    }
}
