package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.PhoneCallback
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.CallRecordEntity
import com.example.data.SinaSettingsState
import com.example.ui.theme.BorderGlowSlate
import com.example.ui.theme.CosmicObsidian
import com.example.ui.theme.DeepSpaceNavy
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldPulse
import com.example.ui.theme.GlassSlate
import com.example.ui.theme.LunarCyan
import com.example.ui.theme.LunarSilver
import com.example.ui.theme.MutedSilver

@Composable
fun CallGuardScreen(
    settings: SinaSettingsState,
    callRecords: List<CallRecordEntity>,
    hasPhonePermissions: Boolean,
    onRequestPhonePermissions: () -> Unit,
    onToggleAutoAnswer: (Boolean) -> Unit,
    onSaveGreeting: (String) -> Unit,
    onTestVoice: (String) -> Unit,
    onSimulateCallFlow: (String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var greetingDraft by remember(settings.callGreetingText) {
        mutableStateOf(settings.callGreetingText)
    }
    var simCallerName by remember { mutableStateOf("Ali Courier") }
    var simPhone by remember { mutableStateOf("+92 300 5550192") }
    var simMessage by remember { mutableStateOf("I am outside the main gate with a parcel, please ask them to unlock the gate.") }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item(key = "call_guard_config") {
                SectionContainer(
                    title = "SMART CALL GUARD · 2ND RING",
                    subtitle = "If you miss ring #1, Sina auto-answers ring #2, listens & reports"
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Auto-Answer 2nd Ring",
                                style = MaterialTheme.typography.titleMedium,
                                color = LunarSilver
                            )
                            Text(
                                text = if (hasPhonePermissions) {
                                    "Telecom permission active"
                                } else {
                                    "Grant Call permissions for live phone pickup"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = if (hasPhonePermissions) EmeraldPulse else MutedSilver
                            )
                        }
                        Switch(
                            checked = settings.autoCallSecondRingEnabled,
                            onCheckedChange = onToggleAutoAnswer,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CosmicObsidian,
                                checkedTrackColor = LunarCyan
                            ),
                            modifier = Modifier.testTag("switch_auto_answer")
                        )
                    }

                    if (!hasPhonePermissions) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = onRequestPhonePermissions,
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, LunarCyan),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = LunarCyan)
                            Spacer(Modifier.width(8.dp))
                            Text("Grant Call Answer Permissions", color = LunarCyan)
                        }
                    }

                    Spacer(Modifier.height(14.dp))

                    OutlinedTextField(
                        value = greetingDraft,
                        onValueChange = { greetingDraft = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Natural Caller Greeting", color = LunarCyan) },
                        minLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LunarCyan,
                            unfocusedBorderColor = BorderGlowSlate,
                            focusedTextColor = LunarSilver,
                            unfocusedTextColor = LunarSilver,
                            focusedContainerColor = DeepSpaceNavy,
                            unfocusedContainerColor = DeepSpaceNavy
                        ),
                        shape = RoundedCornerShape(14.dp)
                    )

                    Spacer(Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onSaveGreeting(greetingDraft) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = LunarCyan,
                                contentColor = CosmicObsidian
                            )
                        ) {
                            Text("Save Greeting")
                        }
                        OutlinedButton(
                            onClick = { onTestVoice(greetingDraft) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, ElectricViolet)
                        ) {
                            Text("Hear Voice", color = ElectricViolet)
                        }
                    }
                }
            }

            item(key = "call_sim_section") {
                SectionContainer(
                    title = "TEST 2ND-RING CALL HANDLER",
                    subtitle = "Verify how Sina logs ring #1, answers ring #2, and summarizes"
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = simCallerName,
                            onValueChange = { simCallerName = it },
                            label = { Text("Caller Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = LunarCyan,
                                unfocusedBorderColor = BorderGlowSlate,
                                focusedTextColor = LunarSilver,
                                unfocusedTextColor = LunarSilver
                            ),
                            shape = RoundedCornerShape(14.dp)
                        )
                        OutlinedTextField(
                            value = simMessage,
                            onValueChange = { simMessage = it },
                            label = { Text("Caller Spoken Message") },
                            minLines = 2,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = LunarCyan,
                                unfocusedBorderColor = BorderGlowSlate,
                                focusedTextColor = LunarSilver,
                                unfocusedTextColor = LunarSilver
                            ),
                            shape = RoundedCornerShape(14.dp)
                        )
                        Button(
                            onClick = { onSimulateCallFlow(simCallerName, simPhone, simMessage) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("simulate_second_ring_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ElectricViolet,
                                contentColor = CosmicObsidian
                            )
                        ) {
                            Icon(Icons.Default.PhoneInTalk, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Simulate Ring #1 Miss -> Ring #2 Auto-Answer")
                        }
                    }
                }
            }

            item(key = "call_logs_title") {
                Text(
                    text = "CALL REPORTS",
                    style = MaterialTheme.typography.titleLarge,
                    color = LunarSilver
                )
            }

            if (callRecords.isEmpty()) {
                item(key = "call_empty") {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = GlassSlate,
                        border = BorderStroke(1.dp, BorderGlowSlate)
                    ) {
                        Text(
                            text = "No call events recorded yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MutedSilver,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(callRecords, key = { it.id }) { rec ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = GlassSlate,
                        border = BorderStroke(
                            1.dp,
                            if (rec.wasAutoAnswered) EmeraldPulse else BorderGlowSlate
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = if (rec.wasAutoAnswered) Icons.Default.PhoneCallback else Icons.Default.CallReceived,
                                contentDescription = null,
                                tint = if (rec.wasAutoAnswered) EmeraldPulse else LunarCyan,
                                modifier = Modifier.size(22.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${rec.callerName} · Ring #${rec.ringCount}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = LunarSilver
                                )
                                if (rec.transcript.isNotBlank()) {
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        text = "\"${rec.transcript}\"",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MutedSilver
                                    )
                                }
                                if (rec.aiSummary.isNotBlank()) {
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        text = rec.aiSummary,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = LunarCyan
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
