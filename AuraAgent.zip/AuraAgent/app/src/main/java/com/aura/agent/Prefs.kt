package com.aura.agent

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("aura", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("key", "") ?: ""
    fun setApiKey(c: Context, v: String) = sp(c).edit().putString("key", v.trim()).apply()

    /** Names with "gemini" use the Google Gemini API, anything else uses Claude. */
    fun model(c: Context): String = sp(c).getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash"
    fun setModel(c: Context, v: String) = sp(c).edit().putString("model", v.trim()).apply()

    /** Empty = automatic (official address of the provider). Later: your own server address. */
    fun baseUrl(c: Context): String = sp(c).getString("url", "") ?: ""
    fun setBaseUrl(c: Context, v: String) = sp(c).edit().putString("url", v.trim()).apply()
}
