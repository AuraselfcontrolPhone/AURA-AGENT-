package com.aura.agent

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import java.util.Random

/** Futuristic wallpaper drawn in code: night sky, twinkling stars, big moon, aurora glow, moving neon grid. */
class FuturisticBg(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random(7)
    private val sx = FloatArray(110) { rnd.nextFloat() }
    private val sy = FloatArray(110) { rnd.nextFloat() * 0.8f }
    private val sr = FloatArray(110) { 0.6f + rnd.nextFloat() * 1.6f }
    private val sp = FloatArray(110) { rnd.nextFloat() * 6.28f }
    private var phase = 0f
    private val anim: ValueAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 7000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // sky
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(Color.parseColor("#02030D"), Color.parseColor("#0A1030"), Color.parseColor("#1B0F42")),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, p)

        // aurora glows
        p.shader = RadialGradient(w * 0.15f, h * 0.55f, w * 0.8f, intArrayOf(Neo.withAlpha(Neo.cyan, 55), 0), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, p)
        p.shader = RadialGradient(w * 0.95f, h * 0.85f, w * 0.9f, intArrayOf(Neo.withAlpha(Neo.gold, 70), 0), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, p)
        p.shader = null

        // stars
        for (i in sx.indices) {
            val a = (0.25f + 0.75f * Math.abs(Math.sin(phase * 6.28 + sp[i]).toFloat())) * 255
            p.color = Color.argb(a.toInt(), 220, 232, 255)
            canvas.drawCircle(sx[i] * w, sy[i] * h, sr[i], p)
        }

        // moon
        val mx = w * 0.80f
        val my = h * 0.13f
        val mr = w * 0.14f
        p.shader = RadialGradient(mx, my, mr * 2.6f, intArrayOf(Neo.withAlpha(Color.parseColor("#BFD0FF"), 120), 0), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(mx, my, mr * 2.6f, p)
        p.shader = RadialGradient(mx - mr * 0.3f, my - mr * 0.3f, mr * 1.5f,
            intArrayOf(Color.parseColor("#FFFFFF"), Color.parseColor("#DCE3F7"), Color.parseColor("#8E9BC8"), Color.parseColor("#3E4880")),
            floatArrayOf(0f, 0.35f, 0.75f, 1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(mx, my, mr, p)
        p.shader = null
        p.color = Color.argb(60, 60, 70, 120)
        canvas.drawCircle(mx - mr * 0.3f, my - mr * 0.2f, mr * 0.22f, p)
        canvas.drawCircle(mx + mr * 0.3f, my + mr * 0.1f, mr * 0.17f, p)
        canvas.drawCircle(mx - mr * 0.05f, my + mr * 0.4f, mr * 0.2f, p)

        // neon perspective grid at the bottom
        val horizon = h * 0.80f
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f
        val vx = w / 2f
        for (i in -10..10) {
            p.color = Neo.withAlpha(Neo.cyan, 38)
            canvas.drawLine(vx, horizon, vx + i * w * 0.18f, h, p)
        }
        for (k in 0 until 9) {
            val t = ((k + phase) / 9f)
            val y = horizon + (h - horizon) * t * t
            p.color = Neo.withAlpha(Neo.cyan, (20 + 60 * t).toInt())
            canvas.drawLine(0f, y, w, y, p)
        }
        p.style = Paint.Style.FILL
    }
}
