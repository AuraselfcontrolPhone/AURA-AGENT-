package com.aura.agent

/** Tolerant matching: understands broken or slightly wrong speech/spelling, fully offline. */
object Fuzzy {
    fun norm(s: String): String = s.lowercase()
        .replace('ي', 'ی').replace('ك', 'ک').replace('ھ', 'ہ').replace("ۃ", "ہ").replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        .replace(Regex("[\\u064B-\\u065F\\u0670]"), "")
        .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
        .replace(Regex("\\s+"), " ").trim()

    fun tokens(s: String): List<String> = norm(s).split(" ").filter { it.isNotEmpty() }

    fun ratio(a: String, b: String): Double {
        if (a == b) return 1.0
        if (a.isEmpty() || b.isEmpty()) return 0.0
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return 1.0 - prev[b.length].toDouble() / maxOf(a.length, b.length)
    }

    /** Does the word `token` appear (almost) in the list of spoken words? */
    fun tokenMatch(token: String, words: List<String>): Boolean =
        words.any { it == token || (token.length > 3 && it.length > 3 && ratio(it, token) >= 0.74) }

    /** 0..1 similarity of two sentences, word by word. */
    fun similarity(a: String, b: String): Double {
        val ta = tokens(a)
        val tb = tokens(b)
        if (ta.isEmpty() || tb.isEmpty()) return 0.0
        val m = ta.count { tokenMatch(it, tb) }
        return 2.0 * m / (ta.size + tb.size)
    }
}
