package com.aura.agent

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray

/**
 * AURA's memory:
 *  - recipes: exact step lists that worked (replayed instantly, no AI call)
 *  - elements: which buttons are used per app
 *  - notes: facts the AI chose to remember about an app
 *  - orders: history of every command
 */
class Memory private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "aura_mem.db", null, 3) {

    class Order(val id: Long, val text: String, val ts: Long, val status: String, val ms: Long, val fast: Boolean)
    class Call(val id: Long, val number: String, val name: String, val ts: Long, val summary: String, val transcript: String)
    class Sched(val id: Long, val goal: String, val hour: Int, val min: Int, val daily: Boolean)

    companion object {
        @Volatile private var inst: Memory? = null
        fun get(ctx: Context): Memory =
            inst ?: synchronized(this) { inst ?: Memory(ctx.applicationContext).also { inst = it } }

        private fun norm(s: String) =
            s.lowercase().replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").replace(Regex("\\s+"), " ").trim()
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE recipes(goal TEXT PRIMARY KEY, steps TEXT, uses INTEGER, ts INTEGER)")
        db.execSQL("CREATE TABLE elements(pkg TEXT, label TEXT, uses INTEGER, PRIMARY KEY(pkg,label))")
        db.execSQL("CREATE TABLE notes(pkg TEXT, note TEXT, ts INTEGER, PRIMARY KEY(pkg,note))")
        db.execSQL("CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT, ts INTEGER, status TEXT, ms INTEGER, steps INTEGER, fast INTEGER)")
        db.execSQL("CREATE TABLE calls(id INTEGER PRIMARY KEY AUTOINCREMENT, number TEXT, name TEXT, ts INTEGER, summary TEXT, transcript TEXT)")
        db.execSQL("CREATE TABLE missed(number TEXT PRIMARY KEY, ts INTEGER)")
        db.execSQL("CREATE TABLE schedules(id INTEGER PRIMARY KEY AUTOINCREMENT, goal TEXT, hour INTEGER, min INTEGER, daily INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        db.execSQL("DROP TABLE IF EXISTS recipes")
        db.execSQL("DROP TABLE IF EXISTS elements")
        db.execSQL("DROP TABLE IF EXISTS notes")
        db.execSQL("DROP TABLE IF EXISTS orders")
        db.execSQL("DROP TABLE IF EXISTS calls")
        db.execSQL("DROP TABLE IF EXISTS missed")
        db.execSQL("DROP TABLE IF EXISTS schedules")
        onCreate(db)
    }

    /* ---------- recipes ---------- */

    fun saveRecipe(goal: String, stepsJson: String) {
        val key = norm(goal)
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO recipes VALUES(?,?,COALESCE((SELECT uses FROM recipes WHERE goal=?),0)+1,?)",
            arrayOf<Any?>(key, stepsJson, key, System.currentTimeMillis())
        )
    }

    fun findRecipeJson(goal: String): String? {
        readableDatabase.rawQuery("SELECT steps FROM recipes WHERE goal=?", arrayOf(norm(goal))).use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }

    fun deleteRecipe(goal: String) {
        writableDatabase.execSQL("DELETE FROM recipes WHERE goal=?", arrayOf<Any?>(norm(goal)))
    }

    fun recipeCount(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM recipes", null).use { return if (it.moveToFirst()) it.getInt(0) else 0 }
    }

    private fun lines(json: String): String {
        val a = JSONArray(json)
        val sb = StringBuilder()
        for (i in 0 until a.length()) {
            val s = a.getJSONObject(i)
            sb.append(i + 1).append(". ").append(s.getString("t")).append(' ')
                .append(s.optString("label").ifEmpty { s.optString("v") }).append('\n')
        }
        return sb.toString().trim()
    }

    /** A similar (not identical) earlier goal, as readable steps, to give the AI a head start. */
    fun nearRecipe(goal: String): String? {
        val a = norm(goal).split(" ").toSet()
        var best: String? = null
        var bestScore = 0.0
        readableDatabase.rawQuery("SELECT goal, steps FROM recipes", null).use {
            while (it.moveToNext()) {
                val b = it.getString(0).split(" ").toSet()
                if (b == a) continue
                val score = a.intersect(b).size.toDouble() / a.union(b).size.coerceAtLeast(1)
                if (score > bestScore) { bestScore = score; best = it.getString(1) }
            }
        }
        val s = best
        return if (bestScore >= 0.6 && s != null) lines(s) else null
    }

    /* ---------- elements & notes ---------- */

    fun bumpElement(pkg: String, label: String) {
        if (label.isBlank()) return
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO elements VALUES(?,?,COALESCE((SELECT uses FROM elements WHERE pkg=? AND label=?),0)+1)",
            arrayOf<Any?>(pkg, label, pkg, label)
        )
    }

    fun hints(pkg: String): String {
        val sb = StringBuilder()
        readableDatabase.rawQuery(
            "SELECT label FROM elements WHERE pkg=? ORDER BY uses DESC LIMIT 12", arrayOf(pkg)
        ).use { while (it.moveToNext()) sb.append("\"").append(it.getString(0)).append("\" ") }
        return sb.toString().trim()
    }

    fun addNote(pkg: String, note: String) {
        if (note.isBlank()) return
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO notes VALUES(?,?,?)", arrayOf<Any?>(pkg, note.take(200), System.currentTimeMillis())
        )
    }

    fun notes(pkg: String): String {
        val sb = StringBuilder()
        readableDatabase.rawQuery(
            "SELECT note FROM notes WHERE pkg=? ORDER BY ts DESC LIMIT 8", arrayOf(pkg)
        ).use { while (it.moveToNext()) sb.append("- ").append(it.getString(0)).append('\n') }
        return sb.toString().trim()
    }

    /* ---------- orders ---------- */

    fun addOrder(text: String): Long {
        val db = writableDatabase
        db.execSQL("INSERT INTO orders(text,ts,status,ms,steps,fast) VALUES(?,?,?,?,?,?)",
            arrayOf<Any?>(text, System.currentTimeMillis(), "run", 0, 0, 0))
        db.rawQuery("SELECT last_insert_rowid()", null).use { return if (it.moveToFirst()) it.getLong(0) else 0L }
    }

    fun finishOrder(id: Long, status: String, ms: Long, steps: Int, fast: Boolean) {
        writableDatabase.execSQL("UPDATE orders SET status=?, ms=?, steps=?, fast=? WHERE id=?",
            arrayOf<Any?>(status, ms, steps, if (fast) 1 else 0, id))
    }

    fun recentOrders(limit: Int): List<Order> {
        val out = ArrayList<Order>()
        readableDatabase.rawQuery(
            "SELECT id,text,ts,status,ms,fast FROM orders ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())
        ).use {
            while (it.moveToNext()) out.add(Order(it.getLong(0), it.getString(1), it.getLong(2), it.getString(3), it.getLong(4), it.getInt(5) == 1))
        }
        return out
    }

    /* ---------- calls ---------- */

    fun markMissed(number: String) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO missed VALUES(?,?)", arrayOf<Any?>(number, System.currentTimeMillis()))
    }

    fun clearMissed(number: String) {
        writableDatabase.execSQL("DELETE FROM missed WHERE number=?", arrayOf<Any?>(number))
    }

    fun wasMissedRecently(number: String, windowMs: Long): Boolean {
        readableDatabase.rawQuery("SELECT ts FROM missed WHERE number=?", arrayOf(number)).use {
            return it.moveToFirst() && System.currentTimeMillis() - it.getLong(0) <= windowMs
        }
    }

    fun addCall(number: String, name: String, summary: String, transcript: String) {
        writableDatabase.execSQL("INSERT INTO calls(number,name,ts,summary,transcript) VALUES(?,?,?,?,?)",
            arrayOf<Any?>(number, name, System.currentTimeMillis(), summary, transcript))
    }

    fun recentCalls(limit: Int): List<Call> {
        val out = ArrayList<Call>()
        readableDatabase.rawQuery("SELECT id,number,name,ts,summary,transcript FROM calls ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())).use {
            while (it.moveToNext()) out.add(Call(it.getLong(0), it.getString(1), it.getString(2), it.getLong(3), it.getString(4), it.getString(5)))
        }
        return out
    }

    /* ---------- schedules ---------- */

    fun addSchedule(goal: String, hour: Int, min: Int, daily: Boolean): Sched {
        val db = writableDatabase
        db.execSQL("INSERT INTO schedules(goal,hour,min,daily) VALUES(?,?,?,?)", arrayOf<Any?>(goal, hour, min, if (daily) 1 else 0))
        db.rawQuery("SELECT last_insert_rowid()", null).use {
            val id = if (it.moveToFirst()) it.getLong(0) else 0L
            return Sched(id, goal, hour, min, daily)
        }
    }

    fun schedules(): List<Sched> {
        val out = ArrayList<Sched>()
        readableDatabase.rawQuery("SELECT id,goal,hour,min,daily FROM schedules ORDER BY hour,min", null).use {
            while (it.moveToNext()) out.add(Sched(it.getLong(0), it.getString(1), it.getInt(2), it.getInt(3), it.getInt(4) == 1))
        }
        return out
    }

    fun schedule(id: Long): Sched? {
        readableDatabase.rawQuery("SELECT id,goal,hour,min,daily FROM schedules WHERE id=?", arrayOf(id.toString())).use {
            return if (it.moveToFirst()) Sched(it.getLong(0), it.getString(1), it.getInt(2), it.getInt(3), it.getInt(4) == 1) else null
        }
    }

    fun deleteSchedule(id: Long) {
        writableDatabase.execSQL("DELETE FROM schedules WHERE id=?", arrayOf<Any?>(id))
    }
}
