package com.aura.agent

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Call manager. Rule: if you miss a call from a number and the SAME number calls again soon,
 * SEENA answers the second call, tells the caller it is an AI assistant, listens, talks naturally,
 * takes a message, hangs up and saves a summary in the Calls tab.
 *
 * Android does not let apps tap into call audio directly, so SEENA uses the speakerphone:
 * it speaks through the speaker and listens through the microphone. Quality depends on the phone.
 */
class CallAssistant(private val svc: AuraService) {
    private val h = Handler(Looper.getMainLooper())
    private var ringing = false
    private var ringNumber = ""
    private var offhook = false
    private var pending: Runnable? = null
    private var job: Job? = null

    @Volatile var active = false

    private fun digits(n: String): String = n.filter { it.isDigit() }.takeLast(10)

    fun onPhoneState(state: String, number: String?) {
        if (!number.isNullOrBlank()) ringNumber = number
        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                if (!ringing) { ringing = true; offhook = false }
                scheduleAutoAnswer()
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                offhook = true
                cancelPending()
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                if (ringing && !offhook && digits(ringNumber).isNotEmpty()) {
                    Memory.get(svc).markMissed(digits(ringNumber))
                }
                active = false
                ringing = false
                offhook = false
                ringNumber = ""
                cancelPending()
            }
        }
    }

    private fun cancelPending() {
        pending?.let { h.removeCallbacks(it) }
        pending = null
    }

    private fun scheduleAutoAnswer() {
        if (!Prefs.callAuto(svc) || active || pending != null) return
        val delaySec = Prefs.getInt(svc, "callDelaySec", 10)   // nobody picks up for 10 seconds -> the assistant answers
        val r = Runnable { pending = null; answerNow(digits(ringNumber)) }
        pending = r
        h.postDelayed(r, delaySec * 1000L)
    }

    private fun answerNow(n: String) {
        if (!ringing || offhook) return
        if (svc.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            svc.overlay.say("کال اٹھانے کی اجازت نہیں ہے۔ SEENA ایپ کی سیٹنگ میں اجازتیں دیں۔")
            return
        }
        val tm = svc.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        try { tm.acceptRingingCall() } catch (e: Exception) { return }
        active = true
        Memory.get(svc).clearMissed(n)
        job = svc.scope.launch { session(n) }
    }

    /* ---------------- the conversation ---------------- */

    @Suppress("DEPRECATION")
    private suspend fun session(n: String) {
        val owner = Prefs.owner(svc)
        val callerName = nameOf(ringNumber.ifEmpty { n })
        val audio = svc.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try { svc.startForegroundService(Intent(svc, CallService::class.java)) } catch (e: Exception) {}

        var waited = 0
        while (!offhook && waited < 40) { delay(100); waited++ }
        delay(700)
        try {
            audio.isSpeakerphoneOn = true
            audio.setStreamVolume(AudioManager.STREAM_VOICE_CALL, audio.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0)
        } catch (e: Exception) {}

        val transcript = StringBuilder()
        var summary = ""
        var audioPath = ""
        try {
            val who = if (owner.isBlank()) "اس نمبر کے مالک" else owner
            val greet = Prefs.callMsg(svc).replace("{owner}", who)
            Speaker.speak(svc, greet, true)
            transcript.append("سینا: ").append(greet).append('\n')

            // record what the caller says (no AI needed, works offline)
            val wav = Mic.listen(60_000L, 9_000L) { active }
            if (wav != null && active) {
                val f = File(svc.filesDir, "call_" + System.currentTimeMillis() + ".wav")
                f.writeBytes(wav)
                audioPath = f.absolutePath
                val secs = (wav.size - 44) / 32000
                Speaker.speak(svc, "شکریہ، آپ کا پیغام پہنچا دیا جائے گا۔ خدا حافظ۔", true)
                if (Net.aiOk(svc)) {
                    try {
                        val said = withContext(Dispatchers.IO) { AiClient.transcribeBytes(svc, wav, "audio/wav") }.trim()
                        if (said.isNotEmpty()) { transcript.append("کالر: ").append(said).append('\n'); summary = said.take(140) }
                    } catch (e: Exception) {}
                }
                if (summary.isBlank()) summary = "پیغام ریکارڈ ہوا ($secs سیکنڈ) — ▶ سنیں"
            } else {
                Speaker.speak(svc, "ٹھیک ہے، میں آپ کی کال کا ذکر کر دوں گا۔ خدا حافظ۔", true)
                summary = "کال آئی، کسی نے پیغام نہیں چھوڑا"
            }
        } catch (e: Exception) {
            transcript.append("(خرابی: ").append(e.message).append(")\n")
        } finally {
            val still = active
            active = false
            if (still) {
                try {
                    val tm = svc.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                    tm.endCall()
                } catch (e: Exception) {}
            }
            try { audio.isSpeakerphoneOn = false } catch (e: Exception) {}
            try { svc.stopService(Intent(svc, CallService::class.java)) } catch (e: Exception) {}

            val num = ringNumber.ifEmpty { n }
            val title = if (callerName.isNotBlank()) callerName else if (num.isNotBlank()) num else "نامعلوم نمبر"
            val sum = if (summary.isBlank()) "پیغام نہیں ملا" else summary
            val tr = (if (audioPath.isNotEmpty()) "AUDIO:$audioPath\n" else "") + transcript.toString()
            Memory.get(svc).addCall(num, callerName, sum, tr)
            notifyOwner("📞 $title", sum)
        }
    }

    private fun notifyOwner(title: String, text: String) {
        svc.overlay.say("$title: $text")
        try {
            val nm = svc.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("aura_msg", "SEENA Messages", NotificationManager.IMPORTANCE_HIGH))
            val n = android.app.Notification.Builder(svc, "aura_msg")
                .setContentTitle(title).setContentText(text)
                .setStyle(android.app.Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.ic_menu_call).build()
            nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
        } catch (e: Exception) {}
    }

    private fun nameOf(number: String): String {
        if (number.isBlank() || svc.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return ""
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            val c = svc.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            var r = ""
            if (c != null) { if (c.moveToFirst()) r = c.getString(0) ?: ""; c.close() }
            r
        } catch (e: Exception) { "" }
    }
}
