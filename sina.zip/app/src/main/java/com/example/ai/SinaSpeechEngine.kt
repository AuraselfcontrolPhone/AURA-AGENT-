package com.example.ai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class SinaSpeechEngine(private val context: Context) {

    companion object {
        private const val TAG = "SinaSpeechEngine"
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speechRate = 1.0f
    private var speechPitch = 1.02f
    private var languageMode = "AUTO"

    private var speechRecognizer: SpeechRecognizer? = null
    private var continuousAlwaysSpeak = false
    private var onRecognizedCallback: ((String) -> Unit)? = null
    private var onErrorCallback: ((String) -> Unit)? = null

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    init {
        initTts()
    }

    private fun initTts() {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setSpeechRate(speechRate)
                tts?.setPitch(speechPitch)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                        if (continuousAlwaysSpeak) {
                            mainHandler.postDelayed({
                                if (continuousAlwaysSpeak && !_isListening.value) {
                                    startRecognizerInternal()
                                }
                            }, 350L)
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                    }
                })
            } else {
                Log.w(TAG, "TTS initialization status=$status")
            }
        }
    }

    fun updateVoiceTuning(rate: Float, pitch: Float, langMode: String) {
        speechRate = rate.coerceIn(0.6f, 1.5f)
        speechPitch = pitch.coerceIn(0.7f, 1.4f)
        languageMode = langMode
        tts?.setSpeechRate(speechRate)
        tts?.setPitch(speechPitch)
    }

    fun speak(text: String, interruptCurrent: Boolean = true) {
        val clean = text.trim()
        if (clean.isEmpty() || !ttsReady) return
        val hasArabicOrUrduScript = clean.any { it in '\u0600'..'\u06FF' }
        val targetLocale = when {
            languageMode == "URDU" || hasArabicOrUrduScript -> Locale("ur", "PK")
            else -> Locale.US
        }
        val availability = tts?.isLanguageAvailable(targetLocale) ?: TextToSpeech.LANG_NOT_SUPPORTED
        if (availability >= TextToSpeech.LANG_AVAILABLE) {
            tts?.language = targetLocale
        } else {
            tts?.language = Locale.US
        }
        tts?.setSpeechRate(speechRate)
        tts?.setPitch(speechPitch)
        val queueMode = if (interruptCurrent) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        tts?.speak(clean, queueMode, null, "sina_utt_${System.currentTimeMillis()}")
    }

    fun stopSpeaking() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun startSingleVoiceListen(
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        continuousAlwaysSpeak = false
        onRecognizedCallback = onResult
        onErrorCallback = onError
        mainHandler.post { startRecognizerInternal() }
    }

    fun setAlwaysSpeakMode(
        enabled: Boolean,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        continuousAlwaysSpeak = enabled
        onRecognizedCallback = onResult
        onErrorCallback = onError
        mainHandler.post {
            if (enabled) {
                startRecognizerInternal()
            } else {
                stopListeningInternal()
            }
        }
    }

    fun stopListening() {
        continuousAlwaysSpeak = false
        mainHandler.post { stopListeningInternal() }
    }

    private fun stopListeningInternal() {
        _isListening.value = false
        _partialTranscript.value = ""
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping SpeechRecognizer", e)
        }
        speechRecognizer = null
    }

    private fun startRecognizerInternal() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _isListening.value = false
            onErrorCallback?.invoke("Speech recognition service unavailable on this device.")
            return
        }
        try {
            speechRecognizer?.destroy()
            val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            speechRecognizer = recognizer

            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _isListening.value = true
                }

                override fun onBeginningOfSpeech() {
                    _partialTranscript.value = "Listening..."
                }

                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    _isListening.value = false
                }

                override fun onError(error: Int) {
                    _isListening.value = false
                    _partialTranscript.value = ""
                    if (continuousAlwaysSpeak &&
                        (error == SpeechRecognizer.ERROR_NO_MATCH ||
                            error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                    ) {
                        mainHandler.postDelayed({
                            if (continuousAlwaysSpeak && !_isSpeaking.value) {
                                startRecognizerInternal()
                            }
                        }, 600L)
                    } else if (!continuousAlwaysSpeak) {
                        val reason = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "Audio capture error"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
                            SpeechRecognizer.ERROR_NO_MATCH -> "Could not catch speech, try again"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected"
                            else -> "Speech error ($error)"
                        }
                        onErrorCallback?.invoke(reason)
                    }
                }

                override fun onResults(results: Bundle?) {
                    _isListening.value = false
                    _partialTranscript.value = ""
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val best = matches?.firstOrNull()?.trim().orEmpty()
                    if (best.isNotEmpty()) {
                        onRecognizedCallback?.invoke(best)
                    } else if (continuousAlwaysSpeak) {
                        mainHandler.postDelayed({
                            if (continuousAlwaysSpeak && !_isSpeaking.value) {
                                startRecognizerInternal()
                            }
                        }, 500L)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                    if (partial.isNotBlank()) {
                        _partialTranscript.value = partial
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val localeTag = when (languageMode) {
                "URDU" -> "ur-PK"
                "ENGLISH" -> "en-US"
                else -> Locale.getDefault().toLanguageTag()
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer.startListening(intent)
            _isListening.value = true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start SpeechRecognizer", e)
            _isListening.value = false
            onErrorCallback?.invoke(e.localizedMessage ?: "Mic start failed")
        }
    }

    fun release() {
        stopListening()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
