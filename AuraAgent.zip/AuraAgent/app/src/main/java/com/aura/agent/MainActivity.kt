package com.aura.agent

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val gold = Color.parseColor("#D4A73A")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.BLACK)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun tv(t: String, size: Float = 15f, color: Int = Color.WHITE) =
            TextView(this).apply { text = t; textSize = size; setTextColor(color); setPadding(0, pad / 2, 0, pad / 2) }
        fun field(hintText: String, value: String, secret: Boolean = false) = EditText(this).apply {
            hint = hintText; setText(value); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or (if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else 0)
        }
        fun button(t: String, click: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { click() }
        }

        root.addView(tv("AURA", 40f, gold))
        status = tv("")
        root.addView(status)

        val key = field("Gemini API key (AIza...)", Prefs.apiKey(this), true)
        val model = field("Model", Prefs.model(this))
        val url = field("خالی چھوڑیں", Prefs.baseUrl(this))
        root.addView(tv("API key (Google AI Studio سے)"))
        root.addView(key)
        root.addView(tv("Model (gemini-3.8-flash مفت ہے)"))
        root.addView(model)
        root.addView(tv("API URL (خالی چھوڑیں)"))
        root.addView(url)
        root.addView(button("محفوظ کرو") {
            Prefs.setApiKey(this, key.text.toString())
            Prefs.setModel(this, model.text.toString())
            Prefs.setBaseUrl(this, url.text.toString())
            Toast.makeText(this, "محفوظ ہو گیا", Toast.LENGTH_SHORT).show()
        })
        root.addView(tv("1) نیچے والے بٹن سے Accessibility کھولیں، Installed apps / Downloaded apps میں AURA Agent کو چالو کریں۔\n2) پھر کسی بھی ایپ میں اسکرین کے نیچے سنہری لکیر کو اوپر سلائیڈ کریں اور لکھیں۔", 14f, Color.LTGRAY))
        root.addView(button("Accessibility کھولو") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val on = AuraService.instance != null
        status.text = if (on) "✅ AURA چالو ہے" else "⚠ AURA ابھی چالو نہیں: Accessibility میں چالو کریں"
        status.setTextColor(if (on) Color.parseColor("#3ECF8E") else Color.parseColor("#F2CF72"))
    }
}
