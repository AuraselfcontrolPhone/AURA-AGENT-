package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        SmartButtonEntity::class,
        DeviceMemoryEntity::class,
        CommandReportEntity::class,
        CallRecordEntity::class,
        QaMessageEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SinaDatabase : RoomDatabase() {
    abstract fun sinaDao(): SinaDao

    companion object {
        @Volatile
        private var INSTANCE: SinaDatabase? = null

        fun getInstance(context: Context): SinaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SinaDatabase::class.java,
                    "sina_neural_core.db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.sinaDao()?.let { dao ->
                                    if (dao.getButtonCount() == 0) {
                                        dao.insertButtons(defaultSmartButtons())
                                    }
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        fun defaultSmartButtons(): List<SmartButtonEntity> = listOf(
            SmartButtonEntity(
                name = "Main Ceiling Light",
                roomSection = "Living Lounge",
                iconKey = "light",
                onUrl = "http://192.168.1.101/cm?cmnd=Power%20On",
                offUrl = "http://192.168.1.101/cm?cmnd=Power%20Off",
                voiceAliases = "living light, lounge light, main light, لائٹ, بتی",
                sortOrder = 1
            ),
            SmartButtonEntity(
                name = "Smart Inverter AC",
                roomSection = "Living Lounge",
                iconKey = "ac",
                onUrl = "http://192.168.1.102/ac/on",
                offUrl = "http://192.168.1.102/ac/off",
                voiceAliases = "ac, air conditioner, cooling, اے سی",
                sortOrder = 2
            ),
            SmartButtonEntity(
                name = "Bedroom Lunar Lamp",
                roomSection = "Master Suite",
                iconKey = "lamp",
                onUrl = "http://192.168.1.103/relay/0?turn=on",
                offUrl = "http://192.168.1.103/relay/0?turn=off",
                voiceAliases = "bedroom light, lamp, lunar lamp, بیڈروم لائٹ",
                sortOrder = 3
            ),
            SmartButtonEntity(
                name = "Ceiling Fan",
                roomSection = "Master Suite",
                iconKey = "fan",
                onUrl = "http://192.168.1.104/fan/on",
                offUrl = "http://192.168.1.104/fan/off",
                voiceAliases = "fan, bedroom fan, پنکھا",
                sortOrder = 4
            ),
            SmartButtonEntity(
                name = "Main Security Gate",
                roomSection = "Security & Entry",
                iconKey = "gate",
                onUrl = "http://192.168.1.105/gate/open",
                offUrl = "http://192.168.1.105/gate/lock",
                voiceAliases = "gate, main gate, door, lock, گیٹ, دروازہ",
                sortOrder = 5
            ),
            SmartButtonEntity(
                name = "Studio Cyber Strip",
                roomSection = "Workspace",
                iconKey = "power",
                onUrl = "http://192.168.1.106/strip/on",
                offUrl = "http://192.168.1.106/strip/off",
                voiceAliases = "studio, desk, power strip, pc power, اسٹوڈیو",
                sortOrder = 6
            )
        )
    }
}
