package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Toys
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.automation.SinaExecutionStatus
import com.example.data.CommandReportEntity
import com.example.data.SinaSettingsState
import com.example.data.SmartButtonEntity
import com.example.ui.theme.BorderGlowCyan
import com.example.ui.theme.BorderGlowSlate
import com.example.ui.theme.CosmicObsidian
import com.example.ui.theme.DeepSpaceNavy
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldPulse
import com.example.ui.theme.GlassSlate
import com.example.ui.theme.GlassSlateHigh
import com.example.ui.theme.LunarCyan
import com.example.ui.theme.LunarSilver
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.RoseAlert

@Composable
fun HomeAutomationScreen(
    buttons: List<SmartButtonEntity>,
    reports: List<CommandReportEntity>,
    settings: SinaSettingsState,
    executionStatus: SinaExecutionStatus,
    onTriggerButton: (SmartButtonEntity, Boolean) -> Unit,
    onEditButton: (SmartButtonEntity) -> Unit,
    onAddNewButton: () -> Unit,
    onOpenOrderMenu: () -> Unit,
    onToggleAlwaysSpeak: (Boolean) -> Unit,
    onToggleFloatingOrb: (Boolean) -> Unit,
    onStudyDevice: () -> Unit,
    onInterruptAndGuide: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    var guideText by remember { mutableStateOf("") }
    var horizontalDragDelta by remember { mutableFloatStateOf(0f) }

    val groupedButtons = remember(buttons) {
        buttons.groupBy { it.roomSection.ifBlank { "General Control" } }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { horizontalDragDelta = 0f },
                    onHorizontalDrag = { _, dragAmount ->
                        horizontalDragDelta += dragAmount
                    },
                    onDragEnd = {
                        // Right-to-left swipe opens the Order Menu cleanly
                        if (horizontalDragDelta < -120f) {
                            onOpenOrderMenu()
                        }
                        horizontalDragDelta = 0f
                    }
                )
            },
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 104.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // SECTION 1: Futuristic Sina Neural Header & Telemetry Controls
            item(key = "section_header") {
                SectionContainer(
                    title = "SINA NEURAL COMMAND",
                    subtitle = "Smart Home · Voice · Visual Memory"
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (executionStatus.isRunning) {
                                    executionStatus.currentStepText
                                } else {
                                    "Indexed ${executionStatus.studiedAppsCount} device apps"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = LunarSilver
                            )
                            Text(
                                text = "Swipe left or tap Order below to command Sina",
                                style = MaterialTheme.typography.labelSmall,
                                color = LunarCyan
                            )
                        }
                        IconButton(
                            onClick = onStudyDevice,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF13213D))
                                .testTag("study_device_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Re-study Device Apps",
                                tint = LunarCyan
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        QuickModeChip(
                            label = if (settings.alwaysSpeakEnabled) "Always Speak: ON" else "Always Speak",
                            icon = Icons.Default.RecordVoiceOver,
                            active = settings.alwaysSpeakEnabled,
                            onClick = { onToggleAlwaysSpeak(!settings.alwaysSpeakEnabled) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chip_always_speak")
                        )
                        QuickModeChip(
                            label = if (settings.floatingOrbEnabled) "Moon Orb: ON" else "Float Moon Orb",
                            icon = Icons.Default.NightsStay,
                            active = settings.floatingOrbEnabled,
                            onClick = { onToggleFloatingOrb(!settings.floatingOrbEnabled) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chip_floating_orb")
                        )
                    }
                }
            }

            // SECTION 2: Active Task & Live Mid-Task Correction
            item(key = "section_live_guidance") {
                AnimatedVisibility(visible = executionStatus.isRunning || executionStatus.lastBriefReport.isNotBlank() || executionStatus.errorMessage != null) {
                    SectionContainer(
                        title = "LIVE EXECUTION & CORRECTION",
                        subtitle = "Steer Sina mid-task if anything goes off-track"
                    ) {
                        if (executionStatus.isRunning) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = LunarCyan
                                )
                                Text(
                                    text = executionStatus.currentStepText,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = LunarCyan
                                )
                            }
                            Spacer(Modifier.height(10.dp))
                        }

                        if (executionStatus.lastBriefReport.isNotBlank()) {
                            Text(
                                text = executionStatus.lastBriefReport,
                                style = MaterialTheme.typography.bodyMedium,
                                color = LunarSilver
                            )
                            Spacer(Modifier.height(8.dp))
                        }

                        executionStatus.errorMessage?.let { err ->
                            Text(
                                text = err,
                                style = MaterialTheme.typography.bodyMedium,
                                color = RoseAlert
                            )
                            Spacer(Modifier.height(8.dp))
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = guideText,
                                onValueChange = { guideText = it },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("live_correction_input"),
                                placeholder = {
                                    Text(
                                        "Guide Sina: 'No, do it this way...'",
                                        color = MutedSilver
                                    )
                                },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                keyboardActions = KeyboardActions(
                                    onSend = {
                                        if (guideText.isNotBlank()) {
                                            onInterruptAndGuide(guideText)
                                            guideText = ""
                                            keyboardController?.hide()
                                            focusManager.clearFocus()
                                        }
                                    }
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = ElectricViolet,
                                    unfocusedBorderColor = BorderGlowSlate,
                                    focusedTextColor = LunarSilver,
                                    unfocusedTextColor = LunarSilver
                                ),
                                shape = RoundedCornerShape(14.dp)
                            )
                            Button(
                                onClick = {
                                    if (guideText.isNotBlank()) {
                                        onInterruptAndGuide(guideText)
                                        guideText = ""
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                    }
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ElectricViolet,
                                    contentColor = CosmicObsidian
                                ),
                                modifier = Modifier
                                    .height(52.dp)
                                    .testTag("live_correction_send")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Apply Correction")
                            }
                        }
                    }
                }
            }

            // SECTION 3: Smart Home Automation Sections (Cleanly grouped by Room!)
            item(key = "smart_home_title_row") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "HOME AUTOMATION MATRIX",
                            style = MaterialTheme.typography.titleLarge,
                            color = LunarSilver
                        )
                        Text(
                            text = "Each button triggers its ON / OFF URL directly",
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedSilver
                        )
                    }
                    OutlinedButton(
                        onClick = onAddNewButton,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, LunarCyan),
                        modifier = Modifier.testTag("add_device_button")
                    ) {
                        Text("+ Add", color = LunarCyan)
                    }
                }
            }

            groupedButtons.forEach { (roomName, roomButtons) ->
                item(key = "room_$roomName") {
                    SectionContainer(
                        title = roomName.uppercase(),
                        subtitle = "${roomButtons.size} connected nodes"
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            roomButtons.chunked(2).forEach { rowPair ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    rowPair.forEach { button ->
                                        SmartDeviceCard(
                                            button = button,
                                            onTurnOn = { onTriggerButton(button, true) },
                                            onTurnOff = { onTriggerButton(button, false) },
                                            onEdit = { onEditButton(button) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    if (rowPair.size == 1) {
                                        Spacer(Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // SECTION 4: Brief Execution Reports
            item(key = "section_reports") {
                SectionContainer(
                    title = "BRIEF EXECUTION REPORTS",
                    subtitle = "Concise summaries after Sina completes an order"
                ) {
                    if (reports.isEmpty()) {
                        Text(
                            text = "No commands executed yet. Tap any ON/OFF button or open the Moon Orb Order Menu.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MutedSilver
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            reports.take(6).forEach { report ->
                                Surface(
                                    color = Color(0xAA0B1325),
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(
                                        1.dp,
                                        if (report.isSuccess) Color(0x4434D399) else Color(0x44FB7185)
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.Top,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (report.isSuccess) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                                            contentDescription = null,
                                            tint = if (report.isSuccess) EmeraldPulse else RoseAlert,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "[${report.source}] ${report.userInput}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = LunarCyan,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(Modifier.height(2.dp))
                                            Text(
                                                text = report.summaryReport,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = LunarSilver
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom Order Trigger Bar ("آرڈر دینے کا بٹن نیچے ہو")
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 24.dp, vertical = 14.dp)
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .height(54.dp)
                .clickable(onClick = onOpenOrderMenu)
                .testTag("bottom_order_bar"),
            shape = RoundedCornerShape(28.dp),
            color = GlassSlateHigh,
            border = BorderStroke(
                1.5.dp,
                Brush.horizontalGradient(listOf(LunarCyan, ElectricViolet))
            ),
            shadowElevation = 12.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = LunarCyan
                    )
                    Text(
                        text = "Give Order to Sina...",
                        style = MaterialTheme.typography.titleMedium,
                        color = LunarSilver
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Voice Order",
                        tint = LunarCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = "Audio Note",
                        tint = ElectricViolet,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SectionContainer(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = GlassSlate,
        border = BorderStroke(1.dp, BorderGlowSlate)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = LunarCyan,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MutedSilver
            )
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun QuickModeChip(
    label: String,
    icon: ImageVector,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .height(48.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = if (active) Color(0x3334D399) else Color(0xAA0F172A),
        border = BorderStroke(
            1.dp,
            if (active) EmeraldPulse else BorderGlowSlate
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (active) EmeraldPulse else LunarCyan,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = if (active) EmeraldPulse else LunarSilver,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SmartDeviceCard(
    button: SmartButtonEntity,
    onTurnOn: () -> Unit,
    onTurnOff: () -> Unit,
    onEdit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeBorder = if (button.isOn) LunarCyan else BorderGlowSlate
    val bgColor = if (button.isOn) Color(0xD90E223A) else Color(0xCC0B1120)

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = bgColor,
        border = BorderStroke(if (button.isOn) 1.5.dp else 1.dp, activeBorder)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            if (button.isOn) Color(0x3322D3EE) else Color(0x2294A3B8)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = iconForKey(button.iconKey),
                        contentDescription = button.name,
                        tint = if (button.isOn) LunarCyan else MutedSilver,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = onEdit,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("edit_button_${button.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Configure ${button.name}",
                        tint = MutedSilver,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Text(
                text = button.name,
                style = MaterialTheme.typography.titleMedium,
                color = LunarSilver,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = button.lastStatusNote,
                style = MaterialTheme.typography.labelSmall,
                color = if (button.isOn) EmeraldPulse else MutedSilver,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // Explicit Two-Tab ON / OFF Command Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .clickable(onClick = onTurnOn)
                        .testTag("device_on_${button.id}"),
                    shape = RoundedCornerShape(12.dp),
                    color = if (button.isOn) LunarCyan else Color(0xFF16233B)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "ON",
                            style = MaterialTheme.typography.labelLarge,
                            color = if (button.isOn) CosmicObsidian else LunarCyan
                        )
                    }
                }
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .clickable(onClick = onTurnOff)
                        .testTag("device_off_${button.id}"),
                    shape = RoundedCornerShape(12.dp),
                    color = if (!button.isOn) RoseAlert else Color(0xFF1E1A2E)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "OFF",
                            style = MaterialTheme.typography.labelLarge,
                            color = if (!button.isOn) CosmicObsidian else RoseAlert
                        )
                    }
                }
            }
        }
    }
}

private fun iconForKey(key: String): ImageVector = when (key.lowercase()) {
    "light", "lamp" -> Icons.Default.Lightbulb
    "ac" -> Icons.Default.AcUnit
    "fan" -> Icons.Default.Toys
    "gate", "lock" -> Icons.Default.Lock
    "power" -> Icons.Default.Bolt
    "memory" -> Icons.Default.Memory
    else -> Icons.Default.PowerSettingsNew
}
