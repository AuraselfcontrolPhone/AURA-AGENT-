package com.aura.agent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class AuraService : AccessibilityService() {

    companion object { var instance: AuraService? = null }

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    lateinit var overlay: ChatOverlay
    private lateinit var agent: AgentLoop

    override fun onServiceConnected() {
        instance = this
        agent = AgentLoop(this)
        overlay = ChatOverlay(this, onGoal = { agent.start(it) }, onStop = { agent.stop() })
        overlay.showHandle()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        agent.stop()
        overlay.destroy()
        scope.cancel()
        instance = null
        super.onDestroy()
    }

    /* ---------------- eyes ---------------- */

    fun snapshot(): ScreenSnapshot? {
        val roots = ArrayList<AccessibilityNodeInfo>()
        val active = rootInActiveWindow
        if (active != null && active.packageName != packageName) {
            roots.add(active)
        } else {
            val ws = windows.orEmpty()
            val app = ws.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_APPLICATION && it.root?.packageName != packageName }
                ?: ws.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_SYSTEM && it.root?.packageName != packageName }
            app?.root?.let { roots.add(it) }
        }
        windows.orEmpty().filter { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }
            .forEach { w -> w.root?.let { roots.add(it) } }
        if (roots.isEmpty()) return null
        return ScreenReader.read(roots)
    }

    /* ---------------- hands ---------------- */

    suspend fun click(n: UiNode): Boolean {
        var cur: AccessibilityNodeInfo? = n.node
        var depth = 0
        while (cur != null && depth < 6) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            depth++
        }
        return tapAt(n.bounds.exactCenterX(), n.bounds.exactCenterY())
    }

    suspend fun tapAt(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return gesture(p, 60)
    }

    suspend fun swipe(direction: String): Boolean {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        val p = Path()
        when (direction) {
            "up" -> { p.moveTo(w / 2, h * 0.72f); p.lineTo(w / 2, h * 0.28f) }
            "down" -> { p.moveTo(w / 2, h * 0.28f); p.lineTo(w / 2, h * 0.72f) }
            "left" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            "right" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            else -> return false
        }
        return gesture(p, 350)
    }

    private suspend fun gesture(path: Path, dur: Long): Boolean = suspendCancellableCoroutine { cont ->
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur))
            .build()
        val sent = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (cont.isActive) cont.resume(true) }
            override fun onCancelled(d: GestureDescription?) { if (cont.isActive) cont.resume(false) }
        }, null)
        if (!sent && cont.isActive) cont.resume(false)
    }

    fun setText(n: UiNode, text: String, submit: Boolean): Boolean {
        n.node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val ok = n.node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok && submit && Build.VERSION.SDK_INT >= 30) {
            n.node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return ok
    }

    fun paste(n: UiNode): Boolean {
        n.node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return n.node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    fun globalAction(name: String): Boolean {
        val a = when (name) {
            "home" -> GLOBAL_ACTION_HOME
            "back" -> GLOBAL_ACTION_BACK
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "lock_screen" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return false
            else -> return false
        }
        return performGlobalAction(a)
    }

    fun openApp(name: String): Boolean {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val q = name.lowercase()
        val hit = pm.queryIntentActivities(i, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(q) ||
                it.activityInfo.packageName.lowercase().contains(q)
        } ?: return false
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { startActivity(launch); true } catch (e: Exception) { false }
    }
}
