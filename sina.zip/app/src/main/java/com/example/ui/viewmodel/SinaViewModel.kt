package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.SinaAudioRecorder
import com.example.automation.SinaAccessibilityService
import com.example.automation.SinaEngineController
import com.example.automation.SinaExecutionStatus
import com.example.automation.SinaVoiceForegroundService
import com.example.data.CallRecordEntity
import com.example.data.CommandReportEntity
import com.example.data.DeviceMemoryEntity
import com.example.data.QaMessageEntity
import com.example.data.SinaSettingsState
import com.example.data.SmartButtonEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SinaTab(val label: String) {
    HOME("Home"),
    ASK("Ask & Memory"),
    CALLS("Call Guard"),
    SETTINGS("Settings")
}

class SinaViewModel(application: Application) : AndroidViewModel(application) {

    private val controller = SinaEngineController.getInstance(application)
    private val repository = controller.repository
    private val preferences = controller.preferences
    private val aiService = controller.aiService
    private val speechEngine = controller.speechEngine
    private val audioRecorder = SinaAudioRecorder(application)

    val buttons: StateFlow<List<SmartButtonEntity>> = repository.buttonsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memories: StateFlow<List<DeviceMemoryEntity>> = repository.memoriesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reports: StateFlow<List<CommandReportEntity>> = repository.reportsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val callRecords: StateFlow<List<CallRecordEntity>> = repository.callRecordsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val qaMessages: StateFlow<List<QaMessageEntity>> = repository.qaMessagesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<SinaSettingsState> = preferences.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SinaSettingsState())

    val executionStatus: StateFlow<SinaExecutionStatus> = controller.executionStatus
    val isListening: StateFlow<Boolean> = speechEngine.isListening
    val isSpeaking: StateFlow<Boolean> = speechEngine.isSpeaking
    val partialTranscript: StateFlow<String> = speechEngine.partialTranscript
    val isAccessibilityConnected: StateFlow<Boolean> = SinaAccessibilityService.isConnected

    val isRecordingAudioNote: StateFlow<Boolean> = audioRecorder.isRecording
    val audioAmplitude: StateFlow<Float> = audioRecorder.amplitude
    val audioDurationMs: StateFlow<Long> = audioRecorder.durationMs

    private val _selectedTab = MutableStateFlow(SinaTab.HOME)
    val selectedTab: StateFlow<SinaTab> = _selectedTab.asStateFlow()

    private val _isOrbMenuOpen = MutableStateFlow(false)
    val isOrbMenuOpen: StateFlow<Boolean> = _isOrbMenuOpen.asStateFlow()

    private val _streamingQaText = MutableStateFlow<String?>(null)
    val streamingQaText: StateFlow<String?> = _streamingQaText.asStateFlow()

    private val _qaError = MutableStateFlow<String?>(null)
    val qaError: StateFlow<String?> = _qaError.asStateFlow()

    private val _editingButton = MutableStateFlow<SmartButtonEntity?>(null)
    val editingButton: StateFlow<SmartButtonEntity?> = _editingButton.asStateFlow()

    private val _uiNotice = MutableStateFlow<String?>(null)
    val uiNotice: StateFlow<String?> = _uiNotice.asStateFlow()

    init {
        controller.studyDeviceImmediately()
    }

    fun selectTab(tab: SinaTab) {
        _selectedTab.value = tab
    }

    fun openOrbMenu() {
        _isOrbMenuOpen.value = true
    }

    fun closeOrbMenu() {
        _isOrbMenuOpen.value = false
    }

    fun clearNotice() {
        _uiNotice.value = null
    }

    fun triggerButton(button: SmartButtonEntity, turnOn: Boolean) {
        viewModelScope.launch {
            val result = controller.repository.triggerSmartButton(button, turnOn, source = "MANUAL")
            val stateWord = if (turnOn) "ON" else "OFF"
            _uiNotice.value = if (result.success) {
                "${button.name} turned $stateWord (${result.latencyMs}ms)"
            } else {
                "${button.name} set $stateWord · ${result.message}"
            }
        }
    }

    fun openButtonEditor(button: SmartButtonEntity?) {
        _editingButton.value = button ?: SmartButtonEntity(
            name = "",
            roomSection = "Living Lounge",
            iconKey = "light",
            onUrl = "http://192.168.1.100/on",
            offUrl = "http://192.168.1.100/off"
        )
    }

    fun closeButtonEditor() {
        _editingButton.value = null
    }

    fun saveButton(button: SmartButtonEntity) {
        viewModelScope.launch {
            repository.saveButton(button)
            _editingButton.value = null
            _uiNotice.value = "Saved ${button.name}"
        }
    }

    fun deleteButton(button: SmartButtonEntity) {
        viewModelScope.launch {
            repository.deleteButton(button)
            _editingButton.value = null
            _uiNotice.value = "Removed ${button.name}"
        }
    }

    fun submitTextOrder(orderText: String, closeMenuAfter: Boolean = true) {
        val clean = orderText.trim()
        if (clean.isEmpty()) return
        if (closeMenuAfter) {
            _isOrbMenuOpen.value = false
        }
        controller.executeOrder(clean, source = "ORB")
    }

    fun startSingleVoiceOrder(closeMenuOnResult: Boolean = true) {
        speechEngine.startSingleVoiceListen(
            onResult = { transcript ->
                if (closeMenuOnResult) {
                    _isOrbMenuOpen.value = false
                }
                controller.executeOrder(transcript, source = "VOICE")
            },
            onError = { err ->
                _uiNotice.value = err
            }
        )
    }

    fun toggleAlwaysSpeak(enabled: Boolean, hasMicPermission: Boolean) {
        if (enabled && !hasMicPermission) {
            _uiNotice.value = "Please allow Microphone permission first."
            return
        }
        viewModelScope.launch {
            preferences.setAlwaysSpeak(enabled)
            // Minimize the Moon Orb menu immediately when user activates Always Speak
            if (enabled) {
                _isOrbMenuOpen.value = false
            }
            val currentOrb = settings.value.floatingOrbEnabled
            SinaVoiceForegroundService.syncServiceState(
                getApplication(),
                alwaysSpeak = enabled,
                showOrb = currentOrb
            )
            _uiNotice.value = if (enabled) {
                "Sina Always-Speak active & minimized to Moon Orb."
            } else {
                "Always-Speak paused."
            }
        }
    }

    fun toggleFloatingOrb(enabled: Boolean) {
        val app = getApplication<Application>()
        if (enabled && !Settings.canDrawOverlays(app)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${app.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            app.startActivity(intent)
            _uiNotice.value = "Enable Display Over Other Apps to float the Moon Orb everywhere."
            return
        }
        viewModelScope.launch {
            preferences.setFloatingOrb(enabled)
            SinaVoiceForegroundService.syncServiceState(
                app,
                alwaysSpeak = settings.value.alwaysSpeakEnabled,
                showOrb = enabled
            )
        }
    }

    fun startWhatsAppAudioNote(hasMicPermission: Boolean) {
        if (!hasMicPermission) {
            _uiNotice.value = "Allow Microphone permission to record voice orders."
            return
        }
        val started = audioRecorder.startRecording(viewModelScope)
        if (!started) {
            _uiNotice.value = "Could not start audio recorder."
        }
    }

    fun sendWhatsAppAudioNote() {
        val bytes = audioRecorder.stopAndReadBytes()
        if (bytes == null) {
            _uiNotice.value = "Voice note too short — hold mic longer."
            return
        }
        _isOrbMenuOpen.value = false
        controller.executeAudioNoteOrder(bytes)
    }

    fun cancelWhatsAppAudioNote() {
        audioRecorder.cancelRecording()
    }

    fun interruptWithGuidance(guidance: String) {
        controller.interruptAndGuide(guidance)
        _uiNotice.value = "Pivoted immediately to your guidance."
    }

    fun askQuestion(question: String) {
        val clean = question.trim()
        if (clean.isEmpty()) return
        _qaError.value = null
        viewModelScope.launch {
            repository.addQaMessage(isUser = true, content = clean)
            val history = qaMessages.value.takeLast(6).joinToString("\n") {
                if (it.isUser) "User: ${it.content}" else "Sina: ${it.content}"
            }
            val memoriesSnap = repository.getTopMemoriesSync()
            val buttonsSnap = buttons.value
            _streamingQaText.value = ""
            var finalAnswer = ""
            try {
                aiService.streamQuestionAnswer(
                    question = clean,
                    historyContext = history,
                    memories = memoriesSnap,
                    buttons = buttonsSnap
                ).collect { partial ->
                    finalAnswer = partial
                    _streamingQaText.value = partial
                }
                _streamingQaText.value = null
                if (finalAnswer.isNotBlank()) {
                    repository.addQaMessage(isUser = false, content = finalAnswer)
                    speechEngine.speak(finalAnswer)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _streamingQaText.value = null
                _qaError.value = e.localizedMessage ?: "Failed to answer question."
            }
        }
    }

    fun speakText(text: String) {
        speechEngine.speak(text)
    }

    fun stopSpeaking() {
        speechEngine.stopSpeaking()
    }

    fun clearQaHistory() {
        viewModelScope.launch { repository.clearQaMessages() }
    }

    fun clearReports() {
        viewModelScope.launch { repository.clearReports() }
    }

    fun studyDeviceNow() {
        controller.studyDeviceImmediately()
        _uiNotice.value = "Studying installed apps & device shortcuts..."
    }

    fun setAutoCallSecondRing(enabled: Boolean) {
        viewModelScope.launch { preferences.setAutoCallSecondRing(enabled) }
    }

    fun setCallGreeting(text: String) {
        viewModelScope.launch { preferences.setCallGreeting(text) }
    }

    fun setOpenUrlsInBrowser(enabled: Boolean) {
        viewModelScope.launch { preferences.setOpenUrlsInBrowser(enabled) }
    }

    fun setVoiceLanguageMode(mode: String) {
        viewModelScope.launch { preferences.setVoiceLanguageMode(mode) }
    }

    fun setTtsRateAndPitch(rate: Float, pitch: Float) {
        viewModelScope.launch { preferences.setTtsRateAndPitch(rate, pitch) }
    }

    fun simulateSecondRingCallFlow(callerName: String, phone: String, callerSpeech: String) {
        viewModelScope.launch {
            val number = phone.ifBlank { "+92 300 5550192" }
            val name = callerName.ifBlank { "Home Guest" }
            // Ring 1 (unanswered)
            val ring1 = repository.recordIncomingCallRing(number, name)
            if (ring1.ringCount == 1) {
                repository.updateCallRecord(
                    ring1.copy(aiSummary = "1st missed ring logged from $name.")
                )
            }
            // Ring 2 -> Auto-Answer & Gemini Summary
            val ring2 = repository.recordIncomingCallRing(number, name)
            val msg = callerSpeech.ifBlank { "Please ask them to call me back when free, urgent delivery at the main gate." }
            val summaryRes = aiService.summarizeIncomingCall(name, ring2.ringCount, msg)
            val summary = summaryRes.getOrElse {
                "Auto-answered 2nd ring from $name: \"$msg\""
            }
            repository.updateCallRecord(
                ring2.copy(
                    wasAutoAnswered = true,
                    transcript = msg,
                    aiSummary = summary
                )
            )
            repository.addCommandReport(
                source = "CALL",
                userInput = "2nd Ring Call from $name",
                summaryReport = summary,
                actionTaken = "Auto-Answered & Summarized",
                isSuccess = true
            )
            speechEngine.speak(summary)
            _uiNotice.value = "2nd-ring call answered & summarized."
        }
    }

    fun openAccessibilitySettings() {
        val app = getApplication<Application>()
        app.startActivity(
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    fun openOverlaySettings() {
        val app = getApplication<Application>()
        app.startActivity(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${app.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    fun openAppNotificationSettings() {
        val app = getApplication<Application>()
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, app.packageName)
            }
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
        }
        app.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onCleared() {
        super.onCleared()
        audioRecorder.cancelRecording()
    }
}
