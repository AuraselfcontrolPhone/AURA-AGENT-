package com.aura.agent

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * See -> think -> act -> check, with:
 *  - instant replay of recipes that worked before (no AI call),
 *  - waiting for the screen to actually change instead of fixed delays,
 *  - stuck-solving: never repeat an action that had no effect, auto-recover (back / scroll),
 *    creative re-thinking, and finally asking you for help,
 *  - live guidance: you can speak or type a correction at any time and AURA obeys it at once.
 */
class AgentLoop(private val svc: AuraService) {
    private var job: Job? = null
    val running: Boolean get() = job?.isActive == true

    @Volatile private var waiter: CompletableDeferred<String>? = null
    private val pending = ConcurrentLinkedQueue<String>()

    companion object {
        const val MAX_STEPS = 40
        const val MAX_MS = 4 * 60_000L
        private val ACTIONS = setOf("tap", "paste", "type_text", "swipe", "global_action", "open_app")
    }

    fun start(goal: String) {
        if (running) return
        pending.clear()
        job = svc.scope.launch { run(goal) }
    }

    fun stop() { job?.cancel() }

    /** The user speaks/types a correction while AURA works (or answers AURA's question). */
    fun guide(text: String) {
        val w = waiter
        if (w != null && w.isActive) w.complete(text) else pending.add(text)
    }

    /** Waits until the screen changes. Returns true if it did. */
    private suspend fun settle(prev: Int, maxMs: Long): Boolean {
        val t0 = System.currentTimeMillis()
        delay(220)
        while (System.currentTimeMillis() - t0 < maxMs) {
            val s = svc.snapshot()
            if (s != null && s.hash() != prev) { delay(180); return true }
            delay(140)
        }
        return false
    }

    private suspend fun askUser(q: String): String? {
        val early = pending.poll()
        if (early != null) return early
        val w = CompletableDeferred<String>()
        waiter = w
        svc.overlay.askUser(q)
        val r = withTimeoutOrNull(90_000L) { w.await() }
        waiter = null
        return r
    }

    /** Replays a stored recipe step by step without asking the AI. Returns true if every step worked. */
    private suspend fun replay(arr: JSONArray, steps: JSONArray): Boolean {
        val ui = svc.overlay
        for (i in 0 until arr.length()) {
            if (pending.isNotEmpty()) return false
            val s = arr.getJSONObject(i)
            val t = s.getString("t")
            val prev = svc.snapshot()?.hash() ?: 0
            var maxWait = 2000L
            when (t) {
                "global" -> { if (!svc.globalAction(s.getString("v"))) return false }
                "open_app" -> { if (!svc.openApp(s.getString("v"))) return false; maxWait = 3000L }
                "swipe" -> { if (!svc.swipe(s.getString("v"))) return false }
                else -> {
                    val label = s.getString("label")
                    var node: UiNode? = null
                    for (a in 0 until 4) {
                        node = svc.snapshot()?.findByLabel(label)
                        if (node != null) break
                        delay(450)
                    }
                    val n = node ?: return false
                    if (t == "tap") {
                        if (SafetyGate.risky(label) && !ui.confirm("AURA یہ دبانے لگا ہے: \"$label\"۔ اجازت ہے؟")) return false
                        val chk = s.optInt("chk", 0)
                        val skip = (chk == 1 && n.isOn) || (chk == 2 && !n.isOn)
                        if (skip) { ui.log("✓ $label (پہلے سے ٹھیک ہے)"); maxWait = 300L }
                        else if (!svc.click(n)) return false
                    } else if (t == "type") {
                        if (!svc.setText(n, s.optString("text"), false)) return false
                    } else if (t == "paste") {
                        if (!svc.paste(n)) return false
                    }
                }
            }
            steps.put(s)
            ui.log("⚡ " + s.optString("label").ifEmpty { s.optString("v") })
            settle(prev, maxWait)
        }
        return true
    }

    private fun sigOf(name: String, a: JSONObject, snap: ScreenSnapshot): String = when (name) {
        "tap", "paste" -> name + ":" + (snap.byId(a.optInt("id", -1))?.label() ?: "?")
        "type_text" -> "type:" + (snap.byId(a.optInt("id", -1))?.label() ?: "?") + ":" + a.optString("text")
        "swipe" -> "swipe:" + a.optString("direction")
        "global_action" -> "global:" + a.optString("action")
        "open_app" -> "open:" + a.optString("name")
        else -> name
    }

    private suspend fun run(goal: String) {
        val ui = svc.overlay
        val mem = Memory.get(svc)
        if (Prefs.apiKey(svc).isBlank()) { ui.say("پہلے AURA ایپ کھول کر API key ڈالیں"); return }

        val t0 = System.currentTimeMillis()
        val orderId = mem.addOrder(goal)
        ui.setRunning(true)
        ui.log("▶ $goal")

        val history = ArrayList<String>()
        val steps = JSONArray()
        val guidance = ArrayList<String>()
        val noEffect = ArrayList<String>()
        val failedKeys = HashSet<String>()
        var noSave = false
        var status = "fail"
        var fast = false
        var count = 0
        var noProgress = 0
        var lastPkg = ""
        var finished = false
        val near = mem.nearRecipe(goal)

        fun takeGuidance(g: String) {
            guidance.add(g)
            noSave = true
            failedKeys.clear()
            noProgress = 0
            history.add("USER GUIDANCE: \"$g\" (obey now; it overrides the earlier plan)")
            ui.log("👂 $g")
            if (lastPkg.isNotEmpty()) mem.addNote(lastPkg, "User correction: $g")
        }

        try {
            val known = mem.findRecipeJson(goal)
            if (known != null) {
                ui.log("⚡ پرانا راستہ: بغیر سوچے چلا رہا ہوں")
                val okAll = replay(JSONArray(known), steps)
                fast = true
                if (okAll) {
                    history.add("A known recipe was replayed fully. Verify the screen now: if the goal is achieved call done(success=true) immediately.")
                } else {
                    mem.deleteRecipe(goal)
                    history.add("A known recipe was replayed partly (${steps.length()} steps) and then a step failed. Continue from the current screen.")
                }
            }

            for (step in 1..MAX_STEPS) {
                if (System.currentTimeMillis() - t0 > MAX_MS) { ui.say("وقت زیادہ ہو گیا، رک گیا"); break }
                while (true) { val g = pending.poll() ?: break; takeGuidance(g) }

                val snap = svc.snapshot()
                if (snap == null) { history.add("screen unreadable, waiting"); delay(700); continue }
                lastPkg = snap.pkg
                val h = snap.hash()

                // ---- stuck ladder ----
                if (noProgress == 3) {
                    ui.log("↩ پیچھے جا کر راستہ بدل رہا ہوں")
                    svc.globalAction("back")
                    history.add("AUTO-RECOVERY: pressed back to dismiss keyboard/dialog")
                    noProgress++
                    delay(600)
                    continue
                }
                if (noProgress == 5) {
                    ui.log("↕ اسکرین سکرول کر کے ڈھونڈ رہا ہوں")
                    svc.swipe("up")
                    history.add("AUTO-RECOVERY: scrolled down to look for the element")
                    noProgress++
                    delay(600)
                    continue
                }
                if (noProgress >= 7) {
                    val ans = askUser("مجھے آگے کا راستہ نہیں مل رہا۔ آپ بتائیں کیا کروں؟ (بولیں 🎙 یا لکھیں ✎)")
                    if (ans == null) { ui.say("کوئی جواب نہیں ملا، میں رک رہا ہوں"); break }
                    takeGuidance(ans)
                    continue
                }

                val prompt = buildPrompt(goal, near, mem.hints(snap.pkg), mem.notes(snap.pkg),
                    history.takeLast(10), snap, noProgress, noEffect.takeLast(8), guidance)
                val call = withContext(Dispatchers.IO) { AiClient.nextAction(svc, prompt, noProgress >= 2) }
                count++
                if (pending.isNotEmpty()) continue   // the user spoke while the AI was thinking: obey that first

                val a = call.input
                val name = call.name
                val sig = sigOf(name, a, snap)
                val key = "$sig@$h"
                if (name in ACTIONS && key in failedKeys) {
                    history.add("BLOCKED: \"$sig\" already had NO EFFECT on this exact screen. Choose a DIFFERENT action.")
                    noProgress++
                    continue
                }

                var line: String
                var settleMs = 2000L
                var settleIt = name in ACTIONS

                when (name) {
                    "tap" -> {
                        val n = snap.byId(a.optInt("id", -1))
                        if (n == null) {
                            line = "tap failed: no element with that id"; settleIt = false; noProgress++
                        } else {
                            val label = n.label()
                            if (SafetyGate.risky(label) && !ui.confirm("AURA یہ دبانے لگا ہے: \"$label\"۔ اجازت ہے؟")) {
                                line = "user DENIED tapping \"$label\""; settleIt = false
                            } else {
                                val chk = if (n.checkable) (if (n.isOn) 2 else 1) else 0
                                val ok = svc.click(n)
                                mem.bumpElement(snap.pkg, label)
                                if (ok) steps.put(JSONObject().put("t", "tap").put("label", label).put("pkg", snap.pkg).put("chk", chk))
                                line = "tap [${n.id}] \"$label\" -> ${if (ok) "ok" else "failed"}"
                                ui.log("👆 $label")
                            }
                        }
                    }
                    "type_text" -> {
                        val n = snap.byId(a.optInt("id", -1))
                        val text = a.optString("text")
                        if (n == null) {
                            line = "type_text failed: no element with that id"; settleIt = false; noProgress++
                        } else {
                            val ok = svc.setText(n, text, a.optBoolean("submit", false))
                            if (ok) steps.put(JSONObject().put("t", "type").put("label", n.label()).put("text", text).put("pkg", snap.pkg))
                            line = "type_text [${n.id}] \"$text\" -> ${if (ok) "ok" else "failed"}"
                            ui.log("⌨ $text")
                        }
                    }
                    "paste" -> {
                        val n = snap.byId(a.optInt("id", -1))
                        val ok = n != null && svc.paste(n)
                        if (ok && n != null) steps.put(JSONObject().put("t", "paste").put("label", n.label()).put("pkg", snap.pkg))
                        line = "paste -> ${if (ok) "ok" else "failed"}"
                        ui.log("📋 paste")
                    }
                    "swipe" -> {
                        val d = a.optString("direction", "up")
                        val ok = svc.swipe(d)
                        if (ok) steps.put(JSONObject().put("t", "swipe").put("v", d))
                        line = "swipe $d -> ${if (ok) "ok" else "failed"}"
                        ui.log("↕ swipe $d")
                    }
                    "global_action" -> {
                        val act = a.optString("action", "home")
                        val ok = svc.globalAction(act)
                        if (ok) steps.put(JSONObject().put("t", "global").put("v", act))
                        line = "global_action $act -> ${if (ok) "ok" else "failed"}"
                        ui.log("⚙ $act")
                    }
                    "open_app" -> {
                        val nm = a.optString("name")
                        val ok = svc.openApp(nm)
                        if (ok) steps.put(JSONObject().put("t", "open_app").put("v", nm))
                        line = "open_app \"$nm\" -> ${if (ok) "launched" else "app not found"}"
                        ui.log("📱 $nm")
                        settleMs = 3500L
                    }
                    "wait" -> {
                        val s = a.optInt("seconds", 2).coerceIn(1, 5)
                        line = "waited ${s}s"
                        delay(s * 1000L)
                    }
                    "remember" -> {
                        mem.addNote(snap.pkg, a.optString("note"))
                        line = "remembered"
                    }
                    "ask_user" -> {
                        val q = a.optString("question", "آپ بتائیں کیا کروں؟")
                        val ans = askUser(q)
                        if (ans == null) { ui.say("کوئی جواب نہیں ملا، میں رک رہا ہوں"); break }
                        takeGuidance(ans)
                        line = "asked the user: \"$q\" -> \"$ans\""
                    }
                    "confirm" -> {
                        val q = a.optString("question", "جاری رکھوں؟")
                        val yes = ui.confirm(q)
                        line = "confirm \"$q\" -> user said ${if (yes) "YES" else "NO"}"
                    }
                    "answer" -> {
                        svc.replyChat(a.optString("text"))
                        status = "ok"; finished = true; noSave = true
                        line = "answered"
                    }
                    "schedule" -> {
                        val g = a.optString("goal")
                        val hour = a.optInt("hour", 0).coerceIn(0, 23)
                        val min = a.optInt("minute", 0).coerceIn(0, 59)
                        val daily = a.optBoolean("daily", true)
                        val s = mem.addSchedule(g, hour, min, daily)
                        Scheduler.arm(svc, s)
                        svc.reply("⏰ قاعدہ محفوظ: " + String.format("%02d:%02d", hour, min) + (if (daily) " روزانہ" else "") + " — " + g)
                        status = "ok"; finished = true; noSave = true
                        line = "scheduled"
                    }
                    "done" -> {
                        val ok = a.optBoolean("success", true)
                        svc.reply((if (ok) "✅ " else "⚠ ") + a.optString("message", "ہو گیا"))
                        if (ok && !noSave && steps.length() > 0) mem.saveRecipe(goal, steps.toString())
                        status = if (ok) "ok" else "fail"
                        finished = true
                        line = "done"
                    }
                    else -> line = "unknown tool"
                }

                if (finished) break

                if (settleIt) {
                    val changed = settle(h, settleMs)
                    if (changed) {
                        noProgress = 0
                    } else {
                        failedKeys.add(key)
                        noEffect.add(sig)
                        noProgress++
                        line += " (NO EFFECT: screen did not change)"
                    }
                }
                history.add("$step. $line")
            }
            if (!finished) svc.reply("⚠ کام مکمل نہیں ہو سکا۔ آپ مجھے بتا دیں کہ کہاں اٹکا ہوں تو میں دوبارہ کوشش کروں گا۔")
        } catch (e: CancellationException) {
            status = "stopped"
            ui.log("⏹ آپ نے روک دیا")
            throw e
        } catch (e: Exception) {
            ui.say("خرابی: ${e.message}")
        } finally {
            mem.finishOrder(orderId, status, System.currentTimeMillis() - t0, count, fast)
            ui.setRunning(false)
        }
    }

    private fun buildPrompt(
        goal: String, near: String?, hints: String, notes: String,
        history: List<String>, snap: ScreenSnapshot, noProgress: Int,
        noEffect: List<String>, guidance: List<String>
    ): String {
        val sb = StringBuilder()
        sb.append("GOAL: ").append(goal).append("\n\n")
        if (guidance.isNotEmpty()) {
            sb.append("USER GUIDANCE (HIGHEST PRIORITY, newest last):\n")
            guidance.forEach { sb.append("- ").append(it).append('\n') }
            sb.append('\n')
        }
        if (near != null) sb.append("SIMILAR EARLIER RECIPE (may help):\n").append(near).append("\n\n")
        if (notes.isNotEmpty()) sb.append("NOTES about ${snap.pkg}:\n").append(notes).append("\n\n")
        if (hints.isNotEmpty()) sb.append("LEARNED ELEMENTS in ${snap.pkg}: ").append(hints).append("\n\n")
        sb.append("HISTORY:\n").append(if (history.isEmpty()) "(none yet)" else history.joinToString("\n")).append("\n\n")
        if (noEffect.isNotEmpty()) {
            sb.append("NO-EFFECT ACTIONS (do not repeat on the same screen):\n")
            noEffect.forEach { sb.append("- ").append(it).append('\n') }
            sb.append('\n')
        }
        if (noProgress >= 2) sb.append("WARNING: you are stuck ($noProgress steps without progress). Think differently: dismiss keyboard/popup (back), scroll, use another element/route, or ask_user.\n\n")
        sb.append("CURRENT SCREEN (package ${snap.pkg}):\n").append(snap.toPrompt())
        return sb.toString()
    }
}
