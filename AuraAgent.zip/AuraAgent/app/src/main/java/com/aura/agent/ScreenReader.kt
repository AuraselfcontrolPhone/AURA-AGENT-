package com.aura.agent

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

class UiNode(val id: Int, val node: AccessibilityNodeInfo) {
    val text: String = node.text?.toString()?.trim().orEmpty()
    val desc: String = node.contentDescription?.toString()?.trim().orEmpty()
    val viewId: String = node.viewIdResourceName.orEmpty()
    val cls: String = node.className?.toString()?.substringAfterLast('.').orEmpty()
    val clickable: Boolean = node.isClickable
    val editable: Boolean = node.isEditable
    val scrollable: Boolean = node.isScrollable
    val checked: Boolean = node.isCheckable && node.isChecked
    val bounds: Rect = Rect().also { node.getBoundsInScreen(it) }

    fun label(): String = text.ifEmpty { desc }.ifEmpty { viewId.substringAfter('/') }.take(60)
}

class ScreenSnapshot(val pkg: String, val nodes: List<UiNode>) {
    fun byId(id: Int): UiNode? = nodes.firstOrNull { it.id == id }

    fun hash(): Int =
        nodes.joinToString("|") { it.label() + it.bounds.flattenToString() + it.checked }.hashCode()

    fun toPrompt(): String = nodes.joinToString("\n") { n ->
        val f = ArrayList<String>()
        if (n.clickable) f.add("click")
        if (n.editable) f.add("edit")
        if (n.scrollable) f.add("scroll")
        if (n.checked) f.add("ON")
        val flags = if (f.isEmpty()) "" else " (" + f.joinToString(",") + ")"
        "[${n.id}] ${n.cls} \"${n.label()}\"$flags"
    }
}

object ScreenReader {
    private const val MAX_NODES = 140

    fun read(roots: List<AccessibilityNodeInfo>): ScreenSnapshot {
        val out = ArrayList<UiNode>()
        val pkg = roots.first().packageName?.toString().orEmpty()

        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40 || out.size >= MAX_NODES) return
            if (n.isVisibleToUser) {
                val interesting = n.isClickable || n.isEditable || n.isScrollable ||
                    !n.text.isNullOrBlank() || !n.contentDescription.isNullOrBlank()
                if (interesting) out.add(UiNode(out.size, n))
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        roots.forEach { walk(it, 0) }
        return ScreenSnapshot(pkg, out)
    }
}
