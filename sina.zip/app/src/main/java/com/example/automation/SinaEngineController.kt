package com.example.automation

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.telecom.TelecomManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.ai.SinaAiService
import com.example.ai.SinaCommandPlan
import com.example.ai.SinaSpeechEngine
import com.example.data.CallRecordEntity
import com.example.data.SinaDatabase
import com.example.data.SinaPreferences
import com.example.data.SinaRepository
import com.example.data.SmartButtonEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class SinaExecutionStatus(
    val isRunning: Boolean = false,
    val currentStepText: String = "",
    val lastBriefReport: String = "",
    val errorMessage: String? = null,
    val studiedAppsCount: Int = 0
)

class SinaEngineController private constructor(private val appContext: Context) {

    companion object {
        private const val TAG = "SinaEngine"

        @Volatile
        private var INSTANCE: SinaEngineController? = null

        fun getInstance(context: Context): SinaEngineController {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SinaEngineController(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val preferences = SinaPreferences(appContext)
    val repository: SinaRepository = SinaRepository(
        appContext,
        SinaDatabase.getInstance(appContext).sinaDao(),
        preferences
    )
    val aiService = SinaAiService()
    val speechEngine = SinaSpeechEngine(appContext)

    private val _executionStatus = MutableStateFlow(SinaExecutionStatus())
    val executionStatus: StateFlow<SinaExecutionStatus> = _executionStatus.asStateFlow()

    private var activeTaskJob: Job? = null
    private var lastActiveGoal: String = ""
    private val recentActionSignatures = ArrayDeque<String>()

    init {
        scope.launch {
            preferences.settingsFlow.collect { settings ->
                speechEngine.updateVoiceTuning(
                    rate = settings.ttsSpeechRate,
                    pitch = settings.ttsPitch,
                    langMode = settings.voiceLanguageMode
                )
            }
        }
    }

    fun studyDeviceImmediately() {
        scope.launch {
            repository.ensureDefaultButtons()
            val count = repository.studyDeviceAppsAndCapabilities()
            _executionStatus.value = _executionStatus.value.copy(
                studiedAppsCount = count,
                lastBriefReport = "Device studied: $count apps & system shortcuts indexed in memory."
            )
        }
    }

    /**
     * Processes a typed or spoken order.
     * Supports fast-path local smart home matching AND full Gemini structured planning.
     */
    fun executeOrder(
        orderText: String,
        source: String,
        liveCorrectionContext: String = ""
    ) {
        val cleanOrder = orderText.trim()
        if (cleanOrder.isEmpty()) return

        activeTaskJob?.cancel()
        lastActiveGoal = cleanOrder

        activeTaskJob = scope.launch {
            _executionStatus.value = _executionStatus.value.copy(
                isRunning = true,
                currentStepText = "Understanding: \"$cleanOrder\"",
                errorMessage = null
            )
            try {
                // Fast-path: check if user directly asked for a Smart Home button ON/OFF
                val buttons = repository.getAllButtonsSync()
                val fastMatch = tryFastSmartHomeMatch(cleanOrder, buttons)
                if (fastMatch != null && liveCorrectionContext.isBlank()) {
                    val (btn, turnOn) = fastMatch
                    val stateWord = if (turnOn) "ON" else "OFF"
                    _executionStatus.value = _executionStatus.value.copy(
                        currentStepText = "Executing ${btn.name} -> $stateWord"
                    )
                    val res = repository.triggerSmartButton(btn, turnOn, source)
                    val brief = if (res.success) {
                        "${btn.name} turned $stateWord (${res.latencyMs}ms)."
                    } else {
                        "${btn.name} switched $stateWord; webhook note: ${res.message}."
                    }
                    speechEngine.speak(brief)
                    _executionStatus.value = _executionStatus.value.copy(
                        isRunning = false,
                        currentStepText = "",
                        lastBriefReport = brief
                    )
                    return@launch
                }

                // Full Gemini AI planning with Device Memory
                val memories = repository.getTopMemoriesSync()
                val currentPkg = SinaAccessibilityService.currentPackage.value.ifBlank { appContext.packageName }
                val planResult = aiService.planTextOrder(
                    userText = cleanOrder,
                    buttons = buttons,
                    memories = memories,
                    currentForegroundPackage = currentPkg,
                    liveCorrectionContext = liveCorrectionContext
                )

                planResult.onSuccess { plan ->
                    executePlan(plan, cleanOrder, source, buttons, memories)
                }.onFailure { err ->
                    val msg = err.localizedMessage ?: "AI planning failed"
                    Log.e(TAG, "Order execution error: $msg", err)
                    _executionStatus.value = _executionStatus.value.copy(
                        isRunning = false,
                        currentStepText = "",
                        errorMessage = msg
                    )
                    speechEngine.speak("Could not process that right now: $msg")
                }
            } catch (e: CancellationException) {
                Log.i(TAG, "Task cancelled cleanly (possibly for live user correction)")
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Unexpected order error", e)
                _executionStatus.value = _executionStatus.value.copy(
                    isRunning = false,
                    currentStepText = "",
                    errorMessage = e.localizedMessage ?: "Execution error"
                )
            }
        }
    }

    /**
     * Sends WhatsApp-style recorded audio bytes directly to Gemini 3.8 Flash
     * and executes the extracted order immediately.
     */
    fun executeAudioNoteOrder(audioBytes: ByteArray) {
        activeTaskJob?.cancel()
        activeTaskJob = scope.launch {
            _executionStatus.value = _executionStatus.value.copy(
                isRunning = true,
                currentStepText = "Listening to voice note...",
                errorMessage = null
            )
            try {
                val buttons = repository.getAllButtonsSync()
                val memories = repository.getTopMemoriesSync()
                val currentPkg = SinaAccessibilityService.currentPackage.value.ifBlank { appContext.packageName }
                val planResult = aiService.planAudioOrder(
                    audioBytes = audioBytes,
                    buttons = buttons,
                    memories = memories,
                    currentForegroundPackage = currentPkg
                )
                planResult.onSuccess { plan ->
                    executePlan(plan, "[Voice Note Order]", "AUDIO_NOTE", buttons, memories)
                }.onFailure { err ->
                    val msg = err.localizedMessage ?: "Voice note analysis failed"
                    _executionStatus.value = _executionStatus.value.copy(
                        isRunning = false,
                        currentStepText = "",
                        errorMessage = msg
                    )
                    speechEngine.speak(msg)
                }
            } catch (e: CancellationException) {
                throw e
            }
        }
    }

    /**
     * Live Mid-Task Voice Correction ("اگر کام کرتے ہوئے میں اسے بول کر گائیڈ کروں کہ یہاں سے غلط کر رہے ہو ایسے کرو")
     * Cancels the current task immediately, saves the correction in Room memory, and pivots!
     */
    fun interruptAndGuide(guidance: String) {
        val cleanGuidance = guidance.trim()
        if (cleanGuidance.isEmpty()) return
        val previousGoal = lastActiveGoal.ifBlank { "Current task" }
        activeTaskJob?.cancel()
        recentActionSignatures.clear()

        scope.launch {
            repository.rememberUserCorrection(cleanGuidance, previousGoal)
            speechEngine.stopSpeaking()
            executeOrder(
                orderText = previousGoal,
                source = "VOICE",
                liveCorrectionContext = cleanGuidance
            )
        }
    }

    private suspend fun executePlan(
        plan: SinaCommandPlan,
        userInput: String,
        source: String,
        buttons: List<SmartButtonEntity>,
        memories: List<com.example.data.DeviceMemoryEntity>
    ) {
        _executionStatus.value = _executionStatus.value.copy(
            currentStepText = "Running ${plan.intentType}..."
        )

        var report = plan.briefReport.ifBlank { plan.spokenReply }
        var actionTaken = plan.intentType
        var isSuccess = true

        when (plan.intentType) {
            "SMART_HOME_ON", "SMART_HOME_OFF" -> {
                val turnOn = plan.intentType == "SMART_HOME_ON"
                val targetBtn = buttons.firstOrNull { it.id == plan.targetButtonId }
                    ?: buttons.firstOrNull {
                        userInput.contains(it.name, ignoreCase = true)
                    }
                if (targetBtn != null) {
                    val urlRes = repository.triggerSmartButton(targetBtn, turnOn, source)
                    val state = if (turnOn) "ON" else "OFF"
                    actionTaken = "${targetBtn.name} -> $state"
                    isSuccess = urlRes.success
                    report = if (urlRes.success) {
                        "${targetBtn.name} turned $state (${urlRes.latencyMs}ms)."
                    } else {
                        "${targetBtn.name} switched $state; endpoint note: ${urlRes.message}"
                    }
                } else {
                    isSuccess = false
                    report = "No matching smart device found for \"$userInput\"."
                }
            }

            "OPEN_APP" -> {
                val pkg = plan.targetAppPackage.ifBlank {
                    memories.firstOrNull {
                        it.memoryType == "APP" && userInput.contains(it.label, ignoreCase = true)
                    }?.appPackage.orEmpty()
                }
                val launchIntent = if (pkg.isNotBlank()) {
                    appContext.packageManager.getLaunchIntentForPackage(pkg)
                } else null
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    appContext.startActivity(launchIntent)
                    actionTaken = "Launched $pkg"
                    report = plan.briefReport.ifBlank { "Opened $pkg." }
                } else {
                    isSuccess = false
                    report = "App not found in device memory for \"$userInput\"."
                }
            }

            "DIAL_NUMBER" -> {
                val digits = plan.phoneNumber.filter { it.isDigit() || it == '+' }
                if (digits.isNotBlank()) {
                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    appContext.startActivity(intent)
                    actionTaken = "Dialer opened for $digits"
                    report = plan.briefReport.ifBlank { "Ready to call $digits." }
                } else {
                    isSuccess = false
                    report = "Could not extract a valid phone number."
                }
            }

            "WHATSAPP_MESSAGE" -> {
                val digits = plan.phoneNumber.filter { it.isDigit() }
                val encodedMsg = Uri.encode(plan.messageBody)
                val uri = if (digits.isNotBlank()) {
                    "https://wa.me/$digits?text=$encodedMsg"
                } else {
                    "https://api.whatsapp.com/send?text=$encodedMsg"
                }
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appContext.startActivity(intent)
                actionTaken = "WhatsApp draft ready"
                report = plan.briefReport.ifBlank { "Prepared WhatsApp message." }
            }

            "SMS_MESSAGE" -> {
                val digits = plan.phoneNumber.filter { it.isDigit() || it == '+' }
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$digits")).apply {
                    putExtra("sms_body", plan.messageBody)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appContext.startActivity(intent)
                actionTaken = "SMS draft to $digits"
                report = plan.briefReport.ifBlank { "SMS draft opened." }
            }

            "SEARCH_YOUTUBE" -> {
                val q = Uri.encode(plan.queryText.ifBlank { userInput })
                val intent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=$q")
                ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                appContext.startActivity(intent)
                actionTaken = "YouTube Search: ${plan.queryText}"
            }

            "SEARCH_WEB" -> {
                val q = Uri.encode(plan.queryText.ifBlank { userInput })
                val intent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/search?q=$q")
                ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                appContext.startActivity(intent)
                actionTaken = "Web Search: ${plan.queryText}"
            }

            "OPEN_SETTINGS" -> {
                val action = when (plan.queryText.uppercase()) {
                    "WIFI" -> Settings.ACTION_WIFI_SETTINGS
                    "BLUETOOTH" -> Settings.ACTION_BLUETOOTH_SETTINGS
                    "ACCESSIBILITY" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
                    "DISPLAY" -> Settings.ACTION_DISPLAY_SETTINGS
                    else -> Settings.ACTION_SETTINGS
                }
                val intent = Intent(action).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                appContext.startActivity(intent)
                actionTaken = "Opened $action"
            }

            "SCREEN_UI_ACTION" -> {
                val acc = SinaAccessibilityService.instance
                if (acc == null) {
                    isSuccess = false
                    report = "Enable Sina Smart Memory Accessibility service to automate third-party UI screens."
                } else {
                    val signature = "${acc.computeScreenSignature()}::${plan.uiTargetLabel}"
                    val repeated = recentActionSignatures.count { it == signature }
                    recentActionSignatures.addLast(signature)
                    if (recentActionSignatures.size > 8) recentActionSignatures.removeFirst()

                    if (repeated >= 2) {
                        // Anti-loop breaker! Ask Gemini for a fresh non-looping alternative
                        _executionStatus.value = _executionStatus.value.copy(
                            currentStepText = "Loop detected — switching strategy..."
                        )
                        val recovery = aiService.resolveStuckLoop(
                            goal = userInput,
                            failedSteps = recentActionSignatures.toList(),
                            visibleScreenLabels = acc.captureVisibleLabels(),
                            memories = memories
                        )
                        recovery.onSuccess { altPlan ->
                            if (altPlan.intentType != "SCREEN_UI_ACTION") {
                                executePlan(altPlan, userInput, source, buttons, memories)
                                return
                            } else {
                                acc.scrollForward()
                                delay(350L)
                                val clicked = acc.findAndClickLabel(altPlan.uiTargetLabel)
                                isSuccess = clicked
                                report = if (clicked) "Recovered and tapped ${altPlan.uiTargetLabel}."
                                else "Switched screen view; please guide Sina if needed."
                            }
                        }
                    } else {
                        val typed = if (plan.messageBody.isNotBlank()) acc.typeTextSmartly(plan.messageBody) else false
                        val clicked = if (plan.uiTargetLabel.isNotBlank()) acc.findAndClickLabel(plan.uiTargetLabel) else false
                        isSuccess = typed || clicked
                        if (!isSuccess) {
                            acc.scrollForward()
                        }
                        actionTaken = "UI Action: ${plan.uiTargetLabel}"
                        report = if (isSuccess) plan.briefReport.ifBlank { "Completed UI action." }
                        else "Element not visible yet; scrolled to find ${plan.uiTargetLabel}."
                    }
                }
            }

            else -> {
                // QUESTION_ANSWER
                actionTaken = "AI Answer"
                report = plan.briefReport.ifBlank { plan.spokenReply }
                if (plan.spokenReply.isNotBlank()) {
                    repository.addQaMessage(isUser = false, content = plan.spokenReply)
                }
            }
        }

        val finalReport = report.ifBlank { "Done." }
        if (plan.intentType != "SMART_HOME_ON" && plan.intentType != "SMART_HOME_OFF") {
            repository.addCommandReport(
                source = source,
                userInput = userInput,
                summaryReport = finalReport,
                actionTaken = actionTaken,
                isSuccess = isSuccess
            )
        }

        val spoken = plan.spokenReply.ifBlank { finalReport }
        speechEngine.speak(spoken)

        _executionStatus.value = _executionStatus.value.copy(
            isRunning = false,
            currentStepText = "",
            lastBriefReport = finalReport
        )
    }

    /**
     * Sub-50ms local matcher for direct smart home voice/text commands so buttons react instantly.
     */
    private fun tryFastSmartHomeMatch(
        input: String,
        buttons: List<SmartButtonEntity>
    ): Pair<SmartButtonEntity, Boolean>? {
        val lower = input.lowercase()
        val wantsOn = listOf("turn on", "switch on", " on", "chala", "khol", "آن", "چلا", "کھول").any {
            lower.contains(it)
        }
        val wantsOff = listOf("turn off", "switch off", " off", "band", "off kar", "آف", "بند").any {
            lower.contains(it)
        }
        if (wantsOn == wantsOff) return null

        val matched = buttons.firstOrNull { btn ->
            val nameMatch = lower.contains(btn.name.lowercase())
            val aliasMatch = btn.voiceAliases.split(",").any { alias ->
                val clean = alias.trim().lowercase()
                clean.isNotEmpty() && lower.contains(clean)
            }
            nameMatch || aliasMatch
        } ?: return null

        return matched to wantsOn
    }

    /**
     * Handles incoming calls:
     * 1st ring unanswered -> recorded.
     * 2nd ring from same number -> if enabled & permission granted, auto-answers, greets caller,
     * and creates a concise call report.
     */
    @SuppressLint("MissingPermission")
    fun handleIncomingCallRinging(phoneNumber: String, callerName: String = "") {
        val number = phoneNumber.ifBlank { "Unknown Caller" }
        scope.launch {
            val settings = preferences.settingsFlow.first()
            if (!settings.autoCallSecondRingEnabled) return@launch

            val record: CallRecordEntity = repository.recordIncomingCallRing(number, callerName)
            if (record.ringCount >= 2) {
                val hasAnswerPermission = ContextCompat.checkSelfPermission(
                    appContext,
                    Manifest.permission.ANSWER_PHONE_CALLS
                ) == PackageManager.PERMISSION_GRANTED

                var answered = false
                if (hasAnswerPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    try {
                        val telecom = appContext.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                        telecom.acceptRingingCall()
                        answered = true
                    } catch (e: Exception) {
                        Log.w(TAG, "acceptRingingCall failed: ${e.message}")
                    }
                }

                val summary = if (answered) {
                    "Auto-answered 2nd ring from ${record.callerName} and delivered greeting."
                } else {
                    "2nd ring detected from ${record.callerName}. Grant Answer Calls permission to auto-pickup."
                }

                repository.updateCallRecord(
                    record.copy(
                        wasAutoAnswered = answered,
                        aiSummary = summary
                    )
                )

                if (answered) {
                    delay(900L)
                    speechEngine.speak(settings.callGreetingText)
                }

                repository.addCommandReport(
                    source = "CALL",
                    userInput = "2nd Ring from ${record.callerName}",
                    summaryReport = summary,
                    actionTaken = if (answered) "Telecom Auto-Answer + Greeting" else "2nd Ring Logged",
                    isSuccess = answered
                )
            } else {
                repository.updateCallRecord(
                    record.copy(aiSummary = "1st ring detected. Sina will auto-answer if they call a 2nd time.")
                )
            }
        }
    }
}
