package com.aura.agent

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

/**
 * SAHIB main screen (opens first): futuristic home-automation dashboard.
 * Each device has two tabs, ON and OFF. ON sends the ON link, OFF sends the OFF link (in the background).
 * ⚙ on a device edits its name and both links. Every kind of thing has its own section.
 */
class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private var edit = false
    private lateinit var mem: Memory

    private fun dp(v: Int): Int = Neo.dp(this, v)
    private val glass = Color.parseColor("#B30B1030")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#02030D")
        mem = Memory.get(this)
        mem.seedDefaultsIfEmpty()

        val frame = FrameLayout(this)
        frame.addView(FuturisticBg(this), FrameLayout.LayoutParams(-1, -1))
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.layoutDirection = View.LAYOUT_DIRECTION_RTL
        content.setPadding(dp(14), dp(34), dp(14), dp(30))
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(content)
        frame.addView(sv, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
    }

    override fun onResume() {
        super.onResume()
        build()
        val svc = AuraService.instance
        if (svc != null) {
            svc.overlay.showIdle()                       // the moon appears as soon as the app opens
            if (!Prefs.getBool(this, "studied", false)) {   // study the phone once, automatically
                Prefs.setBool(this, "studied", true)
                Toast.makeText(this, "SAHIB فون کو اسٹڈی کر رہا ہے...", Toast.LENGTH_LONG).show()
                content.postDelayed({ svc.study() }, 1500)
            }
        }
    }

    /* ---------------- small UI helpers ---------------- */

    private fun tv(t: String, size: Float, color: Int): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        return v
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = Neo.pill(this, glass, Neo.stroke, 22)
        c.setPadding(dp(14), dp(12), dp(14), dp(14))
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, 0, 0, dp(14))
        c.layoutParams = p
        return c
    }

    private fun sectionTitle(text: String, icon: String): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(tv(icon, 18f, Neo.cyan))
        val t = tv("  $text", 16f, Neo.goldHi)
        t.typeface = Typeface.DEFAULT_BOLD
        row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        return row
    }

    private fun smallBtn(label: String, color: Int, click: () -> Unit): TextView {
        val b = tv(label, 13f, color)
        b.setPadding(dp(10), dp(4), dp(10), dp(4))
        b.background = Neo.pill(this, 0, Neo.stroke, 12)
        b.setOnClickListener { click() }
        return b
    }

    /* ---------------- the page ---------------- */

    private fun build() {
        content.removeAllViews()
        val svc = AuraService.instance

        // header: moon + name + edit + settings
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(OrbView(this), LinearLayout.LayoutParams(dp(56), dp(56)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(10), 0, dp(10), 0)
        val name = tv("SAHIB", 30f, Color.WHITE)
        name.typeface = Typeface.DEFAULT_BOLD
        name.letterSpacing = 0.25f
        titles.addView(name)
        val sub = tv("SMART INTELLIGENT ASSISTANT", 9f, Neo.cyan)
        sub.typeface = Typeface.MONOSPACE
        sub.letterSpacing = 0.12f
        titles.addView(sub)
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(smallBtn(if (edit) "✔ ہو گیا" else "✎ ترمیم", if (edit) Neo.green else Neo.goldHi) { edit = !edit; build() })
        val gear = smallBtn("⚙", Neo.goldHi) { startActivity(Intent(this, SettingsActivity::class.java)) }
        val gp = LinearLayout.LayoutParams(-2, -2)
        gp.setMargins(dp(8), 0, 0, 0)
        head.addView(gear, gp)
        content.addView(head)
        val hp = head.layoutParams as LinearLayout.LayoutParams
        hp.setMargins(0, 0, 0, dp(14))
        head.layoutParams = hp

        // ---- section: assistant ----
        val a = card()
        a.addView(sectionTitle("اسسٹنٹ", "◉"))
        val st = tv(if (svc != null) "● SAHIB چالو ہے" else "● SAHIB بند ہے", 14f, if (svc != null) Neo.green else Neo.red)
        st.setPadding(0, dp(6), 0, dp(4))
        a.addView(st)
        if (svc == null) {
            a.addView(smallBtn("Accessibility میں SAHIB چالو کریں", Neo.goldHi) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        } else {
            val sw = Switch(this)
            sw.text = "🎙 ہمیشہ سننا (چاند چھوٹا ہو کر سنتا رہے گا)"
            sw.setTextColor(Color.WHITE)
            sw.textSize = 15f
            sw.isChecked = svc.always
            sw.setPadding(0, dp(8), 0, dp(8))
            sw.setOnCheckedChangeListener { _, on -> svc.setAlwaysListen(on) }
            a.addView(sw)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.addView(smallBtn("چاند دکھاؤ", Neo.cyan) { svc.overlay.showIdle() })
            val r2 = smallBtn("📚 فون اسٹڈی", Neo.cyan) { Toast.makeText(this, "اسٹڈی شروع", Toast.LENGTH_SHORT).show(); svc.study() }
            val rp = LinearLayout.LayoutParams(-2, -2)
            rp.setMargins(dp(8), 0, 0, 0)
            row.addView(r2, rp)
            a.addView(row)
        }
        content.addView(a)

        // ---- device sections ----
        for (s in mem.sections()) content.addView(sectionCard(s))
        if (edit) {
            content.addView(smallBtn("＋ نیا سیکشن", Neo.goldHi) { editSection(null) })
        }

        // ---- section: calls ----
        val calls = mem.recentCalls(3)
        val c = card()
        c.addView(sectionTitle("کالز (SAHIB نے سنبھالی)", "☎"))
        if (calls.isEmpty()) {
            c.addView(tv("ابھی کوئی کال نہیں۔ ایک ہی نمبر سے دوسری بار کال آئے اور پہلی آپ نہ اٹھائیں تو SAHIB اٹھائے گا۔", 12f, Neo.dim))
        } else {
            for (k in calls) {
                c.addView(tv("📞 " + (if (k.name.isNotBlank()) k.name else k.number), 14f, Color.WHITE))
                c.addView(tv(k.summary, 12f, Neo.cyan))
            }
        }
        content.addView(c)

        // ---- section: rules ----
        val rules = mem.schedules()
        val r = card()
        r.addView(sectionTitle("قوانین (وقت پر خود چلیں)", "⏰"))
        if (rules.isEmpty()) r.addView(tv("SAHIB سے کہیں: \"روز رات 11 بجے ڈیٹا بند کرو\"", 12f, Neo.dim))
        for (x in rules) r.addView(tv(String.format("%02d:%02d  ", x.hour, x.min) + x.goal, 13f, Color.WHITE))
        content.addView(r)

        val tip = tv("آواز سے: \"کمرے کی لائٹ آن کرو\"، \"سب لائٹس بند کرو\"۔ ایپ بند ہو تب بھی چلتا ہے۔", 11f, Neo.dim)
        tip.setPadding(dp(6), dp(4), dp(6), 0)
        content.addView(tip)
    }

    private fun sectionCard(s: Memory.Section): LinearLayout {
        val c = card()
        val head = sectionTitle(s.name, "▣")
        if (edit) {
            head.addView(smallBtn("＋", Neo.green) { editDevice(null, s.id) })
            val rn = smallBtn("✎", Neo.goldHi) { editSection(s) }
            val rp = LinearLayout.LayoutParams(-2, -2)
            rp.setMargins(dp(6), 0, 0, 0)
            head.addView(rn, rp)
        }
        c.addView(head)

        val devs = mem.devices(s.id)
        if (devs.isEmpty()) c.addView(tv("اس سیکشن میں ابھی کوئی بٹن نہیں۔ ✎ دبا کر ＋ سے بٹن بنائیں۔", 12f, Neo.dim))
        var i = 0
        while (i < devs.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val rp = LinearLayout.LayoutParams(-1, -2)
            rp.setMargins(0, dp(10), 0, 0)
            row.layoutParams = rp
            for (j in 0 until 2) {
                val lp = LinearLayout.LayoutParams(0, -2, 1f)
                lp.setMargins(if (j == 0) 0 else dp(10), 0, 0, 0)
                if (i + j < devs.size) row.addView(tile(devs[i + j]), lp) else row.addView(View(this), lp)
            }
            c.addView(row)
            i += 2
        }
        return c
    }

    /** A device button: name + two tabs, ON and OFF. */
    private fun tile(d: Memory.Device): View {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.background = Neo.pill(this, Color.parseColor("#1AFFFFFF"), if (d.state == 1) Neo.cyan else Neo.stroke, 16)
        t.setPadding(dp(10), dp(10), dp(10), dp(10))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val n = tv(d.name, 14f, Color.WHITE)
        n.typeface = Typeface.DEFAULT_BOLD
        n.maxLines = 2
        top.addView(n, LinearLayout.LayoutParams(0, -2, 1f))
        val gear = tv("⚙", 16f, Neo.dim)
        gear.setPadding(dp(8), 0, 0, 0)
        gear.setOnClickListener { editDevice(d, d.section) }
        top.addView(gear)
        t.addView(top)

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        val tp = LinearLayout.LayoutParams(-1, -2)
        tp.setMargins(0, dp(10), 0, 0)
        tabs.layoutParams = tp
        tabs.addView(tab("ON", d, true), LinearLayout.LayoutParams(0, -2, 1f))
        val offLp = LinearLayout.LayoutParams(0, -2, 1f)
        offLp.setMargins(dp(8), 0, 0, 0)
        tabs.addView(tab("OFF", d, false), offLp)
        t.addView(tabs)
        return t
    }

    private fun tab(label: String, d: Memory.Device, on: Boolean): TextView {
        val active = (d.state == 1 && on) || (d.state == 2 && !on)
        val v = tv(label, 14f, if (active) Color.WHITE else Neo.text)
        v.gravity = Gravity.CENTER
        v.typeface = Typeface.DEFAULT_BOLD
        v.setPadding(0, dp(8), 0, dp(8))
        v.background = if (active) Neo.pill(this, if (on) Neo.gold else Color.parseColor("#3A4270"), 0, 12) else Neo.pill(this, 0, Neo.stroke, 12)
        v.setOnClickListener { trigger(d, on, v) }
        return v
    }

    private fun trigger(d: Memory.Device, on: Boolean, v: TextView) {
        v.text = "..."
        thread {
            val r = HomeAuto.runNow(this, d, on)
            runOnUiThread {
                Toast.makeText(this, (if (r.ok) "✓ " else "✗ ") + d.name + (if (on) " ON" else " OFF") + (if (r.ok) "" else "  (" + r.msg + ")"), Toast.LENGTH_SHORT).show()
                build()
            }
        }
    }

    /* ---------------- editors ---------------- */

    private fun dialog(): AlertDialog.Builder = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)

    private fun field(hintText: String, value: String): EditText {
        val e = EditText(this)
        e.hint = hintText
        e.setText(value)
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Neo.dim)
        e.textSize = 14f
        e.setSingleLine(true)
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        return e
    }

    private fun editSection(s: Memory.Section?) {
        val e = field("سیکشن کا نام", s?.name ?: "")
        e.inputType = InputType.TYPE_CLASS_TEXT
        val b = dialog().setTitle(if (s == null) "نیا سیکشن" else "سیکشن").setView(e)
            .setPositiveButton("محفوظ") { _, _ ->
                val n = e.text.toString().trim()
                if (n.isNotEmpty()) { if (s == null) mem.addSection(n) else mem.renameSection(s.id, n); build() }
            }
            .setNegativeButton("منسوخ", null)
        if (s != null) b.setNeutralButton("حذف") { _, _ -> mem.deleteSection(s.id); build() }
        b.show()
    }

    /** Device editor: name + two tabs (ON link / OFF link). */
    private fun editDevice(d: Memory.Device?, sectionId: Long) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(8), dp(18), 0)
        val nameF = field("بٹن کا نام (مثلاً کمرے کی لائٹ)", d?.name ?: "")
        nameF.inputType = InputType.TYPE_CLASS_TEXT
        box.addView(nameF)

        var onUrl = d?.onUrl ?: ""
        var offUrl = d?.offUrl ?: ""
        var tabOn = true
        val urlF = field("https://...  (ON کے لیے لنک)", onUrl)
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        val tOn = tv("ON", 14f, Color.WHITE)
        val tOff = tv("OFF", 14f, Color.WHITE)
        fun paint() {
            tOn.background = if (tabOn) Neo.pill(this, Neo.gold, 0, 12) else Neo.pill(this, 0, Neo.stroke, 12)
            tOff.background = if (!tabOn) Neo.pill(this, Neo.gold, 0, 12) else Neo.pill(this, 0, Neo.stroke, 12)
            urlF.hint = if (tabOn) "https://...  (ON کے لیے لنک)" else "https://...  (OFF کے لیے لنک)"
        }
        for (t in listOf(tOn, tOff)) { t.gravity = Gravity.CENTER; t.setPadding(0, dp(8), 0, dp(8)) }
        tOn.setOnClickListener {
            if (!tabOn) { offUrl = urlF.text.toString().trim(); tabOn = true; urlF.setText(onUrl); paint() }
        }
        tOff.setOnClickListener {
            if (tabOn) { onUrl = urlF.text.toString().trim(); tabOn = false; urlF.setText(offUrl); paint() }
        }
        val l1 = LinearLayout.LayoutParams(0, -2, 1f)
        val l2 = LinearLayout.LayoutParams(0, -2, 1f)
        l2.setMargins(dp(8), 0, 0, 0)
        tabs.addView(tOn, l1)
        tabs.addView(tOff, l2)
        val tp = LinearLayout.LayoutParams(-1, -2)
        tp.setMargins(0, dp(14), 0, dp(8))
        box.addView(tabs, tp)
        box.addView(urlF)
        paint()

        val test = smallBtn("▶ اس لنک کو آزمائیں", Neo.cyan) {
            val u = urlF.text.toString().trim()
            thread {
                val r = HomeAuto.fire(u)
                runOnUiThread { Toast.makeText(this, (if (r.ok) "✓ " else "✗ ") + r.msg, Toast.LENGTH_SHORT).show() }
            }
        }
        val tsp = LinearLayout.LayoutParams(-2, -2)
        tsp.setMargins(0, dp(12), 0, 0)
        box.addView(test, tsp)
        box.addView(tv("لنک کے شروع میں POST لکھیں (جیسے: POST https://...) تو POST بھیجے گا۔ http:// اور https:// دونوں چلتے ہیں۔", 11f, Neo.dim))

        fun readBack() {
            if (tabOn) onUrl = urlF.text.toString().trim() else offUrl = urlF.text.toString().trim()
        }

        val b = dialog().setTitle(if (d == null) "نیا بٹن" else "بٹن کی سیٹنگ").setView(box)
            .setPositiveButton("محفوظ") { _, _ ->
                readBack()
                val n = nameF.text.toString().trim()
                if (n.isNotEmpty()) {
                    if (d == null) mem.addDevice(sectionId, n, onUrl, offUrl) else mem.updateDevice(d.id, n, onUrl, offUrl)
                    build()
                }
            }
            .setNegativeButton("منسوخ", null)
        if (d != null) b.setNeutralButton("حذف") { _, _ -> mem.deleteDevice(d.id); build() }
        b.show()
    }
}
