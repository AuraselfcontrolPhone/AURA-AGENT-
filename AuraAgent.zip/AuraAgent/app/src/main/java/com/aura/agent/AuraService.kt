package com.aura.agent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

class AuraService : AccessibilityService() {

    companion object { var instance: AuraService? = null }

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    lateinit var overlay: ChatOverlay
    lateinit var calls: CallAssistant
    private lateinit var agent: AgentLoop
    private var askJob: Job? = null
    private var speakJob: Job? = null
    private val chatHistory = ArrayList<Pair<String, String>>()
    private val notifs = ArrayList<String>()

    override fun onServiceConnected() {
        instance = this
        agent = AgentLoop(this)
        calls = CallAssistant(this)
        overlay = ChatOverlay(this, onGoal = { runGoal(it) }, onStop = { stopAll() }, onVoice = { onVoice(it) })
        overlay.showIdle()
        Scheduler.armAll(this)
    }

    override fun onInterrupt() {}

    /** Remembers the latest notifications so you can ask "who messaged me?". */
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) return
        val pkg = event.packageName?.toString().orEmpty()
        if (pkg == packageName) return
        val t = event.text.joinToString(" ").trim()
        if (t.isEmpty()) return
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
        notifs.add("$label: ${t.take(160)}")
        if (notifs.size > 15) notifs.removeAt(0)
    }

    override fun onDestroy() {
        agent.stop()
        overlay.destroy()
        scope.cancel()
        instance = null
        super.onDestroy()
    }

    /* ---------------- commands, questions, voice ---------------- */

    private fun isQuestion(t: String): Boolean {
        val s = t.trim().lowercase()
        val action = listOf("کھولو", "کھول دو", "کرو", "کر دو", "آن", "بند", "بھیجو", "ڈاؤنلوڈ", "ڈاؤن لوڈ", "چلاؤ", "لگاؤ", "ڈھونڈو",
            "تلاش", "کاپی", "پیسٹ", "ڈیلیٹ", "شیڈول", "روز ", "open", "turn", "send", "download", "play", "set ", "remind")
        val qWords = listOf("کیا ", "کیوں", "کیسے", "کون ", "کب ", "کہاں", "کتنا", "کتنی", "کتنے", "بتاؤ", "بتائیں", "سمجھاؤ",
            "what", "why", "how", "who", "when", "where", "tell me", "explain")
        val q = s.endsWith("؟") || s.endsWith("?") || qWords.any { s.startsWith(it) || s.contains(" $it") }
        return q && action.none { s.contains(it) }
    }

    /** Entry point for everything the user says or types. */
    fun runGoal(text: String) {
        if (calls.active) { overlay.say("ابھی کال چل رہی ہے، تھوڑی دیر بعد"); return }
        if (agent.running) { agent.guide(text); return }      // live correction while AURA works
        if (isQuestion(text)) ask(text) else agent.start(text)
    }

    fun stopAll() {
        agent.stop()
        askJob?.cancel()
        speakJob?.cancel()
        Speaker.stop()
    }

    private fun buildAskContext(q: String): String {
        val sb = StringBuilder()
        sb.append("Now: ").append(SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())).append("\n")
        if (notifs.isNotEmpty()) sb.append("Recent notifications:\n").append(notifs.takeLast(10).joinToString("\n")).append("\n")
        val calls = Memory.get(this).recentCalls(5)
        if (calls.isNotEmpty()) {
            sb.append("Recent calls handled by AURA:\n")
            calls.forEach { sb.append("- ").append(it.name.ifEmpty { it.number }).append(": ").append(it.summary).append("\n") }
        }
        val l = q.lowercase()
        if (listOf("اسکرین", "screen", "یہاں", "اس پر", "اس میں", "پڑھ", "read", "summar", "خلاصہ", "ترجمہ", "translate").any { l.contains(it) }) {
            val s = snapshot()
            if (s != null) sb.append("Text on the user's screen (").append(s.pkg).append("):\n").append(s.toPrompt()).append("\n")
        }
        return sb.toString()
    }

    private fun ask(q: String) {
        askJob?.cancel()
        askJob = scope.launch {
            overlay.setThinking(true, "سوچ رہا ہوں...")
            try {
                val ctxText = buildAskContext(q)
                val ans = withContext(Dispatchers.IO) { AiClient.ask(this@AuraService, q, ctxText, chatHistory.takeLast(6)) }
                chatHistory.add(Pair(q, ans))
                overlay.setThinking(false, "")
                replyChat(ans)
            } catch (e: CancellationException) {
                overlay.setThinking(false, "")
                throw e
            } catch (e: Exception) {
                overlay.setThinking(false, "")
                overlay.say("خرابی: ${e.message}")
            }
        }
    }

    /** Short result: small pill (and spoken if voice replies are on). */
    fun reply(text: String) {
        overlay.say(text)
        speak(text)
    }

    /** Longer answer: opens the chat so you can read it and keep talking. */
    fun replyChat(text: String) {
        overlay.say(text)
        overlay.showPanel()
        speak(text)
    }

    private fun speak(text: String) {
        if (!Prefs.speakReplies(this) || calls.active) return
        val clean = text.filter { it.isLetterOrDigit() || it.isWhitespace() || it in ".,،۔؟?!:-" }.trim()
        if (clean.isEmpty()) return
        speakJob?.cancel()
        speakJob = scope.launch { Speaker.speak(this@AuraService, clean) }
    }

    /** A voice message arrived: turn it into text, then treat it like typed text. */
    private fun onVoice(file: File) {
        scope.launch {
            overlay.setThinking(true, "آپ کی آواز سمجھ رہا ہوں...")
            try {
                val text = withContext(Dispatchers.IO) { AiClient.transcribe(this@AuraService, file) }.trim()
                file.delete()
                overlay.setThinking(false, "")
                if (text.isEmpty()) {
                    overlay.say("آواز سمجھ نہیں آئی، دوبارہ بولیں")
                } else {
                    overlay.addUser(if (agent.running) "✋ $text" else text)
                    runGoal(text)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                overlay.setThinking(false, "")
                overlay.say("آواز میں خرابی: ${e.message}")
            }
        }
    }

    /* ---------------- eyes ---------------- */

    fun snapshot(): ScreenSnapshot? {
        val roots = ArrayList<AccessibilityNodeInfo>()
        val active = rootInActiveWindow
        if (active != null && active.packageName != packageName) {
            roots.add(active)
        } else {
            val ws = windows.orEmpty()
            val app = ws.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_APPLICATION && it.root?.packageName != packageName }
                ?: ws.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_SYSTEM && it.root?.packageName != packageName }
            app?.root?.let { roots.add(it) }
        }
        windows.orEmpty().filter { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }
            .forEach { w -> w.root?.let { roots.add(it) } }
        if (roots.isEmpty()) return null
        return ScreenReader.read(roots)
    }

    /* ---------------- hands ---------------- */

    suspend fun click(n: UiNode): Boolean {
        var cur: AccessibilityNodeInfo? = n.node
        var depth = 0
        while (cur != null && depth < 6) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            depth++
        }
        return tapAt(n.bounds.exactCenterX(), n.bounds.exactCenterY())
    }

    suspend fun tapAt(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return gesture(p, 60)
    }

    suspend fun swipe(direction: String): Boolean {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        val p = Path()
        when (direction) {
            "up" -> { p.moveTo(w / 2, h * 0.72f); p.lineTo(w / 2, h * 0.28f) }
            "down" -> { p.moveTo(w / 2, h * 0.28f); p.lineTo(w / 2, h * 0.72f) }
            "left" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            "right" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            else -> return false
        }
        return gesture(p, 350)
    }

    private suspend fun gesture(path: Path, dur: Long): Boolean = suspendCancellableCoroutine { cont ->
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur))
            .build()
        val sent = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (cont.isActive) cont.resume(true) }
            override fun onCancelled(d: GestureDescription?) { if (cont.isActive) cont.resume(false) }
        }, null)
        if (!sent && cont.isActive) cont.resume(false)
    }

    fun setText(n: UiNode, text: String, submit: Boolean): Boolean {
        n.node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val ok = n.node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok && submit && Build.VERSION.SDK_INT >= 30) {
            n.node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return ok
    }

    fun paste(n: UiNode): Boolean {
        n.node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return n.node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    fun globalAction(name: String): Boolean {
        val a = when (name) {
            "home" -> GLOBAL_ACTION_HOME
            "back" -> GLOBAL_ACTION_BACK
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "lock_screen" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return false
            else -> return false
        }
        return performGlobalAction(a)
    }

    fun openApp(name: String): Boolean {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val q = name.lowercase()
        val hit = pm.queryIntentActivities(i, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(q) ||
                it.activityInfo.packageName.lowercase().contains(q)
        } ?: return false
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { startActivity(launch); true } catch (e: Exception) { false }
    }
}
