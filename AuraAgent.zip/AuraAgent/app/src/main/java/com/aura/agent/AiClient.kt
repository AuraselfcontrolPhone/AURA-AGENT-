package com.aura.agent

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * One client, two providers. If the model name contains "gemini" -> Google Gemini API (free tier works),
 * otherwise -> Anthropic Claude API.
 */
object AiClient {
    class ToolCall(val name: String, val input: JSONObject)

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    private const val SYSTEM = """You are AURA, an agent that operates an Android phone through accessibility, exactly like a careful human would.
Each turn you receive: the GOAL, optional memory (a known recipe from an earlier success and learned elements), the HISTORY of your previous actions, and the CURRENT SCREEN as a numbered list of elements.
Choose exactly ONE tool call per turn.
Rules:
- Use element ids from the CURRENT SCREEN only. Ids change every turn.
- To reach Wi-Fi, Bluetooth, flashlight, hotspot and similar toggles, use global_action quick_settings, then tap the tile. If a toggle shows ON already, do not tap it.
- To open an app, prefer open_app. If that fails, go home and tap the app icon.
- After typing in a search box, tap the search/go button or the keyboard's action key shown on screen (or set submit=true).
- If the screen did not change after your action, try something different. Never repeat the same failing action more than twice.
- If a known recipe is given, follow it but verify every step against the current screen.
- Before sending money, deleting something permanently, or changing a password, call confirm first.
- Call done when the goal is verified complete on screen, or when it is impossible (success=false). Verify before saying success.
- Write the 'message' fields for the user in Urdu, short."""

    private class P(val name: String, val type: String, val desc: String, val options: List<String>? = null)
    private class T(val name: String, val desc: String, val props: List<P>, val required: List<String>)

    private val TOOLS = listOf(
        T("tap", "Tap/click an element on screen.", listOf(P("id", "integer", "element id")), listOf("id")),
        T("type_text", "Type text into an editable element (replaces its content).",
            listOf(P("id", "integer", "element id"), P("text", "string", "text to type"),
                P("submit", "boolean", "press the keyboard action key after typing (Android 11+ only)")),
            listOf("id", "text")),
        T("paste", "Paste the clipboard into an editable element.", listOf(P("id", "integer", "element id")), listOf("id")),
        T("swipe", "Swipe on the screen. direction is the finger movement: up scrolls content down.",
            listOf(P("direction", "string", "finger direction", listOf("up", "down", "left", "right"))), listOf("direction")),
        T("global_action", "System action.",
            listOf(P("action", "string", "which", listOf("home", "back", "recents", "notifications", "quick_settings", "lock_screen"))), listOf("action")),
        T("open_app", "Launch an installed app by name (English label, e.g. YouTube, Chrome, Settings).",
            listOf(P("name", "string", "app name")), listOf("name")),
        T("wait", "Wait for the screen to load.", listOf(P("seconds", "integer", "1 to 5")), listOf("seconds")),
        T("confirm", "Ask the user yes/no before a sensitive step.", listOf(P("question", "string", "question in Urdu")), listOf("question")),
        T("done", "Finish the task.",
            listOf(P("success", "boolean", "true if goal achieved"), P("message", "string", "short Urdu message for the user")),
            listOf("success", "message"))
    )

    private fun schema(t: T, upper: Boolean): JSONObject {
        val props = JSONObject()
        t.props.forEach { p ->
            val o = JSONObject().put("type", if (upper) p.type.uppercase() else p.type).put("description", p.desc)
            if (p.options != null) o.put("enum", JSONArray(p.options))
            props.put(p.name, o)
        }
        return JSONObject().put("type", if (upper) "OBJECT" else "object")
            .put("properties", props).put("required", JSONArray(t.required))
    }

    /** Blocking call. Run on Dispatchers.IO. */
    fun nextAction(ctx: Context, userPrompt: String): ToolCall {
        val model = Prefs.model(ctx)
        return if (model.lowercase().contains("gemini")) gemini(ctx, model, userPrompt) else claude(ctx, model, userPrompt)
    }

    /* ---------------- Gemini ---------------- */

    private fun gemini(ctx: Context, model: String, userPrompt: String): ToolCall {
        val decls = JSONArray()
        TOOLS.forEach { t -> decls.put(JSONObject().put("name", t.name).put("description", t.desc).put("parameters", schema(t, true))) }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", userPrompt)))))
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", decls)))
            .put("toolConfig", JSONObject().put("functionCallingConfig", JSONObject().put("mode", "ANY")))
            .put("generationConfig", JSONObject().put("temperature", 0.2))

        val url = Prefs.baseUrl(ctx).ifBlank { "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent" }
        val req = Request.Builder().url(url)
            .header("x-goog-api-key", Prefs.apiKey(ctx))
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val txt = send(req)
        val root = JSONObject(txt)
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) error("Gemini نے جواب نہیں دیا: ${root.optJSONObject("promptFeedback") ?: txt.take(150)}")
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val fc = parts.getJSONObject(i).optJSONObject("functionCall")
                if (fc != null) return ToolCall(fc.getString("name"), fc.optJSONObject("args") ?: JSONObject())
            }
        }
        error("AI نے کوئی عمل نہیں دیا")
    }

    /* ---------------- Claude ---------------- */

    private fun claude(ctx: Context, model: String, userPrompt: String): ToolCall {
        val tools = JSONArray()
        TOOLS.forEach { t -> tools.put(JSONObject().put("name", t.name).put("description", t.desc).put("input_schema", schema(t, false))) }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 1024)
            .put("system", SYSTEM)
            .put("tools", tools)
            .put("tool_choice", JSONObject().put("type", "any"))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", userPrompt)))

        val url = Prefs.baseUrl(ctx).ifBlank { "https://api.anthropic.com/v1/messages" }
        val req = Request.Builder().url(url)
            .header("x-api-key", Prefs.apiKey(ctx))
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val content = JSONObject(send(req)).getJSONArray("content")
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            if (b.getString("type") == "tool_use") return ToolCall(b.getString("name"), b.getJSONObject("input"))
        }
        error("AI نے کوئی عمل نہیں دیا")
    }

    /* ---------------- shared HTTP with retry on 429/503 ---------------- */

    private fun send(req: Request): String {
        var attempt = 0
        while (true) {
            http.newCall(req).execute().use { r ->
                val txt = r.body?.string().orEmpty()
                if (r.isSuccessful) return txt
                if ((r.code == 429 || r.code == 503) && attempt < 2) {
                    attempt++
                    Thread.sleep(5000L * attempt)
                } else if (r.code == 429) {
                    error("مفت حد پوری ہو گئی، کچھ دیر بعد دوبارہ کوشش کریں")
                } else if (r.code == 400 || r.code == 401 || r.code == 403) {
                    error("API ${r.code}: key یا model کا نام چیک کریں۔ ${txt.take(160)}")
                } else {
                    error("API ${r.code}: ${txt.take(160)}")
                }
            }
        }
    }
}
