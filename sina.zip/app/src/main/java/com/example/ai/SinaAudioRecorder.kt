package com.example.ai

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

class SinaAudioRecorder(private val context: Context) {

    companion object {
        private const val TAG = "SinaAudioRecorder"
    }

    private var recorder: MediaRecorder? = null
    private var outputFile: File? = null
    private var meteringJob: Job? = null
    private var startTimeMs = 0L

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _amplitude = MutableStateFlow(0f)
    val amplitude: StateFlow<Float> = _amplitude.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    fun startRecording(scope: CoroutineScope): Boolean {
        if (_isRecording.value) return true
        return try {
            val file = File(context.cacheDir, "sina_voice_${System.currentTimeMillis()}.m4a")
            outputFile = file

            val mr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setAudioSamplingRate(16000)
            mr.setAudioEncodingBitRate(32000)
            mr.setOutputFile(file.absolutePath)
            mr.prepare()
            mr.start()

            recorder = mr
            startTimeMs = System.currentTimeMillis()
            _isRecording.value = true
            _durationMs.value = 0L

            meteringJob?.cancel()
            meteringJob = scope.launch(Dispatchers.Main) {
                while (isActive && _isRecording.value) {
                    val amp = try {
                        (recorder?.maxAmplitude ?: 0) / 32767f
                    } catch (_: Exception) {
                        0f
                    }
                    _amplitude.value = amp.coerceIn(0.05f, 1f)
                    _durationMs.value = System.currentTimeMillis() - startTimeMs
                    delay(80L)
                }
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start audio recording", e)
            cancelRecording()
            false
        }
    }

    fun stopAndReadBytes(): ByteArray? {
        meteringJob?.cancel()
        _isRecording.value = false
        _amplitude.value = 0f
        return try {
            recorder?.stop()
            recorder?.release()
            recorder = null
            val file = outputFile
            outputFile = null
            if (file != null && file.exists() && file.length() > 512) {
                val bytes = file.readBytes()
                file.delete()
                bytes
            } else {
                file?.delete()
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to stop audio recording", e)
            cancelRecording()
            null
        }
    }

    fun cancelRecording() {
        meteringJob?.cancel()
        _isRecording.value = false
        _amplitude.value = 0f
        _durationMs.value = 0L
        try {
            recorder?.stop()
        } catch (_: Exception) {
        }
        try {
            recorder?.release()
        } catch (_: Exception) {
        }
        recorder = null
        outputFile?.delete()
        outputFile = null
    }
}
