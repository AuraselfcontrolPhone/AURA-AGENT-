package com.aura.agent

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AgentLoop(private val svc: AuraService) {
    private var job: Job? = null
    val running: Boolean get() = job?.isActive == true

    companion object { const val MAX_STEPS = 30 }

    fun start(goal: String) {
        if (running) return
        job = svc.scope.launch { run(goal) }
    }

    fun stop() { job?.cancel() }

    private suspend fun run(goal: String) {
        val ui = svc.overlay
        val mem = Memory.get(svc)
        if (Prefs.apiKey(svc).isBlank()) { ui.log("پہلے AURA ایپ کھول کر API key ڈالیں"); return }

        ui.setRunning(true)
        ui.log("▶ $goal")
        val history = ArrayList<String>()
        val recipe = ArrayList<String>()
        val known = mem.findRecipe(goal)
        var lastHash = 0
        var stuck = 0
        var finished = false

        try {
            for (step in 1..MAX_STEPS) {
                val snap = svc.snapshot()
                if (snap == null) { history.add("screen unreadable, waiting"); delay(800); continue }

                val h = snap.hash()
                stuck = if (h == lastHash) stuck + 1 else 0
                lastHash = h

                val prompt = buildPrompt(goal, known, mem.hints(snap.pkg), history.takeLast(14), snap, stuck)
                val call = withContext(Dispatchers.IO) { AiClient.nextAction(svc, prompt) }
                val a = call.input
                var line: String
                var settle = 900L

                when (call.name) {
                    "tap" -> {
                        val n = snap.byId(a.optInt("id", -1))
                        if (n == null) {
                            line = "tap failed: no element with that id"
                        } else {
                            val label = n.label()
                            if (SafetyGate.risky(label) && !ui.confirm("AURA یہ دبانے لگا ہے: \"$label\"۔ اجازت ہے؟")) {
                                line = "user DENIED tapping \"$label\""
                            } else {
                                val ok = svc.click(n)
                                mem.bumpElement(snap.pkg, label)
                                recipe.add("tap \"$label\" in ${snap.pkg}")
                                line = "tap [${n.id}] \"$label\" -> ${if (ok) "ok" else "failed"}"
                                ui.log("👆 $label")
                            }
                        }
                    }
                    "type_text" -> {
                        val n = snap.byId(a.optInt("id", -1))
                        val text = a.optString("text")
                        if (n == null) {
                            line = "type_text failed: no element with that id"
                        } else {
                            val ok = svc.setText(n, text, a.optBoolean("submit", false))
                            recipe.add("type \"$text\" into \"${n.label()}\"")
                            line = "type_text [${n.id}] \"$text\" -> ${if (ok) "ok" else "failed"}"
                            ui.log("⌨ $text")
                        }
                    }
                    "paste" -> {
                        val n = snap.byId(a.optInt("id", -1))
                        val ok = n != null && svc.paste(n)
                        recipe.add("paste into \"${n?.label()}\"")
                        line = "paste -> ${if (ok) "ok" else "failed"}"
                        ui.log("📋 paste")
                    }
                    "swipe" -> {
                        val d = a.optString("direction", "up")
                        val ok = svc.swipe(d)
                        recipe.add("swipe $d")
                        line = "swipe $d -> ${if (ok) "ok" else "failed"}"
                        ui.log("↕ swipe $d")
                    }
                    "global_action" -> {
                        val act = a.optString("action", "home")
                        val ok = svc.globalAction(act)
                        recipe.add("global $act")
                        line = "global_action $act -> ${if (ok) "ok" else "failed"}"
                        ui.log("⚙ $act")
                        settle = 1200
                    }
                    "open_app" -> {
                        val name = a.optString("name")
                        val ok = svc.openApp(name)
                        recipe.add("open_app $name")
                        line = "open_app \"$name\" -> ${if (ok) "launched" else "app not found"}"
                        ui.log("📱 $name")
                        settle = 1800
                    }
                    "wait" -> {
                        val s = a.optInt("seconds", 2).coerceIn(1, 5)
                        line = "waited ${s}s"
                        settle = s * 1000L
                    }
                    "confirm" -> {
                        val q = a.optString("question", "جاری رکھوں؟")
                        val yes = ui.confirm(q)
                        line = "confirm \"$q\" -> user said ${if (yes) "YES" else "NO"}"
                    }
                    "done" -> {
                        val ok = a.optBoolean("success", true)
                        ui.log((if (ok) "✅ " else "⚠ ") + a.optString("message", "ہو گیا"))
                        if (ok) mem.saveRecipe(goal, recipe)
                        finished = true
                        line = "done"
                    }
                    else -> line = "unknown tool"
                }

                if (finished) break
                if (stuck >= 1) line += " (screen did not change before this step)"
                history.add("${step}. $line")
                delay(settle)
            }
            if (!finished) ui.log("⚠ ${MAX_STEPS} سٹیپ میں مکمل نہیں ہوا، رک گیا")
        } catch (e: CancellationException) {
            ui.log("⏹ آپ نے روک دیا")
            throw e
        } catch (e: Exception) {
            ui.log("خرابی: ${e.message}")
        } finally {
            ui.setRunning(false)
        }
    }

    private fun buildPrompt(
        goal: String, recipe: String?, hints: String,
        history: List<String>, snap: ScreenSnapshot, stuck: Int
    ): String {
        val sb = StringBuilder()
        sb.append("GOAL: ").append(goal).append("\n\n")
        if (recipe != null) sb.append("KNOWN RECIPE (worked before, verify each step):\n").append(recipe).append("\n\n")
        if (hints.isNotEmpty()) sb.append("LEARNED ELEMENTS in ${snap.pkg}: ").append(hints).append("\n\n")
        sb.append("HISTORY:\n").append(if (history.isEmpty()) "(none yet)" else history.joinToString("\n")).append("\n\n")
        if (stuck >= 2) sb.append("WARNING: the screen has not changed for $stuck steps. Try a different approach.\n\n")
        sb.append("CURRENT SCREEN (package ${snap.pkg}):\n").append(snap.toPrompt())
        return sb.toString()
    }
}
