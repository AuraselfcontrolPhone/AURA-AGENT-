package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.KeyboardHide
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.DeviceMemoryEntity
import com.example.data.QaMessageEntity
import com.example.ui.theme.BorderGlowSlate
import com.example.ui.theme.CosmicObsidian
import com.example.ui.theme.DeepSpaceNavy
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.GlassSlate
import com.example.ui.theme.LunarCyan
import com.example.ui.theme.LunarSilver
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.RoseAlert

@Composable
fun AssistantScreen(
    qaMessages: List<QaMessageEntity>,
    streamingQaText: String?,
    qaError: String?,
    isSpeaking: Boolean,
    memories: List<DeviceMemoryEntity>,
    onAskQuestion: (String) -> Unit,
    onSpeakText: (String) -> Unit,
    onStopSpeaking: () -> Unit,
    onClearQa: () -> Unit,
    onStudyDevice: () -> Unit,
    modifier: Modifier = Modifier
) {
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current

    var questionInput by remember { mutableStateOf("") }
    var isFocused by remember { mutableStateOf(false) }
    var memoryFilter by remember { mutableStateOf("ALL") }

    val filteredMemories = remember(memories, memoryFilter) {
        if (memoryFilter == "ALL") memories
        else memories.filter { it.memoryType == memoryFilter }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // SECTION A: Ask Sina Anything (Q&A)
            item(key = "qa_section") {
                SectionContainer(
                    title = "ASK SINA · AI Q&A",
                    subtitle = "Ask questions in Urdu, Roman Urdu, or English"
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isSpeaking) {
                            Surface(
                                modifier = Modifier
                                    .clickable(onClick = onStopSpeaking)
                                    .padding(end = 8.dp),
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0x33FB7185)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Stop, contentDescription = null, tint = RoseAlert, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Stop Voice", style = MaterialTheme.typography.labelSmall, color = RoseAlert)
                                }
                            }
                        }
                        IconButton(onClick = onClearQa) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "Clear Q&A", tint = MutedSilver)
                        }
                    }

                    if (qaMessages.isEmpty() && streamingQaText == null) {
                        Text(
                            text = "Ask Sina anything — tech help, Urdu/English answers, device locations, or smart home status.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MutedSilver
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            qaMessages.takeLast(12).forEach { msg ->
                                QaBubble(
                                    isUser = msg.isUser,
                                    text = msg.content,
                                    onSpeak = { onSpeakText(msg.content) }
                                )
                            }
                            if (streamingQaText != null) {
                                QaBubble(
                                    isUser = false,
                                    text = streamingQaText.ifBlank { "Thinking..." },
                                    onSpeak = {}
                                )
                            }
                        }
                    }

                    qaError?.let { err ->
                        Spacer(Modifier.height(8.dp))
                        Text(err, style = MaterialTheme.typography.bodyMedium, color = RoseAlert)
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = questionInput,
                            onValueChange = { questionInput = it },
                            modifier = Modifier
                                .weight(1f)
                                .onFocusChanged { isFocused = it.isFocused }
                                .testTag("qa_input"),
                            placeholder = { Text("Ask Sina a question...", color = MutedSilver) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (questionInput.isNotBlank()) {
                                        onAskQuestion(questionInput)
                                        questionInput = ""
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                    }
                                }
                            ),
                            trailingIcon = {
                                if (isFocused) {
                                    IconButton(onClick = {
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                    }) {
                                        Icon(Icons.Default.KeyboardHide, contentDescription = "Hide Keyboard", tint = MutedSilver)
                                    }
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = LunarCyan,
                                unfocusedBorderColor = BorderGlowSlate,
                                focusedTextColor = LunarSilver,
                                unfocusedTextColor = LunarSilver,
                                focusedContainerColor = DeepSpaceNavy,
                                unfocusedContainerColor = DeepSpaceNavy
                            ),
                            shape = RoundedCornerShape(16.dp)
                        )
                        IconButton(
                            onClick = {
                                if (questionInput.isNotBlank()) {
                                    onAskQuestion(questionInput)
                                    questionInput = ""
                                    keyboardController?.hide()
                                    focusManager.clearFocus()
                                }
                            },
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .testTag("qa_send_button")
                        ) {
                            Surface(color = LunarCyan, shape = CircleShape, modifier = Modifier.fillMaxSize()) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Ask Sina", tint = CosmicObsidian)
                                }
                            }
                        }
                    }
                }
            }

            // SECTION B: Visual & Device Memory Explorer
            item(key = "memory_header") {
                SectionContainer(
                    title = "VISUAL & DEVICE MEMORY",
                    subtitle = "Everything Sina studied on launch & remembers once seen"
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${memories.size} remembered nodes",
                            style = MaterialTheme.typography.titleMedium,
                            color = LunarSilver
                        )
                        Surface(
                            modifier = Modifier
                                .clickable(onClick = onStudyDevice)
                                .testTag("memory_rescan_button"),
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF13223D),
                            border = BorderStroke(1.dp, LunarCyan)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Memory, contentDescription = null, tint = LunarCyan, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Study Phone", style = MaterialTheme.typography.labelLarge, color = LunarCyan)
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val filters = listOf("ALL", "APP", "SCREEN_ELEMENT", "CORRECTION", "FACT")
                        items(filters) { f ->
                            FilterChip(
                                selected = memoryFilter == f,
                                onClick = { memoryFilter = f },
                                label = { Text(f.replace('_', ' ')) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = LunarCyan,
                                    selectedLabelColor = CosmicObsidian,
                                    labelColor = LunarSilver
                                )
                            )
                        }
                    }
                }
            }

            items(filteredMemories.take(40), key = { it.id }) { mem ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = GlassSlate,
                    border = BorderStroke(1.dp, BorderGlowSlate)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "[${mem.memoryType}] ${mem.label}",
                                style = MaterialTheme.typography.titleMedium,
                                color = LunarSilver,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "×${mem.hitCount}",
                                style = MaterialTheme.typography.labelSmall,
                                color = LunarCyan
                            )
                        }
                        Text(
                            text = "${mem.appPackage} · ${mem.actionHint}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedSilver,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QaBubble(
    isUser: Boolean,
    text: String,
    onSpeak: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = if (isUser) Color(0x33818CF8) else Color(0xAA0B1426),
        border = BorderStroke(1.dp, if (isUser) ElectricViolet else Color(0x4422D3EE))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isUser) "You" else "Sina",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isUser) ElectricViolet else LunarCyan
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = LunarSilver
                )
            }
            if (!isUser && text.isNotBlank()) {
                IconButton(onClick = onSpeak, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Read Answer Aloud",
                        tint = LunarCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
