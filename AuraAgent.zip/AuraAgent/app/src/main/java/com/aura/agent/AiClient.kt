package com.aura.agent

import android.content.Context
import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Gemini (free tier) or Claude. Model names containing "gemini" use Gemini.
 * For Gemini, if a model is busy (503) or missing (404) the next model in the list is tried automatically.
 */
object AiClient {
    class ToolCall(val name: String, val input: JSONObject)
    private class Resp(val code: Int, val body: String)

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private const val SYSTEM = """You are AURA, an agent that operates an Android phone through accessibility, exactly like a careful and FAST human would.
Each turn you receive: the GOAL, optional memory (notes, learned elements, a similar earlier recipe), the HISTORY of your previous actions, and the CURRENT SCREEN as a numbered list of elements.
Choose exactly ONE tool call per turn.
Rules:
- Use element ids from the CURRENT SCREEN only. Ids change every turn.
- To reach Wi-Fi, Bluetooth, flashlight, hotspot and similar toggles, use global_action quick_settings, then tap the tile. Elements marked ON are already on: do not tap them again.
- To open an app, prefer open_app. If that fails, go home and tap the app icon.
- After typing in a search box, tap the search/go button or the keyboard's action key shown on screen (or set submit=true).
- If the screen did not change after your action, try something different. Never repeat the same failing action more than twice.
- Take the shortest path. Do not take extra steps.
- NEVER repeat an action listed under NO-EFFECT ACTIONS on the same screen. Always change something.
- When stuck, solve it like a smart human: (1) if a keyboard, popup, dialog or permission sheet covers the target, dismiss it with global_action back or tap its OK/Allow/Close; (2) scroll with swipe to find the element; (3) look for a different element with similar text/description, a search box, or a menu (three dots, hamburger); (4) take another route (another screen, another app, a website, Settings search); (5) go home and start again; (6) if still unsure, use ask_user and follow the user's answer.
- USER GUIDANCE is the user correcting you live. It has the HIGHEST priority and overrides the goal and your plan. Do exactly what the user says now.
- When you discover something useful about where things are in an app (for example "Wi-Fi tile is on page 2 of quick settings"), call remember once with a short note.
- If a recipe or replay history is given, follow it but verify against the current screen.
- Before sending money, deleting something permanently, or changing a password, call confirm first.
- If the goal is just a question or chat, use answer (no phone action). If the goal asks to do something later or every day at a time, use schedule.
- Call done when the goal is verified complete on screen, or when it is impossible (success=false). Verify before saying success.
- Write the 'message' fields for the user in Urdu, short."""

    private class P(val name: String, val type: String, val desc: String, val options: List<String>? = null)
    private class T(val name: String, val desc: String, val props: List<P>, val required: List<String>)

    private val TOOLS = listOf(
        T("tap", "Tap/click an element on screen.", listOf(P("id", "integer", "element id")), listOf("id")),
        T("type_text", "Type text into an editable element (replaces its content).",
            listOf(P("id", "integer", "element id"), P("text", "string", "text to type"),
                P("submit", "boolean", "press the keyboard action key after typing (Android 11+ only)")),
            listOf("id", "text")),
        T("paste", "Paste the clipboard into an editable element.", listOf(P("id", "integer", "element id")), listOf("id")),
        T("swipe", "Swipe on the screen. direction is the finger movement: up scrolls content down.",
            listOf(P("direction", "string", "finger direction", listOf("up", "down", "left", "right"))), listOf("direction")),
        T("global_action", "System action.",
            listOf(P("action", "string", "which", listOf("home", "back", "recents", "notifications", "quick_settings", "lock_screen"))), listOf("action")),
        T("open_app", "Launch an installed app by name (English label, e.g. YouTube, Chrome, Settings).",
            listOf(P("name", "string", "app name")), listOf("name")),
        T("wait", "Wait for the screen to load.", listOf(P("seconds", "integer", "1 to 5")), listOf("seconds")),
        T("remember", "Save a short useful fact about the current app/screen for future tasks.",
            listOf(P("note", "string", "short fact")), listOf("note")),
        T("answer", "Reply to the user in Urdu when the goal is only a question or chat and needs no phone action.",
            listOf(P("text", "string", "the answer, in Urdu, concise")), listOf("text")),
        T("schedule", "Create an automatic daily/one-time order that runs at a given time (24h clock).",
            listOf(P("goal", "string", "what AURA should do then, as a command"), P("hour", "integer", "0-23"),
                P("minute", "integer", "0-59"), P("daily", "boolean", "repeat every day")),
            listOf("goal", "hour", "minute", "daily")),
        T("ask_user", "Ask the user for help or a missing detail when you are unsure or stuck. The user will answer by voice or text.",
            listOf(P("question", "string", "short question in Urdu")), listOf("question")),
        T("confirm", "Ask the user yes/no before a sensitive step.", listOf(P("question", "string", "question in Urdu")), listOf("question")),
        T("done", "Finish the task.",
            listOf(P("success", "boolean", "true if goal achieved"), P("message", "string", "short Urdu message for the user")),
            listOf("success", "message"))
    )

    private fun schema(t: T, upper: Boolean): JSONObject {
        val props = JSONObject()
        t.props.forEach { p ->
            val o = JSONObject().put("type", if (upper) p.type.uppercase() else p.type).put("description", p.desc)
            if (p.options != null) o.put("enum", JSONArray(p.options))
            props.put(p.name, o)
        }
        return JSONObject().put("type", if (upper) "OBJECT" else "object")
            .put("properties", props).put("required", JSONArray(t.required))
    }

    private fun post(req: Request): Resp =
        http.newCall(req).execute().use { r -> Resp(r.code, r.body?.string().orEmpty()) }

    /** Blocking call. Run on Dispatchers.IO. */
    fun nextAction(ctx: Context, userPrompt: String, creative: Boolean = false): ToolCall {
        val model = Prefs.model(ctx)
        return if (model.lowercase().contains("gemini")) gemini(ctx, userPrompt, creative) else claude(ctx, model, userPrompt, creative)
    }

    /* ---------------- Gemini ---------------- */

    private fun geminiModels(ctx: Context): List<String> =
        (listOf(Prefs.model(ctx)) + listOf("gemini-3.7-flash", "gemini-3.1-flash-lite", "gemini-flash-latest")).distinct()

    private fun geminiCall(ctx: Context, body: JSONObject): JSONObject {
        var last = ""
        for (m in geminiModels(ctx)) {
            val url = Prefs.baseUrl(ctx).ifBlank { "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent" }
            val req = Request.Builder().url(url)
                .header("x-goog-api-key", Prefs.apiKey(ctx))
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()
            val r: Resp = try { post(req) } catch (e: IOException) { last = e.message ?: "network"; continue }
            if (r.code == 200) return JSONObject(r.body)
            last = "API ${r.code}: ${r.body.take(140)}"
            if (r.code == 404 || r.code == 429 || r.code == 500 || r.code == 503 || r.code == 504) continue
            error("key یا درخواست میں مسئلہ۔ $last")
        }
        error("سب ماڈل مصروف یا دستیاب نہیں۔ کچھ دیر بعد کوشش کریں۔ $last")
    }

    private fun gemini(ctx: Context, userPrompt: String, creative: Boolean): ToolCall {
        val decls = JSONArray()
        TOOLS.forEach { t -> decls.put(JSONObject().put("name", t.name).put("description", t.desc).put("parameters", schema(t, true))) }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", userPrompt)))))
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", decls)))
            .put("toolConfig", JSONObject().put("functionCallingConfig", JSONObject().put("mode", "ANY")))
            .put("generationConfig", JSONObject().put("temperature", if (creative) 0.8 else 0.2).put("maxOutputTokens", 512))

        val root = geminiCall(ctx, body)
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) error("Gemini نے جواب نہیں دیا")
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val fc = parts.getJSONObject(i).optJSONObject("functionCall")
                if (fc != null) return ToolCall(fc.getString("name"), fc.optJSONObject("args") ?: JSONObject())
            }
        }
        error("AI نے کوئی عمل نہیں دیا")
    }

    /** Voice message (AAC) -> text. Gemini only. */
    fun transcribe(ctx: Context, file: File): String {
        if (!Prefs.model(ctx).lowercase().contains("gemini")) error("آواز کی ریکارڈنگ کے لیے Gemini ماڈل چاہیے")
        val b64 = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
        val parts = JSONArray()
            .put(JSONObject().put("text", "Transcribe this voice message exactly as spoken. It is probably Urdu (write Urdu in Urdu script) or English. Return ONLY the transcription, nothing else."))
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/aac").put("data", b64)))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("temperature", 0.0))
        val root = geminiCall(ctx, body)
        val cands = root.optJSONArray("candidates") ?: return ""
        if (cands.length() == 0) return ""
        val ps = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text"))
        return sb.toString().trim()
    }

    /* ---------------- Claude ---------------- */

    private fun claude(ctx: Context, model: String, userPrompt: String, creative: Boolean): ToolCall {
        val tools = JSONArray()
        TOOLS.forEach { t -> tools.put(JSONObject().put("name", t.name).put("description", t.desc).put("input_schema", schema(t, false))) }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 512)
            .put("temperature", if (creative) 0.8 else 0.2)
            .put("system", SYSTEM)
            .put("tools", tools)
            .put("tool_choice", JSONObject().put("type", "any"))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", userPrompt)))

        val url = Prefs.baseUrl(ctx).ifBlank { "https://api.anthropic.com/v1/messages" }
        val req = Request.Builder().url(url)
            .header("x-api-key", Prefs.apiKey(ctx))
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        val r = post(req)
        if (r.code != 200) error("API ${r.code}: ${r.body.take(160)}")
        val content = JSONObject(r.body).getJSONArray("content")
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            if (b.getString("type") == "tool_use") return ToolCall(b.getString("name"), b.getJSONObject("input"))
        }
        error("AI نے کوئی عمل نہیں دیا")
    }

    /* ---------------- chat / Q&A ---------------- */

    private const val ASK_SYSTEM = """You are AURA, a smart, warm personal AI assistant living inside the user's phone.
Answer in the language the user used (usually Urdu, written in Urdu script). Be accurate, clear and concise (a few short sentences unless asked for detail).
You may be given extra CONTEXT (current time, recent notifications, recent calls, or the text on the user's screen). Use it when relevant.
If you do not know something or it may have changed recently, say so honestly."""

    fun ask(ctx: Context, question: String, context: String, history: List<Pair<String, String>>): String {
        val q = if (context.isBlank()) question else "CONTEXT:\n$context\n\nQUESTION: $question"
        val model = Prefs.model(ctx)
        if (model.lowercase().contains("gemini")) {
            val contents = JSONArray()
            history.forEach { h ->
                contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", h.first))))
                contents.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", h.second))))
            }
            contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", q))))
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", ASK_SYSTEM))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("temperature", 0.5).put("maxOutputTokens", 700))
            val root = geminiCall(ctx, body)
            val ps = root.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: error("جواب نہیں آیا")
            val sb = StringBuilder()
            for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text"))
            return sb.toString().trim()
        }
        val msgs = JSONArray()
        history.forEach { h ->
            msgs.put(JSONObject().put("role", "user").put("content", h.first))
            msgs.put(JSONObject().put("role", "assistant").put("content", h.second))
        }
        msgs.put(JSONObject().put("role", "user").put("content", q))
        val body = JSONObject().put("model", model).put("max_tokens", 700).put("system", ASK_SYSTEM).put("messages", msgs)
        val url = Prefs.baseUrl(ctx).ifBlank { "https://api.anthropic.com/v1/messages" }
        val req = Request.Builder().url(url).header("x-api-key", Prefs.apiKey(ctx)).header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        val r = post(req)
        if (r.code != 200) error("API ${r.code}: ${r.body.take(160)}")
        val c = JSONObject(r.body).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until c.length()) sb.append(c.getJSONObject(i).optString("text"))
        return sb.toString().trim()
    }

    /* ---------------- phone call assistant ---------------- */

    /** One turn of a live phone call: caller audio (WAV) in, JSON {transcript, reply, end_call, caller_name, summary} out. */
    fun callTurn(ctx: Context, wav: ByteArray, owner: String, brief: String, transcript: String, callerName: String): JSONObject {
        val who = if (owner.isBlank()) "the phone's owner" else owner
        val instr = """You are AURA, the AI phone assistant of $who. $who could not answer this call, so you answered. You already told the caller that you are an AI assistant.
Instructions from $who: $brief
Caller (from contacts, may be empty): $callerName
Conversation so far:
$transcript

Listen to the caller's NEW audio and answer. Rules:
- Speak natural, polite, short Urdu (1-2 sentences), like a human secretary. Never be robotic.
- Take a clear message: who is calling, what they need, and a callback number/time if relevant.
- Do not promise anything on behalf of $who beyond the instructions. Never reveal private information.
- If the caller says goodbye or the message is complete, thank them, say goodbye, and set end_call true.
Return ONLY JSON: {"transcript":"what the caller said","reply":"your spoken reply","end_call":false,"caller_name":"","summary":"one or two line summary of the whole call so far, in Urdu"}"""
        val b64 = Base64.encodeToString(wav, Base64.NO_WRAP)
        val parts = JSONArray()
            .put(JSONObject().put("text", instr))
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav").put("data", b64)))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("temperature", 0.4).put("responseMimeType", "application/json"))
        val root = geminiCall(ctx, body)
        val ps = root.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: error("جواب نہیں آیا")
        val sb = StringBuilder()
        for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text"))
        val t = sb.toString().trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return JSONObject(t)
    }

    /* ---------------- natural voice (Gemini TTS) ---------------- */

    /** Returns raw PCM (24 kHz, mono, 16-bit) or null if TTS is not available. */
    fun tts(ctx: Context, text: String): ByteArray? {
        if (Prefs.baseUrl(ctx).isNotEmpty()) return null
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject()
                .put("text", "Say in a natural, warm, clear and friendly voice, at a calm pace: $text")))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig",
                    JSONObject().put("voiceName", Prefs.voice(ctx))))))
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-tts-preview:generateContent")
            .header("x-goog-api-key", Prefs.apiKey(ctx))
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        val r = try { post(req) } catch (e: IOException) { return null }
        if (r.code != 200) return null
        val ps = JSONObject(r.body).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return null
        for (i in 0 until ps.length()) {
            val d = ps.getJSONObject(i).optJSONObject("inlineData")?.optString("data").orEmpty()
            if (d.isNotEmpty()) return Base64.decode(d, Base64.DEFAULT)
        }
        return null
    }
}
