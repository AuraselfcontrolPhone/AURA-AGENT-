package com.aura.agent

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.telephony.TelephonyManager

class PhoneReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(ctx: Context, i: Intent) {
        val state = i.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val number = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        AuraService.instance?.calls?.onPhoneState(state, number)
    }
}

/** Keeps the microphone usable while AURA handles a call. */
class CallService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("aura_call", "AURA Calls", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "aura_call")
            .setContentTitle("AURA کال سنبھال رہا ہے")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 30) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(77, n)
        } catch (e: Exception) {}
        return START_NOT_STICKY
    }
}
