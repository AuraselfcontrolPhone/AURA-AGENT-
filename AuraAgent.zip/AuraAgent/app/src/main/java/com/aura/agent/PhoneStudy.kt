package com.aura.agent

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import kotlinx.coroutines.delay

/**
 * "Study the phone": lists every installed app (opened or not) and looks at the main places
 * (Quick Settings, Settings, home screen) so the AI knows where things are and goes straight there.
 * No AI calls are used: it only reads the screen.
 */
object PhoneStudy {
    fun ready(svc: AuraService): Boolean {
        val pm = svc.getSystemService(Context.POWER_SERVICE) as PowerManager
        val km = svc.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return pm.isInteractive && !km.isKeyguardLocked
    }

    private fun collect(s: ScreenSnapshot?, out: LinkedHashSet<String>) {
        if (s == null) return
        for (n in s.nodes) {
            val l = n.label()
            if (l.isEmpty() || l.length > 32) continue
            if (n.clickable || n.checkable || n.scrollable || n.editable) {
                out.add(if (n.checkable) l + (if (n.isOn) " (ON)" else " (OFF)") else l)
            }
            if (out.size >= 60) return
        }
    }

    suspend fun run(svc: AuraService): String {
        if (!ready(svc)) return "فون لاک ہے۔ اسکرین کھول کر دوبارہ کہیں: \"فون اسٹڈی کرو\""
        val mem = Memory.get(svc)
        svc.overlay.setThinking(true, "📚 فون کی ساخت سیکھ رہا ہوں... (ہاتھ نہ لگائیں)")
        var areas = 0
        var apps = 0
        try {
            // 1) every installed app, even those never opened
            val pm = svc.packageManager
            val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { Pair(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
                .distinctBy { it.first }
            mem.replaceApps(list)
            apps = list.size

            // 2) Quick Settings (compact + expanded)
            svc.globalAction("quick_settings")
            delay(1300)
            val qs = LinkedHashSet<String>()
            collect(svc.snapshot(), qs)
            val m = svc.resources.displayMetrics
            svc.swipeRaw(m.widthPixels / 2f, 8f, m.widthPixels / 2f, m.heightPixels * 0.75f, 400)
            delay(1000)
            collect(svc.snapshot(), qs)
            if (qs.isNotEmpty()) { mem.saveMap("quick_settings (tiles)", qs.joinToString(" | ")); areas++ }
            svc.globalAction("back")
            delay(600)

            // 3) Settings app main list
            svc.globalAction("home")
            delay(800)
            if (svc.openApp("Settings")) {
                delay(2200)
                val st = LinkedHashSet<String>()
                collect(svc.snapshot(), st)
                if (st.isNotEmpty()) { mem.saveMap("settings_main (categories)", st.joinToString(" | ")); areas++ }
                svc.globalAction("back")
                delay(500)
            }

            // 4) home screen
            svc.globalAction("home")
            delay(1000)
            val hs = LinkedHashSet<String>()
            collect(svc.snapshot(), hs)
            if (hs.isNotEmpty()) { mem.saveMap("home_screen (icons)", hs.joinToString(" | ")); areas++ }
        } finally {
            svc.overlay.setThinking(false, "")
        }
        Prefs.setBool(svc, "studied", true)
        return "📚 سیکھ لیا: $apps ایپس اور $areas اہم حصے۔ اب میں سیدھا صحیح جگہ جاؤں گا۔"
    }
}
