package com.aura.agent

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Listens until someone finishes a sentence (voice activity detection). Used by calls and "always listen". */
object Mic {
    /** Returns WAV bytes, or null if nobody spoke within waitMs / the mic is not available. */
    suspend fun listen(maxMs: Long, waitMs: Long, alive: () -> Boolean): ByteArray? = withContext(Dispatchers.IO) {
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec: AudioRecord? = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf * 4)
        } catch (e: Exception) { null }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
            rec?.release()
            return@withContext null
        }
        val out = ByteArrayOutputStream()
        val buf = ShortArray(1600)
        var elapsed = 0L
        var spoke = false
        var silentMs = 0L
        var speechMs = 0L
        var chunks = 0
        var noise = 1e9
        var thr = 600.0
        rec.startRecording()
        try {
            while (alive()) {
                if (elapsed >= (if (spoke) maxMs else waitMs)) break
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) break
                var sum = 0.0
                for (i in 0 until n) sum += buf[i].toDouble() * buf[i].toDouble()
                val rms = Math.sqrt(sum / n)
                val ms = n * 1000L / rate
                elapsed += ms
                chunks++
                if (chunks <= 3) {
                    if (rms < noise) noise = rms
                    if (chunks == 3) thr = Math.max(500.0, noise * 3.0)
                    continue
                }
                if (rms > thr) { if (!spoke) elapsed = 0; spoke = true; silentMs = 0; speechMs += ms } else if (spoke) silentMs += ms
                if (spoke) {
                    for (i in 0 until n) { out.write(buf[i].toInt() and 0xFF); out.write((buf[i].toInt() shr 8) and 0xFF) }
                }
                if (spoke && silentMs >= 1200) break
            }
        } finally {
            try { rec.stop() } catch (e: Exception) {}
            rec.release()
        }
        if (!spoke || speechMs < 400) null else wav(out.toByteArray(), rate)
    }

    fun wav(pcm: ByteArray, rate: Int): ByteArray {
        val b = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()); b.putInt(36 + pcm.size); b.put("WAVE".toByteArray())
        b.put("fmt ".toByteArray()); b.putInt(16); b.putShort(1); b.putShort(1)
        b.putInt(rate); b.putInt(rate * 2); b.putShort(2); b.putShort(16)
        b.put("data".toByteArray()); b.putInt(pcm.size); b.put(pcm)
        return b.array()
    }
}
