package com.aura.agent

import android.accessibilityservice.AccessibilityService
import android.Manifest
import android.accessibilityservice.GestureDescription
import android.app.KeyguardManager
import android.os.PowerManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

class AuraService : AccessibilityService() {

    companion object { var instance: AuraService? = null }

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    lateinit var overlay: ChatOverlay
    lateinit var calls: CallAssistant
    private lateinit var agent: AgentLoop
    private var askJob: Job? = null
    private var speakJob: Job? = null
    private var listenJob: Job? = null
    @Volatile var always = false
    @Volatile private var speaking = false
    private val chatHistory = ArrayList<Pair<String, String>>()
    private val notifs = ArrayList<String>()

    override fun onServiceConnected() {
        instance = this
        agent = AgentLoop(this)
        calls = CallAssistant(this)
        overlay = ChatOverlay(this, onGoal = { runGoal(it) }, onStop = { stopAll() }, onVoice = { onVoice(it) }, onAlways = { setAlwaysListen(it) })
        overlay.showIdle()
        Scheduler.armAll(this)
        scope.launch { withContext(Dispatchers.IO) { refreshApps() } }
        if (Prefs.getBool(this, "always", false)) setAlwaysListen(true)
    }

    override fun onInterrupt() {}

    /** Remembers the latest notifications so you can ask "who messaged me?". */
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) return
        val pkg = event.packageName?.toString().orEmpty()
        if (pkg == packageName) return
        val t = event.text.joinToString(" ").trim()
        if (t.isEmpty()) return
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
        notifs.add("$label: ${t.take(160)}")
        if (notifs.size > 15) notifs.removeAt(0)
    }

    override fun onDestroy() {
        agent.stop()
        overlay.destroy()
        scope.cancel()
        instance = null
        super.onDestroy()
    }

    /* ---------------- commands, questions, voice ---------------- */

    private fun isQuestion(t: String): Boolean {
        val s = t.trim().lowercase()
        val action = listOf("کھولو", "کھول دو", "کرو", "کر دو", "آن", "بند", "بھیجو", "ڈاؤنلوڈ", "ڈاؤن لوڈ", "چلاؤ", "لگاؤ", "ڈھونڈو",
            "تلاش", "کاپی", "پیسٹ", "ڈیلیٹ", "شیڈول", "روز ", "open", "turn", "send", "download", "play", "set ", "remind")
        val qWords = listOf("کیا ", "کیوں", "کیسے", "کون ", "کب ", "کہاں", "کتنا", "کتنی", "کتنے", "بتاؤ", "بتائیں", "سمجھاؤ",
            "what", "why", "how", "who", "when", "where", "tell me", "explain")
        val q = s.endsWith("؟") || s.endsWith("?") || qWords.any { s.startsWith(it) || s.contains(" $it") }
        return q && action.none { s.contains(it) }
    }

    /** Entry point for everything the user says or types. Offline brain first, the API only when needed. */
    fun runGoal(text: String) {
        scope.launch {
            if (calls.active) { overlay.say("ابھی کال چل رہی ہے، تھوڑی دیر بعد"); return@launch }
            // 1) your devices: instant, offline, forgiving of broken speech
            val dev = withContext(Dispatchers.IO) { try { HomeAuto.handle(this@AuraService, text) } catch (e: Exception) { null } }
            if (dev != null) { report(text, dev); return@launch }
            // 2) facts the phone knows by itself: battery, time, date, storage, messages, diary, contacts, missed calls
            val fact = withContext(Dispatchers.IO) { try { LocalFacts.answer(this@AuraService, text) } catch (e: Exception) { null } }
            if (fact != null) { replyChat(fact); return@launch }
            // 2b) phone actions that need no AI: Wi-Fi, hotspot, data, Bluetooth, torch, lock screen, open an app...
            val act = try { LocalActions.handle(this@AuraService, text) } catch (e: Exception) { null }
            if (act != null) { if (act.isNotEmpty()) report(text, act); return@launch }
            // 3) study the phone
            val low = text.lowercase()
            if (text.contains("اسٹڈی") || low.contains("study")) {
                if (!agent.running) reply(PhoneStudy.run(this@AuraService))
                return@launch
            }
            // 4) live correction while SINA works
            if (agent.running) { agent.guide(text); return@launch }
            // 5) a question
            if (isQuestion(text)) { askSmart(text); return@launch }
            // 6) a command: a similar earlier order (even if said badly) is replayed offline; new ones need the AI
            val mem = Memory.get(this@AuraService)
            val similar = mem.bestOrder(text)
            val goal = if (similar != null && mem.findRecipeJson(similar) != null) similar else text
            if (!prepareScreen()) return@launch
            agent.start(goal)
        }
    }

    /** Wakes the screen and swipes away a plain lock screen. A PIN/pattern lock is never opened by SINA (security). */
    suspend fun prepareScreen(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!pm.isInteractive) {
            @Suppress("DEPRECATION")
            val wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "sina:wake")
            wl.acquire(15_000L)
            delay(700)
        }
        if (km.isKeyguardLocked) {
            if (km.isDeviceSecure) {
                reply("🔒 فون پن/پاس ورڈ سے لاک ہے۔ حفاظت کے لیے میں اسے خود نہیں کھولتا۔ ان لاک کر کے دوبارہ کہیں۔")
                return false
            }
            val m = resources.displayMetrics
            swipeRaw(m.widthPixels / 2f, m.heightPixels * 0.85f, m.widthPixels / 2f, m.heightPixels * 0.2f, 300)
            delay(700)
        }
        return true
    }

    private fun askSmart(q: String) {
        val mem = Memory.get(this)
        val cached = mem.cachedAnswer(q)
        if (cached != null) { replyChat("📚 " + cached); return }          // asked before: no internet, no API
        val kb = Knowledge.search(this, q)
        if (!Net.aiOk(this)) {
            if (kb.isNotEmpty()) replyChat("📚 " + kb.first())
            else overlay.say("📴 آف لائن یا کوٹہ ختم: اس کا جواب میرے پاس محفوظ نہیں۔ نیٹ آنے پر پوچھیں، پھر یہ ہمیشہ کے لیے محفوظ ہو جائے گا۔")
            return
        }
        ask(q, kb)
    }

    /** Studies the whole phone (apps + Quick Settings + Settings + home screen). */
    fun study() {
        scope.launch { if (!agent.running && !calls.active) reply(PhoneStudy.run(this@AuraService)) }
    }

    private fun refreshApps() {
        try {
            val pm = packageManager
            val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { Pair(it.activityInfo.packageName, it.loadLabel(pm).toString()) }.distinctBy { it.first }
            Memory.get(this).replaceApps(list)
        } catch (e: Exception) {}
    }

    /** "Always speak": the moon shrinks, SINA keeps listening, understands, acts, answers and reports. */
    fun setAlwaysListen(on: Boolean) {
        if (on && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            overlay.say("مائیک کی اجازت نہیں ہے۔ SINA ایپ میں 'اجازتیں دیں' دبائیں۔")
            return
        }
        always = on
        Prefs.setBool(this, "always", on)
        listenJob?.cancel()
        overlay.setListening(on)
        if (on) {
            try { startForegroundService(Intent(this, CallService::class.java).putExtra("title", "SINA سن رہا ہے")) } catch (e: Exception) {}
            listenJob = scope.launch { listenLoop() }
            overlay.say("🎙 میں سن رہا ہوں۔ حکم دیں۔")
        } else {
            try { stopService(Intent(this, CallService::class.java)) } catch (e: Exception) {}
            overlay.say("🎙 سننا بند کر دیا")
        }
    }

    private val wakeWords = listOf("سینا", "sina", "سنا", "سینہ", "سیٹا", "sena", "seena", "cena")
    private var awaitUntil = 0L

    private fun onHeard(text: String) {
        var t = text.trim()
        if (Prefs.wakeWord(this) && !agent.running) {
            val low = t.lowercase()
            val w = wakeWords.firstOrNull { low.contains(it) }
            val awaiting = System.currentTimeMillis() < awaitUntil
            if (w == null && !awaiting) return                    // not meant for me
            if (w != null) t = low.replace(w, " ").trim()
            if (t.isBlank()) {
                awaitUntil = System.currentTimeMillis() + 8000L
                overlay.say("🎙 جی؟ بولیں")
                speak("جی؟")
                return
            }
            awaitUntil = 0L
        }
        overlay.addUser(if (agent.running) "✋ $t" else t)
        runGoal(t)
    }

    private suspend fun listenLoop() {
        var fails = 0
        while (always) {
            if (calls.active || speaking) { delay(400); continue }
            if (Stt.available(this)) {
                // the phone's own recognition: free, offline if the Urdu pack is installed
                val pref = Prefs.aiMode(this) != "online" && !Prefs.getBool(this, "noOfflinePack", false)
                val text = Stt.listenOnce(this, pref)?.trim()
                if (pref && (Stt.lastError == 12 || Stt.lastError == 13)) {
                    Prefs.setBool(this, "noOfflinePack", true)
                    overlay.say("📴 آف لائن اردو آواز کا پیک نہیں ملا، اس لیے فون کی عام (مفت) پہچان لگا رہا ہوں۔ آف لائن کے لیے: Settings > Google > Voice > Offline speech recognition > اردو ڈاؤنلوڈ کریں۔")
                }
                if (text.isNullOrEmpty()) { fails++; delay(if (fails > 5) 1500L else 250L); continue }
                fails = 0
                onHeard(text)
            } else if (Net.aiOk(this)) {
                val t0 = System.currentTimeMillis()
                val wav = Mic.listen(15_000L, 25_000L) { always && !calls.active && !speaking }
                if (wav == null) { if (System.currentTimeMillis() - t0 < 800) delay(1500); continue }
                try {
                    val text = withContext(Dispatchers.IO) { AiClient.transcribeBytes(this@AuraService, wav, "audio/wav") }.trim()
                    if (text.isNotEmpty()) onHeard(text)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    delay(2000)
                }
            } else {
                delay(3000)
            }
        }
    }

    /** Short report after every order: what you said and what was done. */
    fun report(goal: String, msg: String) {
        overlay.say("🗣 «${goal.take(70)}»\n$msg")
        speak("آپ نے کہا: ${goal.take(60)}۔ $msg")
    }

    fun stopAll() {
        agent.stop()
        askJob?.cancel()
        speakJob?.cancel()
        Speaker.stop()
    }

    private fun buildAskContext(q: String): String {
        val sb = StringBuilder()
        sb.append("Now: ").append(SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())).append("\n")
        if (notifs.isNotEmpty()) sb.append("Recent notifications:\n").append(notifs.takeLast(10).joinToString("\n")).append("\n")
        val wm = Memory.get(this).recentMessages(8)
        if (wm.isNotEmpty()) sb.append("Recent WhatsApp messages:\n").append(wm.joinToString("\n") { it.first + ": " + it.second }).append("\n")
        val calls = Memory.get(this).recentCalls(5)
        if (calls.isNotEmpty()) {
            sb.append("Recent calls handled by SINA:\n")
            calls.forEach { sb.append("- ").append(it.name.ifEmpty { it.number }).append(": ").append(it.summary).append("\n") }
        }
        val l = q.lowercase()
        if (listOf("اسکرین", "screen", "یہاں", "اس پر", "اس میں", "پڑھ", "read", "summar", "خلاصہ", "ترجمہ", "translate").any { l.contains(it) }) {
            val s = snapshot()
            if (s != null) sb.append("Text on the user's screen (").append(s.pkg).append("):\n").append(s.toPrompt()).append("\n")
        }
        return sb.toString()
    }

    private fun ask(q: String, kb: List<String>) {
        askJob?.cancel()
        askJob = scope.launch {
            overlay.setThinking(true, "سوچ رہا ہوں...")
            try {
                var ctxText = buildAskContext(q)
                if (kb.isNotEmpty()) ctxText += "\nKNOWLEDGE from the user's own website (prefer it when relevant):\n" + kb.joinToString("\n---\n")
                val ans = withContext(Dispatchers.IO) { AiClient.ask(this@AuraService, q, ctxText, chatHistory.takeLast(6)) }
                chatHistory.add(Pair(q, ans))
                Memory.get(this@AuraService).cacheAnswer(q, ans)           // remembered: next time works offline
                overlay.setThinking(false, "")
                replyChat(ans)
            } catch (e: CancellationException) {
                overlay.setThinking(false, "")
                throw e
            } catch (e: Exception) {
                overlay.setThinking(false, "")
                overlay.say("خرابی: ${e.message}")
            }
        }
    }

    /** Short result: small pill (and spoken if voice replies are on). */
    fun reply(text: String) {
        overlay.say(text)
        speak(text)
    }

    /** Longer answer: opens the chat so you can read it and keep talking. */
    fun replyChat(text: String) {
        overlay.say(text)
        overlay.showPanel()
        speak(text)
    }

    private fun speak(text: String) {
        if (!Prefs.speakReplies(this) || calls.active) return
        val clean = text.filter { it.isLetterOrDigit() || it.isWhitespace() || it in ".,،۔؟?!:-" }.trim()
        if (clean.isEmpty()) return
        speakJob?.cancel()
        speakJob = scope.launch {
            speaking = true
            try { Speaker.speak(this@AuraService, clean) } finally { speaking = false }
        }
    }

    /** A voice message arrived: turn it into text, then treat it like typed text. */
    private fun onVoice(file: File) {
        scope.launch {
            overlay.setThinking(true, "آپ کی آواز سمجھ رہا ہوں...")
            try {
                val text = withContext(Dispatchers.IO) { AiClient.transcribe(this@AuraService, file) }.trim()
                file.delete()
                overlay.setThinking(false, "")
                if (text.isEmpty()) {
                    overlay.say("آواز سمجھ نہیں آئی، دوبارہ بولیں")
                } else {
                    overlay.addUser(if (agent.running) "✋ $text" else text)
                    runGoal(text)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                overlay.setThinking(false, "")
                overlay.say("آواز میں خرابی: ${e.message}")
            }
        }
    }

    /* ---------------- eyes ---------------- */

    fun snapshot(): ScreenSnapshot? {
        val roots = ArrayList<AccessibilityNodeInfo>()
        val active = rootInActiveWindow
        if (active != null && active.packageName != packageName) {
            roots.add(active)
        } else {
            val ws = windows.orEmpty()
            val app = ws.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_APPLICATION && it.root?.packageName != packageName }
                ?: ws.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_SYSTEM && it.root?.packageName != packageName }
            app?.root?.let { roots.add(it) }
        }
        windows.orEmpty().filter { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }
            .forEach { w -> w.root?.let { roots.add(it) } }
        if (roots.isEmpty()) return null
        return ScreenReader.read(roots)
    }

    /* ---------------- hands ---------------- */

    suspend fun click(n: UiNode): Boolean {
        var cur: AccessibilityNodeInfo? = n.node
        var depth = 0
        while (cur != null && depth < 6) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            depth++
        }
        return tapAt(n.bounds.exactCenterX(), n.bounds.exactCenterY())
    }

    suspend fun tapAt(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return gesture(p, 60)
    }

    suspend fun swipe(direction: String): Boolean {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        val p = Path()
        when (direction) {
            "up" -> { p.moveTo(w / 2, h * 0.72f); p.lineTo(w / 2, h * 0.28f) }
            "down" -> { p.moveTo(w / 2, h * 0.28f); p.lineTo(w / 2, h * 0.72f) }
            "left" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            "right" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            else -> return false
        }
        return gesture(p, 350)
    }

    private suspend fun gesture(path: Path, dur: Long): Boolean = suspendCancellableCoroutine { cont ->
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur))
            .build()
        val sent = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (cont.isActive) cont.resume(true) }
            override fun onCancelled(d: GestureDescription?) { if (cont.isActive) cont.resume(false) }
        }, null)
        if (!sent && cont.isActive) cont.resume(false)
    }

    fun setText(n: UiNode, text: String, submit: Boolean): Boolean {
        n.node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val ok = n.node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok && submit && Build.VERSION.SDK_INT >= 30) {
            n.node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return ok
    }

    fun paste(n: UiNode): Boolean {
        n.node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return n.node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    fun globalAction(name: String): Boolean {
        val a = when (name) {
            "home" -> GLOBAL_ACTION_HOME
            "back" -> GLOBAL_ACTION_BACK
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "lock_screen" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return false
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else return false
            else -> return false
        }
        return performGlobalAction(a)
    }

    fun openApp(name: String): Boolean {
        val pkg = Memory.get(this).findApp(name)
        if (pkg != null) {
            val li = packageManager.getLaunchIntentForPackage(pkg)
            if (li != null) {
                li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivity(li); return true } catch (e: Exception) {}
            }
        }
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val q = name.lowercase()
        val hit = pm.queryIntentActivities(i, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(q) ||
                it.activityInfo.packageName.lowercase().contains(q)
        } ?: return false
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { startActivity(launch); true } catch (e: Exception) { false }
    }

    /* ---------------- direct tools (no screen hunting, no typing digits) ---------------- */

    fun callNumber(num: String): Boolean {
        val n = num.filter { it.isDigit() || it == '+' }
        if (n.isEmpty()) return false
        val granted = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val i = Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n)))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { startActivity(i); true } catch (e: Exception) { false }
    }

    fun openUrl(url: String): Boolean {
        if (url.isBlank()) return false
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { startActivity(i); true } catch (e: Exception) { false }
    }

    fun openSettings(page: String): Boolean {
        val a = when (page) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        val i = Intent(a)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { startActivity(i); true } catch (e: Exception) { false }
    }

    fun sendWhatsapp(number: String, text: String): Boolean =
        openUrl("https://wa.me/" + number.filter { it.isDigit() } + "?text=" + Uri.encode(text))

    suspend fun swipeRaw(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long): Boolean {
        val p = Path()
        p.moveTo(x1, y1)
        p.lineTo(x2, y2)
        return gesture(p, dur)
    }
}
