package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ai.configureAppCheck
import com.example.ui.components.FuturisticBackground
import com.example.ui.components.MoonOrbAndOrderOverlay
import com.example.ui.screens.AssistantScreen
import com.example.ui.screens.ButtonEditorDialog
import com.example.ui.screens.CallGuardScreen
import com.example.ui.screens.HomeAutomationScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.CosmicObsidian
import com.example.ui.theme.DeepSpaceNavy
import com.example.ui.theme.EmeraldPulse
import com.example.ui.theme.GlassSlateHigh
import com.example.ui.theme.LunarCyan
import com.example.ui.theme.LunarSilver
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.SinaTheme
import com.example.ui.viewmodel.SinaTab
import com.example.ui.viewmodel.SinaViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mandatory Step 1: Configure Firebase App Check with launch intent before Compose UI or ViewModels
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            SinaTheme {
                SinaRootApp()
            }
        }
    }
}

@Composable
fun SinaRootApp(
    viewModel: SinaViewModel = viewModel()
) {
    val context = LocalContext.current
    val buttons by viewModel.buttons.collectAsStateWithLifecycle()
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val reports by viewModel.reports.collectAsStateWithLifecycle()
    val callRecords by viewModel.callRecords.collectAsStateWithLifecycle()
    val qaMessages by viewModel.qaMessages.collectAsStateWithLifecycle()
    val streamingQaText by viewModel.streamingQaText.collectAsStateWithLifecycle()
    val qaError by viewModel.qaError.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val executionStatus by viewModel.executionStatus.collectAsStateWithLifecycle()
    val isListening by viewModel.isListening.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.isSpeaking.collectAsStateWithLifecycle()
    val partialTranscript by viewModel.partialTranscript.collectAsStateWithLifecycle()
    val isAccessibilityConnected by viewModel.isAccessibilityConnected.collectAsStateWithLifecycle()
    val isRecordingAudioNote by viewModel.isRecordingAudioNote.collectAsStateWithLifecycle()
    val audioAmplitude by viewModel.audioAmplitude.collectAsStateWithLifecycle()
    val audioDurationMs by viewModel.audioDurationMs.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val isOrbMenuOpen by viewModel.isOrbMenuOpen.collectAsStateWithLifecycle()
    val editingButton by viewModel.editingButton.collectAsStateWithLifecycle()
    val uiNotice by viewModel.uiNotice.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var hasPhonePermissions by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) ==
                PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        hasMicPermission = grants[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
    }

    val phonePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        hasPhonePermissions = grants[Manifest.permission.READ_PHONE_STATE] == true &&
            grants[Manifest.permission.ANSWER_PHONE_CALLS] == true
    }

    LaunchedEffect(uiNotice) {
        uiNotice?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearNotice()
        }
    }

    // Back from secondary tabs cleanly returns to the Home Automation main screen
    BackHandler(enabled = selectedTab != SinaTab.HOME && !isOrbMenuOpen) {
        viewModel.selectTab(SinaTab.HOME)
    }

    val requestMicAndNotifications = {
        val perms = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }.toTypedArray()
        micPermissionLauncher.launch(perms)
    }

    FuturisticBackground {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavRail = maxWidth >= 700.dp

            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                snackbarHost = { SnackbarHost(snackbarHostState) },
                topBar = {
                    SinaTopBar(
                        selectedTab = selectedTab,
                        alwaysSpeakEnabled = settings.alwaysSpeakEnabled,
                        isRunning = executionStatus.isRunning
                    )
                },
                bottomBar = {
                    if (!useNavRail) {
                        NavigationBar(
                            containerColor = GlassSlateHigh,
                            windowInsets = WindowInsets.navigationBars,
                            tonalElevation = 0.dp
                        ) {
                            SinaTab.entries.forEach { tab ->
                                NavigationBarItem(
                                    selected = selectedTab == tab,
                                    onClick = { viewModel.selectTab(tab) },
                                    icon = {
                                        Icon(
                                            imageVector = tabIcon(tab),
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = CosmicObsidian,
                                        selectedTextColor = LunarCyan,
                                        indicatorColor = LunarCyan,
                                        unselectedIconColor = MutedSilver,
                                        unselectedTextColor = MutedSilver
                                    ),
                                    modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useNavRail) {
                        NavigationRail(
                            containerColor = GlassSlateHigh,
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            SinaTab.entries.forEach { tab ->
                                NavigationRailItem(
                                    selected = selectedTab == tab,
                                    onClick = { viewModel.selectTab(tab) },
                                    icon = {
                                        Icon(tabIcon(tab), contentDescription = tab.label)
                                    },
                                    label = { Text(tab.label) },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = CosmicObsidian,
                                        selectedTextColor = LunarCyan,
                                        indicatorColor = LunarCyan,
                                        unselectedIconColor = MutedSilver,
                                        unselectedTextColor = MutedSilver
                                    )
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                        when (selectedTab) {
                            SinaTab.HOME -> HomeAutomationScreen(
                                buttons = buttons,
                                reports = reports,
                                settings = settings,
                                executionStatus = executionStatus,
                                onTriggerButton = { btn, on -> viewModel.triggerButton(btn, on) },
                                onEditButton = { btn -> viewModel.openButtonEditor(btn) },
                                onAddNewButton = { viewModel.openButtonEditor(null) },
                                onOpenOrderMenu = { viewModel.openOrbMenu() },
                                onToggleAlwaysSpeak = { enable ->
                                    if (enable && !hasMicPermission) requestMicAndNotifications()
                                    else viewModel.toggleAlwaysSpeak(enable, hasMicPermission)
                                },
                                onToggleFloatingOrb = { enable -> viewModel.toggleFloatingOrb(enable) },
                                onStudyDevice = { viewModel.studyDeviceNow() },
                                onInterruptAndGuide = { guide -> viewModel.interruptWithGuidance(guide) }
                            )

                            SinaTab.ASK -> AssistantScreen(
                                qaMessages = qaMessages,
                                streamingQaText = streamingQaText,
                                qaError = qaError,
                                isSpeaking = isSpeaking,
                                memories = memories,
                                onAskQuestion = { q -> viewModel.askQuestion(q) },
                                onSpeakText = { t -> viewModel.speakText(t) },
                                onStopSpeaking = { viewModel.stopSpeaking() },
                                onClearQa = { viewModel.clearQaHistory() },
                                onStudyDevice = { viewModel.studyDeviceNow() }
                            )

                            SinaTab.CALLS -> CallGuardScreen(
                                settings = settings,
                                callRecords = callRecords,
                                hasPhonePermissions = hasPhonePermissions,
                                onRequestPhonePermissions = {
                                    phonePermissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.READ_PHONE_STATE,
                                            Manifest.permission.ANSWER_PHONE_CALLS
                                        )
                                    )
                                },
                                onToggleAutoAnswer = { viewModel.setAutoCallSecondRing(it) },
                                onSaveGreeting = { viewModel.setCallGreeting(it) },
                                onTestVoice = { viewModel.speakText(it) },
                                onSimulateCallFlow = { name, phone, msg ->
                                    viewModel.simulateSecondRingCallFlow(name, phone, msg)
                                }
                            )

                            SinaTab.SETTINGS -> SettingsScreen(
                                buttons = buttons,
                                settings = settings,
                                isAccessibilityConnected = isAccessibilityConnected,
                                hasOverlayPermission = Settings.canDrawOverlays(context),
                                hasMicPermission = hasMicPermission,
                                onEditButton = { viewModel.openButtonEditor(it) },
                                onDeleteButton = { viewModel.deleteButton(it) },
                                onToggleOpenInBrowser = { viewModel.setOpenUrlsInBrowser(it) },
                                onVoiceLangChange = { viewModel.setVoiceLanguageMode(it) },
                                onTtsRatePitchChange = { r, p -> viewModel.setTtsRateAndPitch(r, p) },
                                onTestNaturalVoice = {
                                    viewModel.speakText("Assalam-o-Alaikum, I am Sina, your futuristic AI home assistant.")
                                },
                                onOpenAccessibilitySettings = { viewModel.openAccessibilitySettings() },
                                onOpenOverlaySettings = { viewModel.openOverlaySettings() },
                                onRequestMicPermission = requestMicAndNotifications
                            )
                        }
                    }
                }
            }

            // Floating Draggable Glowing Moon Orb ("Sina") + Order Menu
            MoonOrbAndOrderOverlay(
                isMenuOpen = isOrbMenuOpen,
                alwaysSpeakEnabled = settings.alwaysSpeakEnabled,
                isListening = isListening,
                isRecordingAudioNote = isRecordingAudioNote,
                audioAmplitude = audioAmplitude,
                audioDurationMs = audioDurationMs,
                partialTranscript = partialTranscript,
                lastBriefReport = executionStatus.lastBriefReport,
                onOpenMenu = { viewModel.openOrbMenu() },
                onCloseMenu = { viewModel.closeOrbMenu() },
                onSubmitTextOrder = { cmd -> viewModel.submitTextOrder(cmd) },
                onTapVoiceOrder = {
                    if (!hasMicPermission) requestMicAndNotifications()
                    else viewModel.startSingleVoiceOrder()
                },
                onToggleAlwaysSpeak = { enable ->
                    if (enable && !hasMicPermission) requestMicAndNotifications()
                    else viewModel.toggleAlwaysSpeak(enable, hasMicPermission)
                },
                onStartAudioNote = {
                    if (!hasMicPermission) requestMicAndNotifications()
                    else viewModel.startWhatsAppAudioNote(hasMicPermission)
                },
                onSendAudioNote = { viewModel.sendWhatsAppAudioNote() },
                onCancelAudioNote = { viewModel.cancelWhatsAppAudioNote() }
            )

            editingButton?.let { btn ->
                ButtonEditorDialog(
                    initialButton = btn,
                    onDismiss = { viewModel.closeButtonEditor() },
                    onSave = { updated -> viewModel.saveButton(updated) }
                )
            }
        }
    }
}

@Composable
private fun SinaTopBar(
    selectedTab: SinaTab,
    alwaysSpeakEnabled: Boolean,
    isRunning: Boolean
) {
    Surface(
        color = Color(0xCC060A17),
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SINA",
                    style = MaterialTheme.typography.headlineMedium,
                    color = LunarSilver,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = selectedTab.label.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = LunarCyan
                )
            }
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = DeepSpaceNavy,
                border = BorderStroke(
                    1.dp,
                    if (alwaysSpeakEnabled || isRunning) EmeraldPulse else Color(0x4422D3EE)
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = if (alwaysSpeakEnabled || isRunning) EmeraldPulse else LunarCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = when {
                            isRunning -> "Executing"
                            alwaysSpeakEnabled -> "Always-Speak"
                            else -> "Neural Ready"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = if (alwaysSpeakEnabled || isRunning) EmeraldPulse else LunarSilver
                    )
                }
            }
        }
    }
}

private fun tabIcon(tab: SinaTab): ImageVector = when (tab) {
    SinaTab.HOME -> Icons.Default.Home
    SinaTab.ASK -> Icons.Default.AutoAwesome
    SinaTab.CALLS -> Icons.Default.PhoneInTalk
    SinaTab.SETTINGS -> Icons.Default.Settings
}
