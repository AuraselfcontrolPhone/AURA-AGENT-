package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CosmicObsidian = Color(0xFF060A17)
val DeepSpaceNavy = Color(0xFF0B1120)
val GlassSlate = Color(0xCC0F172A)
val GlassSlateHigh = Color(0xE6162038)
val LunarCyan = Color(0xFF22D3EE)
val LunarCyanDim = Color(0xFF0891B2)
val ElectricViolet = Color(0xFF818CF8)
val ElectricVioletDeep = Color(0xFF4F46E5)
val LunarSilver = Color(0xFFF1F5F9)
val MutedSilver = Color(0xFF94A3B8)
val EmeraldPulse = Color(0xFF34D399)
val RoseAlert = Color(0xFFFB7185)
val AmberTelemetry = Color(0xFFFBBF24)
val BorderGlowCyan = Color(0x5522D3EE)
val BorderGlowSlate = Color(0x4494A3B8)
