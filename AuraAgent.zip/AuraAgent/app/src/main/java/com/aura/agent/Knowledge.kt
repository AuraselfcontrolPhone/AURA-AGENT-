package com.aura.agent

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/** Your own website as a knowledge source. Downloaded once, stored in the phone, searched offline. */
object Knowledge {
    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()

    /** Blocking. Returns the number of stored pieces. */
    fun refresh(ctx: Context): Int {
        var url = Prefs.getStr(ctx, "kbUrl", "").trim()
        if (url.isEmpty()) return 0
        if (!url.contains("://")) url = "https://$url"
        val html = http.newCall(Request.Builder().url(url).build()).execute().use { it.body?.string().orEmpty() }
        val text = html
            .replace(Regex("(?is)<(script|style|noscript)[^>]*>.*?</\\1>"), " ")
            .replace(Regex("(?s)<[^>]+>"), " ")
            .replace("&nbsp;", " ").replace("&amp;", "&")
            .replace(Regex("\\s+"), " ").trim()
        val sentences = text.split(Regex("(?<=[۔.!؟?])\\s+"))
        val mem = Memory.get(ctx)
        mem.kbClear()
        var cur = StringBuilder()
        var n = 0
        for (s in sentences) {
            if (cur.length + s.length > 450 && cur.isNotEmpty()) { mem.kbAdd(cur.toString().trim()); n++; cur = StringBuilder() }
            cur.append(s).append(' ')
        }
        if (cur.isNotBlank()) { mem.kbAdd(cur.toString().trim()); n++ }
        return n
    }

    /** Best matching pieces for a question (offline keyword match). */
    fun search(ctx: Context, q: String): List<String> {
        val words = Fuzzy.tokens(q).filter { it.length > 2 }
        if (words.isEmpty()) return emptyList()
        return Memory.get(ctx).kbAll()
            .map { c -> Pair(c, words.count { w -> Fuzzy.tokenMatch(w, Fuzzy.tokens(c)) }) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(3).map { it.first }
    }
}
