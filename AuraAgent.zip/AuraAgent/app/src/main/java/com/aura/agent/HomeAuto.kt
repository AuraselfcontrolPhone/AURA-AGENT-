package com.aura.agent

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Home automation. Every device has an ON address and an OFF address (a web link / webhook).
 * Pressing ON sends the ON link, OFF sends the OFF link. Everything happens in the background:
 * no browser and no app screen is opened. Works from voice even when the app is closed.
 * A link may start with "POST " to send a POST instead of a GET.
 */
object HomeAuto {
    class Result(val ok: Boolean, val msg: String)

    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    /** Blocking. Run off the main thread. */
    fun fire(url: String): Result {
        val u0 = url.trim()
        if (u0.isEmpty()) return Result(false, "URL نہیں لگا")
        return try {
            val post = u0.startsWith("POST ", ignoreCase = true)
            val u = if (post) u0.substring(5).trim() else u0
            val rb = Request.Builder().url(u)
            if (post) rb.post("".toRequestBody()) else rb.get()
            http.newCall(rb.build()).execute().use { r -> Result(r.isSuccessful, "HTTP ${r.code}") }
        } catch (e: Exception) {
            Result(false, e.message ?: "خرابی")
        }
    }

    /** Blocking: runs the ON or OFF link of a device and remembers the state. */
    fun runNow(ctx: Context, d: Memory.Device, on: Boolean): Result {
        val r = fire(if (on) d.onUrl else d.offUrl)
        if (r.ok) Memory.get(ctx).setDeviceState(d.id, if (on) 1 else 2)
        return r
    }

    private val onWords = listOf("آن", "چالو", "جلاؤ", "کھولو", "کھول دو", "چلاؤ", "turn on", " on", "start")
    private val offWords = listOf("بند", "آف", "بجھاؤ", "روک", "turn off", " off", "stop", "close")

    /**
     * Voice/text control. Returns a short report if the sentence named one of your devices
     * (or "all <section>"), otherwise null. Blocking: call from a background thread.
     */
    fun handle(ctx: Context, text: String): String? {
        val mem = Memory.get(ctx)
        val t = " " + text.lowercase().trim()
        val off = offWords.any { t.contains(it) }
        val on = !off && onWords.any { t.contains(it) }
        val all = listOf("سب ", "تمام", "all ").any { t.contains(it) }

        val picked = ArrayList<Memory.Device>()
        for (s in mem.sections()) {
            val ds = mem.devices(s.id)
            if (all && t.contains(s.name.lowercase())) { picked.addAll(ds); continue }
            for (d in ds) {
                val n = d.name.lowercase().trim()
                if (n.isEmpty()) continue
                val tokens = n.split(" ").filter { it.length >= 2 }
                if (t.contains(n) || (tokens.isNotEmpty() && tokens.all { t.contains(it) })) picked.add(d)
            }
        }
        if (picked.isEmpty()) return null

        val lines = ArrayList<String>()
        for (d in picked.distinctBy { it.id }) {
            val goOn = if (on) true else if (off) false else d.state != 1   // no word said: toggle
            val r = runNow(ctx, d, goOn)
            lines.add((if (r.ok) "✓ " else "✗ ") + d.name + (if (goOn) " آن" else " بند") + (if (r.ok) "" else " (${r.msg})"))
        }
        return lines.joinToString("\n")
    }
}
