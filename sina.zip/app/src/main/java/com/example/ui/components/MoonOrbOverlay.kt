package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.KeyboardHide
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.CosmicObsidian
import com.example.ui.theme.DeepSpaceNavy
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldPulse
import com.example.ui.theme.GlassSlateHigh
import com.example.ui.theme.LunarCyan
import com.example.ui.theme.LunarSilver
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.RoseAlert
import kotlin.math.roundToInt

@Composable
fun MoonOrbAndOrderOverlay(
    isMenuOpen: Boolean,
    alwaysSpeakEnabled: Boolean,
    isListening: Boolean,
    isRecordingAudioNote: Boolean,
    audioAmplitude: Float,
    audioDurationMs: Long,
    partialTranscript: String,
    lastBriefReport: String,
    onOpenMenu: () -> Unit,
    onCloseMenu: () -> Unit,
    onSubmitTextOrder: (String) -> Unit,
    onTapVoiceOrder: () -> Unit,
    onToggleAlwaysSpeak: (Boolean) -> Unit,
    onStartAudioNote: () -> Unit,
    onSendAudioNote: () -> Unit,
    onCancelAudioNote: () -> Unit,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current

    var orderText by remember { mutableStateOf("") }
    var isInputFocused by remember { mutableStateOf(false) }

    // Back button behavior:
    // 1. If keyboard / text field is focused, dismiss keyboard cleanly first.
    // 2. Otherwise if orb menu is open, minimize back to the Moon Orb!
    BackHandler(enabled = isMenuOpen) {
        if (isInputFocused) {
            keyboardController?.hide()
            focusManager.clearFocus()
        } else {
            onCloseMenu()
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "moonPulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isListening || alwaysSpeakEnabled) 1.12f else 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        val orbSizePx = with(density) { 74.dp.toPx() }
        val maxWidthPx = with(density) { maxWidth.toPx() } - orbSizePx - with(density) { 12.dp.toPx() }
        val maxHeightPx = with(density) { maxHeight.toPx() } - orbSizePx - with(density) { 92.dp.toPx() }

        var offsetX by remember {
            mutableFloatStateOf((maxWidthPx - with(density) { 16.dp.toPx() }).coerceAtLeast(16f))
        }
        var offsetY by remember {
            mutableFloatStateOf((maxHeightPx * 0.62f).coerceAtLeast(60f))
        }

        // Scrim & Order Menu when open (tap outside scrim minimizes back to Moon Orb)
        AnimatedVisibility(
            visible = isMenuOpen,
            enter = fadeIn(tween(180)) + scaleIn(initialScale = 0.92f, animationSpec = tween(220)),
            exit = fadeOut(tween(160)) + scaleOut(targetScale = 0.92f, animationSpec = tween(180))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x9903060F))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        keyboardController?.hide()
                        focusManager.clearFocus()
                        onCloseMenu()
                    },
                contentAlignment = Alignment.BottomCenter
            ) {
                Surface(
                    modifier = Modifier
                        .padding(horizontal = 16.dp, vertical = 20.dp)
                        .widthIn(max = 540.dp)
                        .fillMaxWidth()
                        .imePadding()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { /* Consume taps inside card so scrim doesn't close */ },
                    shape = RoundedCornerShape(28.dp),
                    color = GlassSlateHigh,
                    tonalElevation = 12.dp,
                    border = androidx.compose.foundation.BorderStroke(
                        1.5.dp,
                        Brush.linearGradient(listOf(LunarCyan, ElectricViolet))
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Top bar: Moon Avatar + "Sina" + Minimize button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_moon_orb),
                                    contentDescription = "Sina Moon Orb",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .border(1.5.dp, LunarCyan, CircleShape)
                                )
                                Column {
                                    Text(
                                        text = "Sina Order Hub",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = LunarSilver,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = when {
                                            isListening -> partialTranscript.ifBlank { "Listening..." }
                                            alwaysSpeakEnabled -> "Always-Speak Armed"
                                            else -> "Voice · Text · Audio Note"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = LunarCyan
                                    )
                                }
                            }
                            IconButton(
                                onClick = {
                                    keyboardController?.hide()
                                    focusManager.clearFocus()
                                    onCloseMenu()
                                },
                                modifier = Modifier.testTag("orb_menu_close_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Minimize to Moon Orb",
                                    tint = MutedSilver
                                )
                            }
                        }

                        if (lastBriefReport.isNotBlank()) {
                            Surface(
                                color = Color(0xFF0A1628),
                                shape = RoundedCornerShape(14.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x3322D3EE))
                            ) {
                                Text(
                                    text = "Last report: $lastBriefReport",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = LunarSilver,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }

                        // Always-Speak & Single Voice Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { onToggleAlwaysSpeak(!alwaysSpeakEnabled) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("always_speak_button"),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (alwaysSpeakEnabled) EmeraldPulse else Color(0xFF172542),
                                    contentColor = if (alwaysSpeakEnabled) CosmicObsidian else LunarCyan
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.RecordVoiceOver,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    text = if (alwaysSpeakEnabled) "Always Speak ON" else "Always Speak",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }

                            Button(
                                onClick = onTapVoiceOrder,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("single_voice_button"),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isListening) RoseAlert else LunarCyan,
                                    contentColor = CosmicObsidian
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    text = if (isListening) "Listening..." else "Speak Order",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }

                        // WhatsApp-style Voice Note Recorder Bar
                        if (isRecordingAudioNote) {
                            val seconds = (audioDurationMs / 1000L).toInt()
                            Surface(
                                color = Color(0xFF131E36),
                                shape = RoundedCornerShape(18.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, RoseAlert)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    IconButton(
                                        onClick = onCancelAudioNote,
                                        modifier = Modifier.testTag("audio_note_cancel")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Cancel Voice Note",
                                            tint = RoseAlert
                                        )
                                    }
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.GraphicEq,
                                            contentDescription = "Recording waveform",
                                            tint = LunarCyan,
                                            modifier = Modifier.scale(0.9f + audioAmplitude * 0.5f)
                                        )
                                        Text(
                                            text = "REC 0:${seconds.toString().padStart(2, '0')}",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = RoseAlert
                                        )
                                    }
                                    Button(
                                        onClick = onSendAudioNote,
                                        shape = CircleShape,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = EmeraldPulse,
                                            contentColor = CosmicObsidian
                                        ),
                                        modifier = Modifier.testTag("audio_note_send")
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Send,
                                            contentDescription = "Send Voice Note"
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Text("Send")
                                    }
                                }
                            }
                        } else {
                            Button(
                                onClick = onStartAudioNote,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("whatsapp_record_button"),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF1A2244),
                                    contentColor = ElectricViolet
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = "Record Voice Note (WhatsApp Style)",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }

                        // Text Order Input + Explicit Hide Keyboard + Auto-Minimize Send
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = orderText,
                                onValueChange = { orderText = it },
                                modifier = Modifier
                                    .weight(1f)
                                    .onFocusChanged { isInputFocused = it.isFocused }
                                    .testTag("orb_order_text_input"),
                                placeholder = {
                                    Text(
                                        "Type order or question...",
                                        color = MutedSilver
                                    )
                                },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                keyboardActions = KeyboardActions(
                                    onSend = {
                                        if (orderText.isNotBlank()) {
                                            val cmd = orderText
                                            orderText = ""
                                            keyboardController?.hide()
                                            focusManager.clearFocus()
                                            onSubmitTextOrder(cmd)
                                        }
                                    }
                                ),
                                trailingIcon = {
                                    if (isInputFocused) {
                                        IconButton(
                                            onClick = {
                                                keyboardController?.hide()
                                                focusManager.clearFocus()
                                            },
                                            modifier = Modifier.testTag("hide_keyboard_button")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.KeyboardHide,
                                                contentDescription = "Hide Keyboard",
                                                tint = MutedSilver
                                            )
                                        }
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = LunarCyan,
                                    unfocusedBorderColor = Color(0x4494A3B8),
                                    focusedTextColor = LunarSilver,
                                    unfocusedTextColor = LunarSilver,
                                    focusedContainerColor = DeepSpaceNavy,
                                    unfocusedContainerColor = DeepSpaceNavy
                                ),
                                shape = RoundedCornerShape(16.dp)
                            )

                            IconButton(
                                onClick = {
                                    if (orderText.isNotBlank()) {
                                        val cmd = orderText
                                        orderText = ""
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                        onSubmitTextOrder(cmd)
                                    }
                                },
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(CircleShape)
                                    .background(LunarCyan)
                                    .testTag("orb_order_send_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Execute & Minimize",
                                    tint = CosmicObsidian
                                )
                            }
                        }
                    }
                }
            }
        }

        // Draggable Luminous Moon Orb ("Sina")
        if (!isMenuOpen) {
            Box(
                modifier = Modifier
                    .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                    .size(74.dp)
                    .scale(pulseScale)
                    .shadow(16.dp, CircleShape, ambientColor = LunarCyan, spotColor = LunarCyan)
                    .clip(CircleShape)
                    .background(CosmicObsidian)
                    .border(
                        width = if (isListening || alwaysSpeakEnabled) 2.5.dp else 1.5.dp,
                        brush = Brush.sweepGradient(
                            listOf(
                                if (alwaysSpeakEnabled) EmeraldPulse else LunarCyan,
                                ElectricViolet,
                                if (alwaysSpeakEnabled) EmeraldPulse else LunarCyan
                            )
                        ),
                        shape = CircleShape
                    )
                    .pointerInput(maxWidthPx, maxHeightPx) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            offsetX = (offsetX + dragAmount.x).coerceIn(8f, maxWidthPx.coerceAtLeast(8f))
                            offsetY = (offsetY + dragAmount.y).coerceIn(8f, maxHeightPx.coerceAtLeast(8f))
                        }
                    }
                    .clickable(onClick = onOpenMenu)
                    .testTag("sina_moon_orb"),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_moon_orb),
                    contentDescription = "Sina Floating Moon Orb",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(3.dp)
                        .clip(CircleShape)
                )
                Surface(
                    color = Color(0xCC060A17),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 4.dp)
                ) {
                    Text(
                        text = if (alwaysSpeakEnabled) "Sina · Live" else "Sina",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (alwaysSpeakEnabled) EmeraldPulse else LunarSilver,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                    )
                }
            }
        }
    }
}
