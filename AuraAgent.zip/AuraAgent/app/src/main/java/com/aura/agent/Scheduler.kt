package com.aura.agent

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

/** Automatic orders: "every night at 11 turn off data". */
object Scheduler {
    private fun pending(ctx: Context, id: Long): PendingIntent =
        PendingIntent.getBroadcast(ctx, id.toInt(), Intent(ctx, ScheduleReceiver::class.java).putExtra("id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun arm(ctx: Context, s: Memory.Sched) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, s.hour)
        c.set(Calendar.MINUTE, s.min)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1)
        val pi = pending(ctx, s.id)
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
        }
    }

    fun cancel(ctx: Context, id: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx, id))
    }

    fun armAll(ctx: Context) {
        Memory.get(ctx).schedules().forEach { arm(ctx, it) }
    }
}

class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val id = i.getLongExtra("id", -1L)
        val mem = Memory.get(ctx)
        val s = mem.schedule(id) ?: return
        val svc = AuraService.instance
        if (svc != null) svc.runGoal(s.goal)
        if (s.daily) Scheduler.arm(ctx, s) else mem.deleteSchedule(id)
    }
}
