package com.example.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

data class UrlExecutionResult(
    val success: Boolean,
    val statusCode: Int?,
    val message: String,
    val latencyMs: Long
)

class SinaRepository(
    private val context: Context,
    private val dao: SinaDao,
    val preferences: SinaPreferences
) {
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS)
        .build()

    val buttonsFlow: Flow<List<SmartButtonEntity>> = dao.observeButtons()
    val memoriesFlow: Flow<List<DeviceMemoryEntity>> = dao.observeMemories()
    val reportsFlow: Flow<List<CommandReportEntity>> = dao.observeReports()
    val callRecordsFlow: Flow<List<CallRecordEntity>> = dao.observeCallRecords()
    val qaMessagesFlow: Flow<List<QaMessageEntity>> = dao.observeQaMessages()

    suspend fun ensureDefaultButtons() = withContext(Dispatchers.IO) {
        if (dao.getButtonCount() == 0) {
            dao.insertButtons(SinaDatabase.defaultSmartButtons())
        }
    }

    suspend fun saveButton(button: SmartButtonEntity) = withContext(Dispatchers.IO) {
        if (button.id == 0L) {
            dao.insertButton(button)
        } else {
            dao.updateButton(button)
        }
    }

    suspend fun deleteButton(button: SmartButtonEntity) = withContext(Dispatchers.IO) {
        dao.deleteButton(button)
    }

    suspend fun getAllButtonsSync(): List<SmartButtonEntity> = withContext(Dispatchers.IO) {
        dao.getAllButtonsSync()
    }

    /**
     * Triggers either ON or OFF URL for a smart home button directly in the background
     * (without opening the browser or switching away from whatever app the user is in),
     * unless openUrlsInBrowser is explicitly enabled in Settings.
     */
    suspend fun triggerSmartButton(
        button: SmartButtonEntity,
        turnOn: Boolean,
        source: String = "MANUAL"
    ): UrlExecutionResult = withContext(Dispatchers.IO) {
        val targetUrl = (if (turnOn) button.onUrl else button.offUrl).trim()
        val stateLabel = if (turnOn) "ON" else "OFF"

        if (targetUrl.isBlank()) {
            val result = UrlExecutionResult(false, null, "No $stateLabel URL configured for ${button.name}", 0)
            dao.updateButton(
                button.copy(
                    isOn = turnOn,
                    lastStatusNote = "Missing $stateLabel URL",
                    lastTriggeredAt = System.currentTimeMillis()
                )
            )
            return@withContext result
        }

        val settings = preferences.settingsFlow.first()
        val start = System.currentTimeMillis()

        val result = if (settings.openUrlsInBrowser) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                UrlExecutionResult(
                    success = true,
                    statusCode = 200,
                    message = "Opened $stateLabel URL for ${button.name}",
                    latencyMs = System.currentTimeMillis() - start
                )
            } catch (e: Exception) {
                Log.e("SinaRepo", "Failed to open URL in browser", e)
                UrlExecutionResult(false, null, e.localizedMessage ?: "Browser launch failed", 0)
            }
        } else {
            executeHttpUrl(targetUrl, button.httpMethod)
        }

        val statusSummary = if (result.success) {
            "$stateLabel OK (${result.statusCode ?: 200} · ${result.latencyMs}ms)"
        } else {
            "$stateLabel Sent (Local/Offline: ${result.message})"
        }

        dao.updateButton(
            button.copy(
                isOn = turnOn,
                lastStatusNote = statusSummary,
                lastTriggeredAt = System.currentTimeMillis()
            )
        )

        dao.insertReport(
            CommandReportEntity(
                source = source,
                userInput = "${button.name} -> $stateLabel",
                summaryReport = if (result.success) {
                    "${button.name} turned $stateLabel via ${targetUrl.take(44)} (${result.latencyMs}ms)."
                } else {
                    "${button.name} toggled $stateLabel locally; endpoint unreachable (${result.message})."
                },
                actionTaken = "HTTP ${button.httpMethod} $targetUrl",
                isSuccess = result.success
            )
        )
        result
    }

    private fun executeHttpUrl(url: String, method: String): UrlExecutionResult {
        val start = System.currentTimeMillis()
        return try {
            val normalizedUrl = if (url.startsWith("http://") || url.startsWith("https://")) {
                url
            } else {
                "http://$url"
            }
            val requestBuilder = Request.Builder().url(normalizedUrl)
            if (method.equals("POST", ignoreCase = true)) {
                requestBuilder.post("".toRequestBody(null))
            } else {
                requestBuilder.get()
            }
            httpClient.newCall(requestBuilder.build()).execute().use { response ->
                val elapsed = System.currentTimeMillis() - start
                UrlExecutionResult(
                    success = response.isSuccessful,
                    statusCode = response.code,
                    message = if (response.isSuccessful) "HTTP ${response.code}" else "HTTP ${response.code} ${response.message}",
                    latencyMs = elapsed
                )
            }
        } catch (e: Exception) {
            val elapsed = System.currentTimeMillis() - start
            Log.w("SinaRepo", "HTTP URL call error for $url: ${e.message}")
            UrlExecutionResult(
                success = false,
                statusCode = null,
                message = e.javaClass.simpleName + ": " + (e.localizedMessage ?: "Unreachable"),
                latencyMs = elapsed
            )
        }
    }

    /**
     * Studies all launchable apps & capabilities on the phone immediately on launch
     * ("فون میں آتے ہی ہر چیز سٹڈی کر لے") and stores them in Room memory.
     */
    suspend fun studyDeviceAppsAndCapabilities(): Int = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolvedApps = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)
        var studiedCount = 0
        for (info in resolvedApps) {
            val pkg = info.activityInfo?.packageName ?: continue
            if (pkg == context.packageName) continue
            val appLabel = info.loadLabel(pm)?.toString()?.trim().orEmpty()
            if (appLabel.isBlank()) continue
            val key = "APP:$pkg"
            val existing = dao.getMemoryByKey(key)
            dao.upsertMemory(
                DeviceMemoryEntity(
                    id = existing?.id ?: 0,
                    memoryKey = key,
                    memoryType = "APP",
                    appPackage = pkg,
                    screenTitle = appLabel,
                    label = appLabel,
                    actionHint = "Launch $appLabel via PackageManager ($pkg)",
                    extraData = info.activityInfo?.name.orEmpty(),
                    hitCount = (existing?.hitCount ?: 0) + 1,
                    updatedAt = System.currentTimeMillis()
                )
            )
            studiedCount++
        }
        // Also record core phone capabilities so Sina knows exact Android shortcuts immediately
        val coreCapabilities = listOf(
            Triple("CAP:DIALER", "Phone Dialer", "Use ACTION_DIAL tel:<number> directly without menu confusion"),
            Triple("CAP:WHATSAPP", "WhatsApp / Messaging", "Use https://wa.me/<digits> or ACTION_SENDTO smsto:<number>"),
            Triple("CAP:SETTINGS_WIFI", "Wi-Fi Settings", "Open Settings.Panel.ACTION_WIFI or Settings.ACTION_WIFI_SETTINGS"),
            Triple("CAP:SETTINGS_BT", "Bluetooth Settings", "Open Settings.ACTION_BLUETOOTH_SETTINGS"),
            Triple("CAP:YOUTUBE_SEARCH", "YouTube Search", "Open https://www.youtube.com/results?search_query=<query>"),
            Triple("CAP:WEB_SEARCH", "Browser / Search", "Open https://www.google.com/search?q=<query>")
        )
        for ((key, title, hint) in coreCapabilities) {
            val existing = dao.getMemoryByKey(key)
            if (existing == null) {
                dao.upsertMemory(
                    DeviceMemoryEntity(
                        memoryKey = key,
                        memoryType = "FACT",
                        appPackage = "android.system",
                        screenTitle = title,
                        label = title,
                        actionHint = hint,
                        hitCount = 1
                    )
                )
            }
        }
        studiedCount
    }

    suspend fun rememberScreenElement(
        appPackage: String,
        screenTitle: String,
        elementLabel: String,
        actionHint: String,
        bounds: String = ""
    ) = withContext(Dispatchers.IO) {
        if (elementLabel.isBlank()) return@withContext
        val key = "UI:${appPackage}:${screenTitle.take(30)}:${elementLabel.take(40)}"
        val existing = dao.getMemoryByKey(key)
        dao.upsertMemory(
            DeviceMemoryEntity(
                id = existing?.id ?: 0,
                memoryKey = key,
                memoryType = "SCREEN_ELEMENT",
                appPackage = appPackage,
                screenTitle = screenTitle,
                label = elementLabel,
                actionHint = actionHint,
                extraData = bounds,
                hitCount = (existing?.hitCount ?: 0) + 1,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun rememberUserCorrection(guidance: String, contextNote: String) = withContext(Dispatchers.IO) {
        val key = "CORR:${guidance.take(45).hashCode()}"
        val existing = dao.getMemoryByKey(key)
        dao.upsertMemory(
            DeviceMemoryEntity(
                id = existing?.id ?: 0,
                memoryKey = key,
                memoryType = "CORRECTION",
                appPackage = "user.guidance",
                screenTitle = contextNote,
                label = guidance,
                actionHint = "User instructed: $guidance",
                hitCount = (existing?.hitCount ?: 0) + 1,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun getTopMemoriesSync(): List<DeviceMemoryEntity> = withContext(Dispatchers.IO) {
        dao.getTopMemoriesSync()
    }

    suspend fun addCommandReport(
        source: String,
        userInput: String,
        summaryReport: String,
        actionTaken: String,
        isSuccess: Boolean = true
    ) = withContext(Dispatchers.IO) {
        dao.insertReport(
            CommandReportEntity(
                source = source,
                userInput = userInput,
                summaryReport = summaryReport,
                actionTaken = actionTaken,
                isSuccess = isSuccess
            )
        )
    }

    suspend fun clearReports() = withContext(Dispatchers.IO) {
        dao.clearReports()
    }

    suspend fun addQaMessage(isUser: Boolean, content: String): Long = withContext(Dispatchers.IO) {
        dao.insertQaMessage(QaMessageEntity(isUser = isUser, content = content))
    }

    suspend fun clearQaMessages() = withContext(Dispatchers.IO) {
        dao.clearQaMessages()
    }

    suspend fun recordIncomingCallRing(phoneNumber: String, callerName: String): CallRecordEntity =
        withContext(Dispatchers.IO) {
            val recent = dao.getLatestCallForNumber(phoneNumber)
            val twoMinutesAgo = System.currentTimeMillis() - 180_000L
            if (recent != null && recent.timestamp >= twoMinutesAgo && !recent.wasAutoAnswered) {
                val updated = recent.copy(
                    ringCount = recent.ringCount + 1,
                    timestamp = System.currentTimeMillis()
                )
                dao.updateCallRecord(updated)
                updated
            } else {
                val fresh = CallRecordEntity(
                    phoneNumber = phoneNumber,
                    callerName = callerName.ifBlank { phoneNumber },
                    ringCount = 1,
                    wasAutoAnswered = false
                )
                val id = dao.insertCallRecord(fresh)
                fresh.copy(id = id)
            }
        }

    suspend fun updateCallRecord(record: CallRecordEntity) = withContext(Dispatchers.IO) {
        dao.updateCallRecord(record)
    }
}
