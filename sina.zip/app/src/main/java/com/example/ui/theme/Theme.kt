package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val SinaDarkColorScheme = darkColorScheme(
    primary = LunarCyan,
    onPrimary = CosmicObsidian,
    primaryContainer = Color(0xFF0E3A4D),
    onPrimaryContainer = Color(0xFFCFFAFE),
    secondary = ElectricViolet,
    onSecondary = CosmicObsidian,
    secondaryContainer = Color(0xFF252A54),
    onSecondaryContainer = Color(0xFFE0E7FF),
    tertiary = EmeraldPulse,
    onTertiary = CosmicObsidian,
    background = CosmicObsidian,
    onBackground = LunarSilver,
    surface = DeepSpaceNavy,
    onSurface = LunarSilver,
    surfaceVariant = GlassSlate,
    onSurfaceVariant = MutedSilver,
    outline = BorderGlowCyan,
    error = RoseAlert,
    onError = CosmicObsidian
)

val SinaShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun SinaTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SinaDarkColorScheme,
        typography = SinaTypography,
        shapes = SinaShapes,
        content = content
    )
}
