package com.aura.agent

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator

/** SAHIB's moon: a glowing moon with craters. Idle = soft breathing, listening = cyan rings that follow your voice, thinking = spinning arc. */
class OrbView(ctx: Context) : View(ctx) {
    enum class State { IDLE, LISTEN, THINK }

    private var state: State = State.IDLE
    private var phase = 0f
    private var level = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val c1 = Color.parseColor("#FFFFFF")
    private val c2 = Color.parseColor("#DCE3F7")
    private val c3 = Color.parseColor("#9AA6CF")
    private val c4 = Color.parseColor("#454F86")
    private val anim: ValueAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    // crater: (x, y, radius) as fractions of the moon radius
    private val craters = arrayOf(
        floatArrayOf(-0.32f, -0.25f, 0.22f), floatArrayOf(0.30f, -0.05f, 0.17f), floatArrayOf(-0.05f, 0.38f, 0.20f),
        floatArrayOf(0.35f, 0.40f, 0.10f), floatArrayOf(-0.45f, 0.18f, 0.10f), floatArrayOf(0.05f, -0.52f, 0.09f)
    )

    fun setState(s: State) { state = s; invalidate() }
    fun setLevel(l: Float) { level = l.coerceIn(0f, 1f) }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val maxR = minOf(cx, cy)
        val accent = if (state == State.LISTEN) Neo.cyan else Neo.gold
        val breathe = 1f + 0.04f * Math.sin(phase * 2.0 * Math.PI).toFloat() + level * 0.12f
        val r = maxR * 0.60f * breathe

        // outer glow
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, maxR, intArrayOf(Neo.withAlpha(accent, 110), Neo.withAlpha(accent, 0)),
            floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, maxR, p)
        p.shader = null

        // rings while listening
        if (state == State.LISTEN) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = maxR * 0.035f
            for (i in 0 until 3) {
                val t = (phase + i / 3f) % 1f
                p.color = Neo.withAlpha(Neo.cyan, ((1f - t) * 150).toInt())
                canvas.drawCircle(cx, cy, r + (maxR - r) * t * (1f + level * 0.3f), p)
            }
        }

        // the moon
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx - r * 0.35f, cy - r * 0.35f, r * 1.5f, intArrayOf(c1, c2, c3, c4),
            floatArrayOf(0f, 0.35f, 0.72f, 1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r, p)
        p.shader = null
        for (cr in craters) {
            p.color = Color.argb(70, 70, 80, 130)
            canvas.drawCircle(cx + cr[0] * r, cy + cr[1] * r, cr[2] * r, p)
            p.color = Color.argb(60, 255, 255, 255)
            canvas.drawCircle(cx + cr[0] * r - cr[2] * r * 0.15f, cy + cr[1] * r - cr[2] * r * 0.15f, cr[2] * r * 0.8f, p)
        }

        // thin crescent shadow on the right side
        p.shader = RadialGradient(cx + r * 0.9f, cy, r * 1.3f, intArrayOf(Color.argb(0, 0, 0, 20), Color.argb(150, 5, 8, 30)),
            floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r, p)
        p.shader = null

        // rim
        p.style = Paint.Style.STROKE
        p.strokeWidth = maxR * 0.03f
        p.color = Neo.withAlpha(accent, 200)
        canvas.drawCircle(cx, cy, r, p)

        if (state == State.THINK) {
            p.strokeWidth = maxR * 0.07f
            p.strokeCap = Paint.Cap.ROUND
            p.color = Neo.cyan
            rect.set(cx - maxR * 0.86f, cy - maxR * 0.86f, cx + maxR * 0.86f, cy + maxR * 0.86f)
            canvas.drawArc(rect, phase * 360f, 100f, false, p)
        }
    }
}
