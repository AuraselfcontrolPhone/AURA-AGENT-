package com.example.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "smart_buttons")
data class SmartButtonEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val roomSection: String,
    val iconKey: String,
    val onUrl: String,
    val offUrl: String,
    val httpMethod: String = "GET",
    val voiceAliases: String = "",
    val isOn: Boolean = false,
    val lastStatusNote: String = "Ready",
    val lastTriggeredAt: Long = 0L,
    val sortOrder: Int = 0
)

@Entity(
    tableName = "device_memories",
    indices = [Index(value = ["memoryKey"], unique = true)]
)
data class DeviceMemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val memoryKey: String,
    val memoryType: String, // APP, SCREEN_ELEMENT, FACT, CORRECTION
    val appPackage: String,
    val screenTitle: String,
    val label: String,
    val actionHint: String,
    val extraData: String = "",
    val hitCount: Int = 1,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "command_reports")
data class CommandReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val source: String, // VOICE, TEXT, AUDIO_NOTE, ORB, CALL, MANUAL
    val userInput: String,
    val summaryReport: String,
    val actionTaken: String,
    val isSuccess: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "call_records")
data class CallRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val phoneNumber: String,
    val callerName: String,
    val ringCount: Int = 1,
    val wasAutoAnswered: Boolean = false,
    val transcript: String = "",
    val aiSummary: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "qa_messages")
data class QaMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val isUser: Boolean,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)
