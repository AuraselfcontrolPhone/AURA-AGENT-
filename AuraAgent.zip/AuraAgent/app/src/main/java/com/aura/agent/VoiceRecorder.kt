package com.aura.agent

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File

/** Records a voice message as AAC (like WhatsApp). Hold to record, release to send. */
class VoiceRecorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()

    fun start(): Boolean {
        return try {
            val f = File(ctx.cacheDir, "voice.aac")
            if (f.exists()) f.delete()
            val r = newRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.AAC_ADTS)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(16000)
            r.setAudioEncodingBitRate(32000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r
            file = f
            true
        } catch (e: Exception) {
            try { rec?.release() } catch (e2: Exception) {}
            rec = null
            false
        }
    }

    fun level(): Float {
        return try { ((rec?.maxAmplitude ?: 0) / 12000f).coerceIn(0f, 1f) } catch (e: Exception) { 0f }
    }

    /** Returns the recorded file, or null if too short/failed. */
    fun stop(): File? {
        val r = rec ?: return null
        rec = null
        return try {
            r.stop()
            r.release()
            file
        } catch (e: Exception) {
            try { r.release() } catch (e2: Exception) {}
            null
        }
    }
}
