package com.aura.agent

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/** Online check + "API quota is over" memory (so we stop calling and use the offline brain). */
object Net {
    @Volatile var blockedUntil = 0L

    fun online(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val nw = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(nw) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /** Can the AI (API) be used right now? */
    fun aiOk(ctx: Context): Boolean =
        Prefs.aiMode(ctx) != "offline" && online(ctx) && System.currentTimeMillis() > blockedUntil
}
