# SINA Mobile Build Kit

یہ kit آپ کو صرف Android موبائل، GitHub ویب سائٹ اور GitHub Actions استعمال کرکے موجودہ SINA v0.2 source project سے debug APK بنانے دیتی ہے۔

1. `SINA_AI_Assistant_v0.2.zip` کو اپنی GitHub repository کے root میں upload کریں۔
2. `.github/workflows/build-apk.yml` کو اسی path پر repository میں بنائیں۔
3. `موبائل_سے_گٹ_ہب_گائیڈ_اردو.md` کے مراحل پر عمل کریں۔

GitHub Actions cloud میں Java، Android SDK اور Gradle setup کرکے APK build کرتا ہے اور artifact کے طور پر محفوظ کرتا ہے۔
