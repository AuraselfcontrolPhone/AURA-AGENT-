package com.aura.agent

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * 3 overlay windows:
 *  - handle: thin gold pill at the bottom. Swipe it up -> chat panel.
 *  - panel: chat (log + input).
 *  - status: shown while the agent works (last line + Stop). Also shows Yes/No for confirmations.
 */
class ChatOverlay(
    private val ctx: Context,
    private val onGoal: (String) -> Unit,
    private val onStop: () -> Unit
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val gold = Color.parseColor("#D4A73A")
    private val coal = Color.parseColor("#F20D0C09")
    private val type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY

    private var handleV: View? = null
    private var panelV: View? = null
    private var statusV: View? = null
    private var logTv: TextView? = null
    private var scroll: ScrollView? = null
    private var statusTv: TextView? = null
    private var yesB: Button? = null
    private var noB: Button? = null
    private val lines = ArrayList<String>()
    private var running = false

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun params(w: Int, h: Int, flags: Int, gravity: Int, y: Int = 0) =
        WindowManager.LayoutParams(w, h, type, flags, PixelFormat.TRANSLUCENT).also {
            it.gravity = gravity
            it.y = y
        }

    private fun btn(t: String) = Button(ctx).apply {
        text = t; setTextColor(Color.BLACK); isAllCaps = false
        background = GradientDrawable().apply { setColor(gold); cornerRadius = dp(14).toFloat() }
        setPadding(dp(14), 0, dp(14), 0); minHeight = 0; minimumHeight = dp(36)
    }

    /* ---------------- handle ---------------- */

    fun showHandle(): Boolean = ui.post {
        if (handleV != null || running) return@post
        val bar = View(ctx).apply {
            background = GradientDrawable().apply { setColor(gold); cornerRadius = dp(3).toFloat() }
        }
        val box = FrameLayout(ctx)
        box.addView(bar, FrameLayout.LayoutParams(dp(110), dp(5), Gravity.CENTER))
        var downY = 0f
        var opened = false
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downY = e.rawY; opened = false }
                MotionEvent.ACTION_MOVE -> if (!opened && downY - e.rawY > dp(36)) { opened = true; showPanel() }
                MotionEvent.ACTION_UP -> if (!opened && Math.abs(e.rawY - downY) < dp(8)) showPanel()
            }
            true
        }
        val p = params(dp(170), dp(40),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, dp(46))
        wm.addView(box, p)
        handleV = box
    }

    private fun hideHandle() { handleV?.let { runCatching { wm.removeView(it) } }; handleV = null }

    /* ---------------- panel ---------------- */

    fun showPanel(): Boolean = ui.post {
        if (panelV != null || running) return@post
        hideHandle()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(coal)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(ctx).apply { text = "AURA"; setTextColor(gold); textSize = 20f }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(TextView(ctx).apply {
            text = "✕"; setTextColor(Color.GRAY); textSize = 20f; setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener { hidePanel(); showHandle() }
        })
        root.addView(head)

        val tv = TextView(ctx).apply { setTextColor(Color.WHITE); textSize = 14f; text = lines.joinToString("\n").ifEmpty { "جی استاد، بتائیں کیا کرنا ہے؟" } }
        val sv = ScrollView(ctx).apply { addView(tv) }
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        logTv = tv; scroll = sv

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(ctx).apply {
            hint = "لکھیں: وائی فائی آن کرو"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            imeOptions = EditorInfo.IME_ACTION_SEND; setSingleLine(true)
        }
        fun send() {
            val t = input.text.toString().trim()
            if (t.isEmpty()) return
            hidePanel()
            onGoal(t)
        }
        input.setOnEditorActionListener { _, _, _ -> send(); true }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("بھیجو").apply { setOnClickListener { send() } })
        root.addView(row)

        val h = (ctx.resources.displayMetrics.heightPixels * 0.5).toInt()
        val p = params(-1, h, WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, Gravity.BOTTOM)
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        wm.addView(root, p)
        panelV = root
        sv.post { sv.fullScroll(View.FOCUS_DOWN) }
        input.requestFocus()
    }

    private fun hidePanel() {
        panelV?.let { runCatching { wm.removeView(it) } }
        panelV = null; logTv = null; scroll = null
    }

    /* ---------------- status / confirm ---------------- */

    fun setRunning(on: Boolean): Boolean = ui.post {
        running = on
        if (on) {
            hidePanel(); hideHandle()
            if (statusV == null) buildStatus()
        } else {
            statusV?.let { runCatching { wm.removeView(it) } }
            statusV = null; statusTv = null
            showHandle()
        }
    }

    private fun buildStatus() {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply { setColor(coal); setStroke(dp(1), gold); cornerRadius = dp(20).toFloat() }
            setPadding(dp(14), dp(6), dp(8), dp(6))
        }
        val t = TextView(ctx).apply { setTextColor(Color.WHITE); textSize = 13f; maxLines = 3; text = "AURA کام کر رہا ہے..." }
        root.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        val yes = btn("ہاں").apply { visibility = View.GONE }
        val no = btn("نہیں").apply { visibility = View.GONE }
        val stop = btn("رکو")
        stop.setOnClickListener { onStop() }
        root.addView(yes); root.addView(no); root.addView(stop)
        yesB = yes; noB = no; statusTv = t
        val p = params(dp(320), -2,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, dp(60))
        wm.addView(root, p)
        statusV = root
    }

    suspend fun confirm(question: String): Boolean = suspendCancellableCoroutine { cont ->
        ui.post {
            if (statusV == null) buildStatus()
            statusTv?.text = question
            yesB?.visibility = View.VISIBLE
            noB?.visibility = View.VISIBLE
            fun answer(v: Boolean) {
                yesB?.visibility = View.GONE; noB?.visibility = View.GONE
                if (cont.isActive) cont.resume(v)
            }
            yesB?.setOnClickListener { answer(true) }
            noB?.setOnClickListener { answer(false) }
        }
    }

    /* ---------------- log ---------------- */

    fun log(line: String): Boolean = ui.post {
        lines.add(line)
        if (lines.size > 60) lines.removeAt(0)
        statusTv?.text = line
        logTv?.text = lines.joinToString("\n")
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }

    fun destroy() {
        hideHandle(); hidePanel()
        statusV?.let { runCatching { wm.removeView(it) } }
        statusV = null
    }
}
