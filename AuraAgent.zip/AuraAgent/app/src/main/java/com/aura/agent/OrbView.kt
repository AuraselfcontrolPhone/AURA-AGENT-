package com.aura.agent

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator

/** The glowing AI orb: idle (slow pulse), listening (cyan rings that follow your voice), thinking (spinning arc). */
class OrbView(ctx: Context) : View(ctx) {
    enum class State { IDLE, LISTEN, THINK }

    private var state: State = State.IDLE
    private var phase = 0f
    private var level = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val dark = Color.parseColor("#0A0620")
    private val anim: ValueAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1800
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    fun setState(s: State) { state = s; invalidate() }
    fun setLevel(l: Float) { level = l.coerceIn(0f, 1f) }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val maxR = minOf(cx, cy)
        val accent = if (state == State.LISTEN) Neo.cyan else Neo.gold
        val rings = if (state == State.LISTEN) 3 else 2

        p.style = Paint.Style.STROKE
        p.strokeWidth = maxR * 0.04f
        for (i in 0 until rings) {
            val t = (phase + i / rings.toFloat()) % 1f
            p.color = Neo.withAlpha(accent, ((1f - t) * 140).toInt())
            canvas.drawCircle(cx, cy, maxR * 0.62f + maxR * 0.38f * t * (1f + level * 0.4f), p)
        }

        val pulse = 1f + 0.05f * Math.sin(phase * 2.0 * Math.PI).toFloat() + level * 0.12f
        val r = maxR * 0.58f * pulse
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.3f, r * 1.4f,
            intArrayOf(Neo.goldHi, accent, dark), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r, p)
        p.shader = null

        if (state == State.THINK) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = maxR * 0.07f
            p.strokeCap = Paint.Cap.ROUND
            p.color = Neo.cyan
            rect.set(cx - maxR * 0.8f, cy - maxR * 0.8f, cx + maxR * 0.8f, cy + maxR * 0.8f)
            canvas.drawArc(rect, phase * 360f, 110f, false, p)
        }
    }
}
