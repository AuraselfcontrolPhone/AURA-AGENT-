package com.aura.agent

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

/** Colors and shapes of the futuristic look. */
object Neo {
    val gold: Int = Color.parseColor("#7C5CFF")
    val goldHi: Int = Color.parseColor("#B7A6FF")
    val cyan: Int = Color.parseColor("#35E6FF")
    val dim: Int = Color.parseColor("#8590B8")
    val text: Int = Color.parseColor("#E9EEFF")
    val line: Int = Color.parseColor("#337C5CFF")
    val stroke: Int = Color.parseColor("#667C5CFF")
    val card: Int = Color.parseColor("#1AFFFFFF")
    val red: Int = Color.parseColor("#FF6B6B")
    val green: Int = Color.parseColor("#3ECF8E")
    private val glassTop: Int = Color.parseColor("#F40C1030")
    private val glassBot: Int = Color.parseColor("#F4050818")

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun withAlpha(col: Int, a: Int): Int = Color.argb(a, Color.red(col), Color.green(col), Color.blue(col))

    fun panel(c: Context, topR: Int, botR: Int = 0): GradientDrawable {
        val t = dp(c, topR).toFloat()
        val b = dp(c, botR).toFloat()
        val d = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(glassTop, glassBot))
        d.cornerRadii = floatArrayOf(t, t, t, t, b, b, b, b)
        d.setStroke(dp(c, 1), stroke)
        return d
    }

    /** Panel with rounded left side (for the orders drawer that slides in from the right). */
    fun panelLeft(c: Context, r: Int): GradientDrawable {
        val x = dp(c, r).toFloat()
        val d = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(glassTop, glassBot))
        d.cornerRadii = floatArrayOf(x, x, 0f, 0f, 0f, 0f, x, x)
        d.setStroke(dp(c, 1), stroke)
        return d
    }

    fun pill(c: Context, fill: Int, strokeCol: Int, radius: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = dp(c, radius).toFloat()
        if (strokeCol != 0) d.setStroke(dp(c, 1), strokeCol)
        return d
    }
}
