package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.sinaDataStore by preferencesDataStore(name = "sina_settings")

data class SinaSettingsState(
    val alwaysSpeakEnabled: Boolean = false,
    val floatingOrbEnabled: Boolean = false,
    val autoCallSecondRingEnabled: Boolean = true,
    val openUrlsInBrowser: Boolean = false,
    val voiceLanguageMode: String = "AUTO", // AUTO, URDU, ENGLISH
    val ttsSpeechRate: Float = 1.0f,
    val ttsPitch: Float = 1.02f,
    val callGreetingText: String = "Assalam-o-Alaikum, this is Sina assistant. You were unreachable on the first ring — please leave your message and I will deliver a brief report."
)

class SinaPreferences(private val context: Context) {
    private object Keys {
        val ALWAYS_SPEAK = booleanPreferencesKey("always_speak_enabled")
        val FLOATING_ORB = booleanPreferencesKey("floating_orb_enabled")
        val AUTO_CALL_SECOND_RING = booleanPreferencesKey("auto_call_second_ring")
        val OPEN_URLS_BROWSER = booleanPreferencesKey("open_urls_browser")
        val VOICE_LANG = stringPreferencesKey("voice_lang_mode")
        val TTS_RATE = floatPreferencesKey("tts_rate")
        val TTS_PITCH = floatPreferencesKey("tts_pitch")
        val CALL_GREETING = stringPreferencesKey("call_greeting_text")
    }

    val settingsFlow: Flow<SinaSettingsState> = context.sinaDataStore.data.map { prefs ->
        SinaSettingsState(
            alwaysSpeakEnabled = prefs[Keys.ALWAYS_SPEAK] ?: false,
            floatingOrbEnabled = prefs[Keys.FLOATING_ORB] ?: false,
            autoCallSecondRingEnabled = prefs[Keys.AUTO_CALL_SECOND_RING] ?: true,
            openUrlsInBrowser = prefs[Keys.OPEN_URLS_BROWSER] ?: false,
            voiceLanguageMode = prefs[Keys.VOICE_LANG] ?: "AUTO",
            ttsSpeechRate = prefs[Keys.TTS_RATE] ?: 1.0f,
            ttsPitch = prefs[Keys.TTS_PITCH] ?: 1.02f,
            callGreetingText = prefs[Keys.CALL_GREETING]
                ?: "Assalam-o-Alaikum, this is Sina assistant. Please share your message and I will pass a brief summary right away."
        )
    }

    suspend fun setAlwaysSpeak(enabled: Boolean) {
        context.sinaDataStore.edit { it[Keys.ALWAYS_SPEAK] = enabled }
    }

    suspend fun setFloatingOrb(enabled: Boolean) {
        context.sinaDataStore.edit { it[Keys.FLOATING_ORB] = enabled }
    }

    suspend fun setAutoCallSecondRing(enabled: Boolean) {
        context.sinaDataStore.edit { it[Keys.AUTO_CALL_SECOND_RING] = enabled }
    }

    suspend fun setOpenUrlsInBrowser(enabled: Boolean) {
        context.sinaDataStore.edit { it[Keys.OPEN_URLS_BROWSER] = enabled }
    }

    suspend fun setVoiceLanguageMode(mode: String) {
        context.sinaDataStore.edit { it[Keys.VOICE_LANG] = mode }
    }

    suspend fun setTtsRateAndPitch(rate: Float, pitch: Float) {
        context.sinaDataStore.edit {
            it[Keys.TTS_RATE] = rate.coerceIn(0.6f, 1.5f)
            it[Keys.TTS_PITCH] = pitch.coerceIn(0.7f, 1.4f)
        }
    }

    suspend fun setCallGreeting(text: String) {
        context.sinaDataStore.edit { it[Keys.CALL_GREETING] = text }
    }
}
