# AURA Agent (Android)

## چلانے کا طریقہ
1. Android Studio میں `AuraAgent` فولڈر Open کریں، Gradle sync ہونے دیں۔
2. فون میں Developer options > USB debugging آن کریں، USB سے جوڑیں، Run دبائیں۔
3. فون میں AURA ایپ کھولیں، Gemini API key ڈالیں (aistudio.google.com)، "محفوظ کرو"۔
4. "Accessibility کھولو" > AURA Agent چالو کریں۔
5. کسی بھی ایپ میں نیچے سنہری لکیر اوپر سلائیڈ کریں > لکھیں "وائی فائی آن کرو"۔

## فائلیں
- AuraService.kt : آنکھیں اور ہاتھ (اسکرین پڑھنا، ٹیپ، ٹائپ، سلائیڈ)
- ChatOverlay.kt : نیچے سے سلائیڈ والی چیٹ، رکو بٹن، ہاں/نہیں
- AgentLoop.kt   : دیکھو > سوچو > کرو > جانچو چکر
- AiClient.kt    : Gemini یا Claude API کال (tools کے ساتھ)
- Memory.kt      : سیکھی ہوئی ترتیب (SQLite)
- SafetyGate.kt  : پیسے/ڈیلیٹ/پاسورڈ پر اجازت

## نوٹس
- API key ٹیسٹنگ کے لیے فون میں ہے۔ بعد میں اپنا چھوٹا سرور بنا کر "API URL" بدل دیں۔
- Infinix/Transsion فون بیٹری کی وجہ سے سروس بند کر دیتے ہیں: Settings > Battery میں AURA کو "No restrictions" کریں۔
