package com.aura.agent

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Voice level bars shown while recording. */
class WaveView(ctx: Context) : View(ctx) {
    private val bars = FloatArray(30)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init { p.strokeCap = Paint.Cap.ROUND }

    fun push(l: Float) {
        System.arraycopy(bars, 1, bars, 0, bars.size - 1)
        bars[bars.size - 1] = l.coerceIn(0.08f, 1f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val step = w / bars.size
        p.strokeWidth = step * 0.5f
        for (i in bars.indices) {
            p.color = if (i % 2 == 0) Neo.cyan else Neo.goldHi
            val bh = h * bars[i]
            val x = step * i + step / 2f
            canvas.drawLine(x, (h - bh) / 2f, x, (h + bh) / 2f, p)
        }
    }
}
