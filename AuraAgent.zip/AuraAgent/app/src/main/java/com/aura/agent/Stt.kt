package com.aura.agent

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/** Phone's own speech recognition: free, no API quota. Works offline if the Urdu offline pack is installed. */
object Stt {
    fun available(ctx: Context): Boolean = SpeechRecognizer.isRecognitionAvailable(ctx)

    /** Listens for one sentence. Returns the text, or null if nothing was understood. */
    suspend fun listenOnce(ctx: Context, preferOffline: Boolean): String? = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine<String?> { cont ->
            val rec = SpeechRecognizer.createSpeechRecognizer(ctx)
            fun finish(r: String?) {
                try { rec.destroy() } catch (e: Exception) {}
                if (cont.isActive) cont.resume(r)
            }
            rec.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { finish(null) }
                override fun onResults(results: Bundle?) {
                    val l = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    finish(l?.firstOrNull())
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
            try { rec.startListening(i) } catch (e: Exception) { finish(null) }
            cont.invokeOnCancellation { try { rec.cancel(); rec.destroy() } catch (e: Exception) {} }
        }
    }
}
