package com.example.automation

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.data.SinaDatabase
import com.example.data.SinaPreferences
import com.example.data.SinaRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SinaAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "SinaAccessService"

        @Volatile
        var instance: SinaAccessibilityService? = null
            private set

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private val _currentPackage = MutableStateFlow("")
        val currentPackage: StateFlow<String> = _currentPackage.asStateFlow()
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var lastScanTimeMs = 0L

    private val repository by lazy {
        val db = SinaDatabase.getInstance(applicationContext)
        SinaRepository(applicationContext, db.sinaDao(), SinaPreferences(applicationContext))
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isConnected.value = true
        Log.i(TAG, "Sina Accessibility Memory Service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString().orEmpty()
        if (pkg.isNotBlank() && pkg != packageName) {
            _currentPackage.value = pkg
        }

        val now = System.currentTimeMillis()
        if (now - lastScanTimeMs < 1400L) return
        lastScanTimeMs = now

        val root = rootInActiveWindow ?: return
        val screenClass = event?.className?.toString()?.substringAfterLast('.').orEmpty()
        val capturedNodes = mutableListOf<Triple<String, String, String>>()
        collectInteractiveNodes(root, capturedNodes, limit = 18)

        if (capturedNodes.isNotEmpty() && pkg != packageName) {
            serviceScope.launch {
                for ((label, hint, bounds) in capturedNodes) {
                    repository.rememberScreenElement(
                        appPackage = pkg,
                        screenTitle = screenClass.ifBlank { pkg },
                        elementLabel = label,
                        actionHint = hint,
                        bounds = bounds
                    )
                }
            }
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "Sina Accessibility Service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        _isConnected.value = false
        serviceScope.cancel()
    }

    fun captureVisibleLabels(): List<String> {
        val root = rootInActiveWindow ?: return emptyList()
        val list = mutableListOf<Triple<String, String, String>>()
        collectInteractiveNodes(root, list, limit = 25)
        return list.map { it.first }.distinct()
    }

    fun computeScreenSignature(): String {
        val pkg = _currentPackage.value
        val labels = captureVisibleLabels().take(8).joinToString("|")
        return "$pkg::$labels"
    }

    fun findAndClickLabel(targetLabel: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val matches = root.findAccessibilityNodeInfosByText(targetLabel)
        for (node in matches) {
            if (clickNodeOrParent(node)) return true
        }
        return false
    }

    /**
     * Inserts digits or text cleanly into the focused or first editable field
     * so Sina never gets confused when entering phone numbers or search queries.
     */
    fun typeTextSmartly(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        val targetNode = if (focused != null && focused.isEditable) {
            focused
        } else {
            findFirstEditable(root)
        } ?: return false

        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return targetNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scrollForward(): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findFirstScrollable(root) ?: return false
        return scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    fun pressSystemBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    private fun clickNodeOrParent(node: AccessibilityNodeInfo?): Boolean {
        var curr = node
        var depth = 0
        while (curr != null && depth < 5) {
            if (curr.isClickable) {
                return curr.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            curr = curr.parent
            depth++
        }
        return false
    }

    private fun findFirstEditable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val found = findFirstEditable(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    private fun findFirstScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val found = findFirstScrollable(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    private fun collectInteractiveNodes(
        node: AccessibilityNodeInfo?,
        out: MutableList<Triple<String, String, String>>,
        limit: Int
    ) {
        if (node == null || out.size >= limit) return
        val label = (node.text?.toString() ?: node.contentDescription?.toString()).orEmpty().trim()
        if (label.isNotBlank() && (node.isClickable || node.isEditable)) {
            val rect = Rect()
            node.getBoundsInScreen(rect)
            val kind = if (node.isEditable) "Editable Input" else "Clickable Element"
            out.add(Triple(label.take(48), "$kind on screen", "${rect.left},${rect.top}-${rect.right},${rect.bottom}"))
        }
        for (i in 0 until node.childCount) {
            if (out.size >= limit) break
            collectInteractiveNodes(node.getChild(i), out, limit)
        }
    }
}
