package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.SinaSettingsState
import com.example.data.SmartButtonEntity
import com.example.ui.theme.BorderGlowSlate
import com.example.ui.theme.CosmicObsidian
import com.example.ui.theme.DeepSpaceNavy
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldPulse
import com.example.ui.theme.GlassSlate
import com.example.ui.theme.GlassSlateHigh
import com.example.ui.theme.LunarCyan
import com.example.ui.theme.LunarSilver
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.RoseAlert

@Composable
fun SettingsScreen(
    buttons: List<SmartButtonEntity>,
    settings: SinaSettingsState,
    isAccessibilityConnected: Boolean,
    hasOverlayPermission: Boolean,
    hasMicPermission: Boolean,
    onEditButton: (SmartButtonEntity?) -> Unit,
    onDeleteButton: (SmartButtonEntity) -> Unit,
    onToggleOpenInBrowser: (Boolean) -> Unit,
    onVoiceLangChange: (String) -> Unit,
    onTtsRatePitchChange: (Float, Float) -> Unit,
    onTestNaturalVoice: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onOpenOverlaySettings: () -> Unit,
    onRequestMicPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    var rate by remember(settings.ttsSpeechRate) { mutableFloatStateOf(settings.ttsSpeechRate) }
    var pitch by remember(settings.ttsPitch) { mutableFloatStateOf(settings.ttsPitch) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // SECTION 1: Smart Home Buttons & ON/OFF URLs
            item(key = "settings_buttons_header") {
                SectionContainer(
                    title = "SMART HOME BUTTONS & URLS",
                    subtitle = "Customize names, rooms, and ON / OFF URLs for every button"
                ) {
                    Button(
                        onClick = { onEditButton(null) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("settings_add_device_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = LunarCyan,
                            contentColor = CosmicObsidian
                        )
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Add New Smart Home Button")
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Open URLs in Browser",
                                style = MaterialTheme.typography.titleMedium,
                                color = LunarSilver
                            )
                            Text(
                                text = if (settings.openUrlsInBrowser) {
                                    "Opens browser when triggering URL"
                                } else {
                                    "Silent background HTTP (instant, stays in current screen)"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedSilver
                            )
                        }
                        Switch(
                            checked = settings.openUrlsInBrowser,
                            onCheckedChange = onToggleOpenInBrowser,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CosmicObsidian,
                                checkedTrackColor = LunarCyan
                            )
                        )
                    }
                }
            }

            items(buttons, key = { it.id }) { btn ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = GlassSlate,
                    border = BorderStroke(1.dp, BorderGlowSlate)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${btn.name} (${btn.roomSection})",
                                style = MaterialTheme.typography.titleMedium,
                                color = LunarSilver
                            )
                            Text(
                                text = "ON: ${btn.onUrl}",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldPulse,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "OFF: ${btn.offUrl}",
                                style = MaterialTheme.typography.labelSmall,
                                color = RoseAlert,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Row {
                            IconButton(
                                onClick = { onEditButton(btn) },
                                modifier = Modifier.testTag("settings_edit_${btn.id}")
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit ${btn.name}", tint = LunarCyan)
                            }
                            IconButton(
                                onClick = { onDeleteButton(btn) },
                                modifier = Modifier.testTag("settings_delete_${btn.id}")
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete ${btn.name}", tint = RoseAlert)
                            }
                        }
                    }
                }
            }

            // SECTION 2: Natural Voice & TTS Tuning
            item(key = "settings_voice") {
                SectionContainer(
                    title = "NATURAL VOICE & LANGUAGE",
                    subtitle = "Clear, natural Urdu & English speech output"
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("AUTO", "URDU", "ENGLISH").forEach { mode ->
                            FilterChip(
                                selected = settings.voiceLanguageMode == mode,
                                onClick = { onVoiceLangChange(mode) },
                                label = { Text(mode) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = LunarCyan,
                                    selectedLabelColor = CosmicObsidian,
                                    labelColor = LunarSilver
                                )
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Text("Speech Speed: ${"%.2f".format(rate)}x", style = MaterialTheme.typography.labelSmall, color = LunarSilver)
                    Slider(
                        value = rate,
                        onValueChange = { rate = it },
                        onValueChangeFinished = { onTtsRatePitchChange(rate, pitch) },
                        valueRange = 0.7f..1.4f,
                        colors = SliderDefaults.colors(thumbColor = LunarCyan, activeTrackColor = LunarCyan)
                    )

                    Text("Voice Pitch: ${"%.2f".format(pitch)}", style = MaterialTheme.typography.labelSmall, color = LunarSilver)
                    Slider(
                        value = pitch,
                        onValueChange = { pitch = it },
                        onValueChangeFinished = { onTtsRatePitchChange(rate, pitch) },
                        valueRange = 0.8f..1.3f,
                        colors = SliderDefaults.colors(thumbColor = ElectricViolet, activeTrackColor = ElectricViolet)
                    )

                    OutlinedButton(
                        onClick = onTestNaturalVoice,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, LunarCyan),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Test Natural Sina Voice", color = LunarCyan)
                    }
                }
            }

            // SECTION 3: System Capabilities Hub
            item(key = "settings_capabilities") {
                SectionContainer(
                    title = "SYSTEM AUTOMATION CAPABILITIES",
                    subtitle = "Enable background Moon Orb, Always-Speak, and Visual Memory"
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        CapabilityRow(
                            title = "Visual Screen Memory (Accessibility)",
                            status = if (isAccessibilityConnected) "Connected" else "Tap to Enable",
                            active = isAccessibilityConnected,
                            onClick = onOpenAccessibilitySettings
                        )
                        CapabilityRow(
                            title = "Floating Moon Orb Everywhere",
                            status = if (hasOverlayPermission) "Allowed" else "Tap to Allow",
                            active = hasOverlayPermission,
                            onClick = onOpenOverlaySettings
                        )
                        CapabilityRow(
                            title = "Always-Speak & Voice Note Mic",
                            status = if (hasMicPermission) "Granted" else "Tap to Grant",
                            active = hasMicPermission,
                            onClick = onRequestMicPermission
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CapabilityRow(
    title: String,
    status: String,
    active: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = Color(0xAA0B1325),
        border = BorderStroke(1.dp, if (active) EmeraldPulse else BorderGlowSlate)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = LunarSilver, modifier = Modifier.weight(1f))
            Text(status, style = MaterialTheme.typography.labelLarge, color = if (active) EmeraldPulse else LunarCyan)
        }
    }
}

/**
 * Two-Tab Button Settings Modal ("ہر بٹن کی سیٹنگز میں دو ٹیبز ہوں آن اور آف کی")
 * Lets the user configure Device Name, Room, Aliases, ON Command URL, and OFF Command URL.
 */
@Composable
fun ButtonEditorDialog(
    initialButton: SmartButtonEntity,
    onDismiss: () -> Unit,
    onSave: (SmartButtonEntity) -> Unit
) {
    var name by remember(initialButton) { mutableStateOf(initialButton.name) }
    var room by remember(initialButton) { mutableStateOf(initialButton.roomSection) }
    var iconKey by remember(initialButton) { mutableStateOf(initialButton.iconKey) }
    var aliases by remember(initialButton) { mutableStateOf(initialButton.voiceAliases) }
    var onUrl by remember(initialButton) { mutableStateOf(initialButton.onUrl) }
    var offUrl by remember(initialButton) { mutableStateOf(initialButton.offUrl) }
    var httpMethod by remember(initialButton) { mutableStateOf(initialButton.httpMethod) }
    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0 = ON Tab, 1 = OFF Tab

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GlassSlateHigh,
        title = {
            Text(
                text = if (initialButton.id == 0L) "New Smart Button" else "Edit ${initialButton.name}",
                color = LunarSilver
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Button Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("editor_button_name"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LunarCyan,
                        unfocusedBorderColor = BorderGlowSlate,
                        focusedTextColor = LunarSilver,
                        unfocusedTextColor = LunarSilver
                    )
                )
                OutlinedTextField(
                    value = room,
                    onValueChange = { room = it },
                    label = { Text("Section / Room") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LunarCyan,
                        unfocusedBorderColor = BorderGlowSlate,
                        focusedTextColor = LunarSilver,
                        unfocusedTextColor = LunarSilver
                    )
                )
                OutlinedTextField(
                    value = aliases,
                    onValueChange = { aliases = it },
                    label = { Text("Voice Aliases (comma separated)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LunarCyan,
                        unfocusedBorderColor = BorderGlowSlate,
                        focusedTextColor = LunarSilver,
                        unfocusedTextColor = LunarSilver
                    )
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("light", "ac", "fan", "gate", "power").forEach { key ->
                        FilterChip(
                            selected = iconKey == key,
                            onClick = { iconKey = key },
                            label = { Text(key) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = LunarCyan,
                                selectedLabelColor = CosmicObsidian,
                                labelColor = LunarSilver
                            )
                        )
                    }
                }

                // Explicit Two Tabs: ON Command & OFF Command
                TabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = DeepSpaceNavy,
                    contentColor = LunarCyan
                ) {
                    Tab(
                        selected = selectedTabIndex == 0,
                        onClick = { selectedTabIndex = 0 },
                        text = { Text("ON Tab (آن)") },
                        modifier = Modifier.testTag("editor_tab_on")
                    )
                    Tab(
                        selected = selectedTabIndex == 1,
                        onClick = { selectedTabIndex = 1 },
                        text = { Text("OFF Tab (آف)") },
                        modifier = Modifier.testTag("editor_tab_off")
                    )
                }

                if (selectedTabIndex == 0) {
                    OutlinedTextField(
                        value = onUrl,
                        onValueChange = { onUrl = it },
                        label = { Text("ON Command URL") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("editor_on_url"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EmeraldPulse,
                            unfocusedBorderColor = BorderGlowSlate,
                            focusedTextColor = LunarSilver,
                            unfocusedTextColor = LunarSilver
                        )
                    )
                } else {
                    OutlinedTextField(
                        value = offUrl,
                        onValueChange = { offUrl = it },
                        label = { Text("OFF Command URL") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("editor_off_url"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RoseAlert,
                            unfocusedBorderColor = BorderGlowSlate,
                            focusedTextColor = LunarSilver,
                            unfocusedTextColor = LunarSilver
                        )
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("GET", "POST").forEach { m ->
                        FilterChip(
                            selected = httpMethod == m,
                            onClick = { httpMethod = m },
                            label = { Text("HTTP $m") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricViolet,
                                selectedLabelColor = CosmicObsidian,
                                labelColor = LunarSilver
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        initialButton.copy(
                            name = name.ifBlank { "Smart Device" },
                            roomSection = room.ifBlank { "General" },
                            iconKey = iconKey,
                            voiceAliases = aliases,
                            onUrl = onUrl.trim(),
                            offUrl = offUrl.trim(),
                            httpMethod = httpMethod
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = LunarCyan,
                    contentColor = CosmicObsidian
                ),
                modifier = Modifier.testTag("editor_save_button")
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = MutedSilver)
            }
        }
    )
}
