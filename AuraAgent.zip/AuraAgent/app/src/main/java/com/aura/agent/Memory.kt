package com.aura.agent

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** AURA's memory: successful recipes per goal, and which on-screen elements it used per app. */
class Memory private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "aura_mem.db", null, 1) {

    companion object {
        @Volatile private var inst: Memory? = null
        fun get(ctx: Context): Memory =
            inst ?: synchronized(this) { inst ?: Memory(ctx.applicationContext).also { inst = it } }

        private fun norm(s: String) =
            s.lowercase().replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").replace(Regex("\\s+"), " ").trim()
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE recipes(goal TEXT PRIMARY KEY, steps TEXT, uses INTEGER, ts INTEGER)")
        db.execSQL("CREATE TABLE elements(pkg TEXT, label TEXT, uses INTEGER, PRIMARY KEY(pkg,label))")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun saveRecipe(goal: String, steps: List<String>) {
        if (steps.isEmpty()) return
        val key = norm(goal)
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO recipes VALUES(?,?,COALESCE((SELECT uses FROM recipes WHERE goal=?),0)+1,?)",
            arrayOf<Any?>(key, steps.joinToString("\n"), key, System.currentTimeMillis())
        )
    }

    fun bumpElement(pkg: String, label: String) {
        if (label.isBlank()) return
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO elements VALUES(?,?,COALESCE((SELECT uses FROM elements WHERE pkg=? AND label=?),0)+1)",
            arrayOf<Any?>(pkg, label, pkg, label)
        )
    }

    fun findRecipe(goal: String): String? {
        val key = norm(goal)
        val db = readableDatabase
        db.rawQuery("SELECT steps FROM recipes WHERE goal=?", arrayOf(key)).use {
            if (it.moveToFirst()) return it.getString(0)
        }
        val a = key.split(" ").toSet()
        var best: String? = null
        var bestScore = 0.0
        db.rawQuery("SELECT goal, steps FROM recipes", null).use {
            while (it.moveToNext()) {
                val b = it.getString(0).split(" ").toSet()
                val score = a.intersect(b).size.toDouble() / a.union(b).size.coerceAtLeast(1)
                if (score > bestScore) { bestScore = score; best = it.getString(1) }
            }
        }
        return if (bestScore >= 0.7) best else null
    }

    fun hints(pkg: String): String {
        val sb = StringBuilder()
        readableDatabase.rawQuery(
            "SELECT label FROM elements WHERE pkg=? ORDER BY uses DESC LIMIT 12", arrayOf(pkg)
        ).use { while (it.moveToNext()) sb.append("\"").append(it.getString(0)).append("\" ") }
        return sb.toString().trim()
    }
}
