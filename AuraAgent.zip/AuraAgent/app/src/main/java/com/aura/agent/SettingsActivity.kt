package com.aura.agent

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.concurrent.thread
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Settings screen: key, voice, call assistant, permissions, moon, icon. */
class SettingsActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var hideBtn: Button

    private fun dp(v: Int): Int = Neo.dp(this, v)
    private val aliasName = "com.aura.agent.LauncherAlias"

    private fun iconHidden(): Boolean =
        packageManager.getComponentEnabledSetting(ComponentName(this, aliasName)) == PackageManager.COMPONENT_ENABLED_STATE_DISABLED

    private fun setIconHidden(hide: Boolean) {
        packageManager.setComponentEnabledSetting(
            ComponentName(this, aliasName),
            if (hide) PackageManager.COMPONENT_ENABLED_STATE_DISABLED else PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )
    }

    private fun askPermissions() {
        val list = ArrayList<String>()
        list.add(Manifest.permission.RECORD_AUDIO)
        list.add(Manifest.permission.READ_PHONE_STATE)
        list.add(Manifest.permission.ANSWER_PHONE_CALLS)
        list.add(Manifest.permission.READ_CALL_LOG)
        list.add(Manifest.permission.READ_CONTACTS)
        list.add(Manifest.permission.CALL_PHONE)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(list.toTypedArray(), 7)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#070A1C")
        val bg = Color.parseColor("#070A1C")

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setBackgroundColor(bg)
        root.setPadding(dp(16), dp(36), dp(16), dp(24))

        fun label(t: String): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = 13f
            v.setTextColor(Neo.cyan)
            v.setPadding(dp(4), dp(14), 0, dp(4))
            return v
        }
        fun field(hintText: String, value: String, secret: Boolean, lines: Int): EditText {
            val e = EditText(this)
            e.hint = hintText
            e.setText(value)
            e.setTextColor(Color.WHITE)
            e.setHintTextColor(Neo.dim)
            e.textSize = 15f
            e.background = Neo.pill(this, Neo.card, Neo.stroke, 14)
            e.setPadding(dp(14), dp(10), dp(14), dp(10))
            if (lines > 1) {
                e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                e.minLines = lines
                e.gravity = Gravity.TOP or Gravity.START
            } else {
                e.setSingleLine(true)
                e.inputType = InputType.TYPE_CLASS_TEXT or (if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else 0)
            }
            return e
        }
        fun button(t: String, fill: Int, click: () -> Unit): Button {
            val b = Button(this)
            b.text = t
            b.isAllCaps = false
            b.setTextColor(Color.WHITE)
            b.background = Neo.pill(this, fill, 0, 14)
            b.setOnClickListener { click() }
            val p = LinearLayout.LayoutParams(-1, -2)
            p.setMargins(0, dp(8), 0, 0)
            b.layoutParams = p
            return b
        }
        fun switch(t: String, on: Boolean, change: (Boolean) -> Unit): Switch {
            val s = Switch(this)
            s.text = t
            s.setTextColor(Color.WHITE)
            s.textSize = 15f
            s.isChecked = on
            s.setPadding(0, dp(10), 0, dp(10))
            s.setOnCheckedChangeListener { _, c -> change(c) }
            return s
        }

        val title = TextView(this)
        title.text = "SEENA"
        title.textSize = 38f
        title.setTextColor(Neo.goldHi)
        title.typeface = Typeface.DEFAULT_BOLD
        title.letterSpacing = 0.2f
        root.addView(title)
        status = TextView(this)
        status.textSize = 14f
        status.setPadding(0, dp(4), 0, dp(8))
        root.addView(status)

        root.addView(label("API key (Google AI Studio سے)"))
        val key = field("AIza... یا AQ....", Prefs.apiKey(this), true, 1)
        root.addView(key)
        root.addView(label("Model"))
        val model = field("gemini-3.7-flash", Prefs.model(this), false, 1)
        root.addView(model)

        root.addView(label("SEENA کی آواز"))
        val voices = LinearLayout(this)
        voices.orientation = LinearLayout.HORIZONTAL
        val vChips = ArrayList<TextView>()
        fun paintVoices() {
            val cur = Prefs.voice(this)
            vChips.forEach {
                val on = it.text.toString() == cur
                it.setTextColor(Color.WHITE)
                it.background = if (on) Neo.pill(this, Neo.gold, 0, 14) else Neo.pill(this, 0, Neo.stroke, 14)
            }
        }
        listOf("Kore", "Puck", "Charon", "Aoede", "Fenrir").forEach { n ->
            val c = TextView(this)
            c.text = n
            c.textSize = 13f
            c.setPadding(dp(12), dp(6), dp(12), dp(6))
            c.setOnClickListener { Prefs.setStr(this, "voice", n); paintVoices() }
            val p = LinearLayout.LayoutParams(-2, -2)
            p.setMargins(0, 0, dp(6), 0)
            voices.addView(c, p)
            vChips.add(c)
        }
        paintVoices()
        root.addView(voices)

        root.addView(label("آپ کا نام (کال پر SEENA یہ نام بتائے گا)"))
        val owner = field("مثلاً احمد", Prefs.owner(this), false, 1)
        root.addView(owner)
        root.addView(label("کال پر SEENA کو ہدایت (آپ کی طرف سے کیا کہنا ہے)"))
        val brief = field("", Prefs.brief(this), false, 3)
        root.addView(brief)

        root.addView(switch("چاند (تیرتا ہوا گولا) اسکرین پر دکھاؤ", Prefs.getBool(this, "orb", true)) {
            Prefs.setBool(this, "orb", it)
            val o = AuraService.instance?.overlay
            if (it) o?.showIdle() else o?.hideOrb()
        })
        root.addView(switch("غائب موڈ: SEENA اسکرین پر نظر نہ آئے (چھونے پر ظاہر ہو)", Prefs.ghost(this)) { Prefs.setBool(this, "ghost", it) })
        root.addView(switch("SEENA آواز میں جواب دے", Prefs.speakReplies(this)) { Prefs.setBool(this, "speak", it) })
        root.addView(switch("ایک بار کال نہ اٹھاؤں تو دوسری بار SEENA اٹھائے", Prefs.callAuto(this)) { Prefs.setBool(this, "callAuto", it) })

        // ---- offline brain / AI mode ----
        root.addView(label("AI کا انداز (API کی حد بچانے کے لیے)"))
        val modeRow = LinearLayout(this)
        modeRow.orientation = LinearLayout.HORIZONTAL
        val modeChips = ArrayList<TextView>()
        val modeVals = listOf("offline", "auto", "online")
        fun paintModes() {
            val cur = Prefs.aiMode(this)
            for (i in modeChips.indices) {
                modeChips[i].setTextColor(Color.WHITE)
                modeChips[i].background = if (modeVals[i] == cur) Neo.pill(this, Neo.gold, 0, 14) else Neo.pill(this, 0, Neo.stroke, 14)
            }
        }
        listOf("آف لائن صرف", "خودکار (بہتر)", "آن لائن ہمیشہ").forEachIndexed { i, nm ->
            val c = TextView(this)
            c.text = nm
            c.textSize = 13f
            c.setPadding(dp(12), dp(6), dp(12), dp(6))
            c.setOnClickListener { Prefs.setStr(this, "aiMode", modeVals[i]); paintModes() }
            val lp = LinearLayout.LayoutParams(-2, -2)
            lp.setMargins(0, 0, dp(6), 0)
            modeRow.addView(c, lp)
            modeChips.add(c)
        }
        paintModes()
        root.addView(modeRow)
        root.addView(switch("آواز آف لائن بولے (فون کی اردو آواز، API نہیں لگتی)", Prefs.offlineVoice(this)) { Prefs.setBool(this, "offVoice", it) })
        root.addView(switch("نام \"سینا\" لینے پر ہی سنے (ہمیشہ سننا میں)", Prefs.wakeWord(this)) { Prefs.setBool(this, "wake", it) })

        // ---- WhatsApp auto reply ----
        root.addView(label("واٹس ایپ: آنے والے میسج پڑھنا اور خودکار جواب"))
        root.addView(button("Notification access دیں (میسج پڑھنے کے لیے)", Color.parseColor("#2B3566")) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(switch("میسج کا خودکار جواب دو (اسکرین بند ہو تب بھی)", Prefs.autoReply(this)) { Prefs.setBool(this, "autoReply", it) })
        root.addView(switch("جواب AI سے لکھواؤ (API لگے گی، ورنہ تیار جملہ)", Prefs.getBool(this, "autoReplyAI", false)) { Prefs.setBool(this, "autoReplyAI", it) })
        val replyF = field("خودکار جواب کا جملہ", Prefs.autoReplyText(this), false, 2)
        root.addView(replyF)

        // ---- calls ----
        root.addView(label("کال: 10 سیکنڈ نہ اٹھے تو SEENA کیا کہے ({owner} = آپ کا نام)"))
        val callF = field("", Prefs.callMsg(this), false, 3)
        root.addView(callF)

        // ---- knowledge website ----
        root.addView(label("علم کی ویب سائٹ (اس کی بنیاد پر سوالوں کے جواب)"))
        val kbF = field("https://...", Prefs.getStr(this, "kbUrl", ""), false, 1)
        root.addView(kbF)
        root.addView(button("ویب سائٹ اپڈیٹ کرو (فون میں محفوظ ہو گی)", Color.parseColor("#2B3566")) {
            Prefs.setStr(this, "kbUrl", kbF.text.toString())
            Toast.makeText(this, "ڈاؤنلوڈ ہو رہی ہے...", Toast.LENGTH_SHORT).show()
            thread {
                val n = try { Knowledge.refresh(this) } catch (e: Exception) { -1 }
                runOnUiThread { Toast.makeText(this, if (n < 0) "ویب سائٹ نہیں کھلی" else "$n حصے محفوظ ہوئے", Toast.LENGTH_LONG).show() }
            }
        })

        // ---- moon picture ----
        root.addView(label("چاند کی تصویر"))
        root.addView(button("اپنی تصویر چنیں", Color.parseColor("#2B3566")) {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            startActivityForResult(i, 91)
        })
        root.addView(button("اصل چاند واپس لگاؤ", Color.parseColor("#2B3566")) {
            File(filesDir, "moon.png").delete()
            OrbView.reloadMoon()
            Toast.makeText(this, "اصل چاند لگ گیا", Toast.LENGTH_SHORT).show()
        })

        fun save() {
            Prefs.setApiKey(this, key.text.toString())
            Prefs.setModel(this, model.text.toString())
            Prefs.setStr(this, "owner", owner.text.toString())
            Prefs.setStr(this, "brief", brief.text.toString())
            Prefs.setStr(this, "autoReplyText", replyF.text.toString())
            Prefs.setStr(this, "callMsg", callF.text.toString())
        }

        root.addView(button("محفوظ کرو", Neo.gold) { save(); Toast.makeText(this, "محفوظ ہو گیا", Toast.LENGTH_SHORT).show() })
        root.addView(button("اجازتیں دیں (مائیک، فون، کانٹیکٹس)", Color.parseColor("#2B3566")) { askPermissions() })
        root.addView(button("Accessibility کھولو", Color.parseColor("#2B3566")) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(button("آواز آزمائیں", Color.parseColor("#2B3566")) {
            save()
            CoroutineScope(Dispatchers.Main).launch {
                Speaker.speak(this@SettingsActivity, "السلام علیکم! میں سینا ہوں، آپ کا ذاتی اسسٹنٹ۔ میری آواز اب ایسی سنائی دے گی۔")
            }
        })
        root.addView(button("فون دوبارہ اسٹڈی کرو (ایپس اور سیٹنگ سیکھے)", Color.parseColor("#2B3566")) {
            val svc = AuraService.instance
            if (svc == null) Toast.makeText(this, "پہلے Accessibility میں SEENA چالو کریں", Toast.LENGTH_SHORT).show()
            else { Toast.makeText(this, "SEENA فون اسٹڈی کر رہا ہے...", Toast.LENGTH_SHORT).show(); svc.study() }
        })
        hideBtn = button("", Color.parseColor("#2B3566")) {
            setIconHidden(!iconHidden())
            refresh()
        }
        root.addView(hideBtn)

        val tip = TextView(this)
        tip.text = "آئیکن چھپانے کے بعد SEENA کی سیٹنگ کھولنے کے لیے: Settings > Accessibility > SEENA Agent > Settings۔"
        tip.textSize = 12f
        tip.setTextColor(Neo.dim)
        tip.setPadding(dp(4), dp(10), dp(4), 0)
        root.addView(tip)

        val sv = ScrollView(this)
        sv.setBackgroundColor(bg)
        sv.addView(root)
        setContentView(sv)
        askPermissions()
    }

    private fun refresh() {
        val on = AuraService.instance != null
        status.text = if (on) "✅ SEENA چالو ہے" else "⚠ SEENA ابھی چالو نہیں: Accessibility میں چالو کریں"
        status.setTextColor(if (on) Neo.green else Neo.goldHi)
        hideBtn.text = if (iconHidden()) "آئیکن دوبارہ دکھاؤ" else "ایپ کا آئیکن چھپاؤ"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == 91 && resultCode == RESULT_OK && uri != null) {
            try {
                val bm = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (bm != null) {
                    val side = Math.min(bm.width, bm.height)
                    val sq = Bitmap.createBitmap(bm, (bm.width - side) / 2, (bm.height - side) / 2, side, side)
                    val out = Bitmap.createScaledBitmap(sq, 320, 320, true)
                    File(filesDir, "moon.png").outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    OrbView.reloadMoon()
                    Toast.makeText(this, "چاند کی تصویر لگ گئی", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "تصویر نہیں لگی", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

