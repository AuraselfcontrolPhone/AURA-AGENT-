package com.example.automation

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class SinaVoiceForegroundService : Service() {

    companion object {
        private const val TAG = "SinaVoiceService"
        private const val CHANNEL_ID = "sina_voice_channel"
        private const val NOTIFICATION_ID = 1092

        const val ACTION_START_OR_UPDATE = "com.example.action.START_OR_UPDATE_SINA"
        const val ACTION_STOP = "com.example.action.STOP_SINA"
        const val EXTRA_ALWAYS_SPEAK = "extra_always_speak"
        const val EXTRA_SHOW_ORB = "extra_show_orb"

        fun syncServiceState(context: Context, alwaysSpeak: Boolean, showOrb: Boolean) {
            val intent = Intent(context, SinaVoiceForegroundService::class.java).apply {
                if (!alwaysSpeak && !showOrb) {
                    action = ACTION_STOP
                } else {
                    action = ACTION_START_OR_UPDATE
                    putExtra(EXTRA_ALWAYS_SPEAK, alwaysSpeak)
                    putExtra(EXTRA_SHOW_ORB, showOrb)
                }
            }
            if (!alwaysSpeak && !showOrb) {
                context.stopService(intent)
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var controller: SinaEngineController
    private var windowManager: WindowManager? = null
    private var orbRootView: View? = null
    private var orbMenuPopup: View? = null

    override fun onCreate() {
        super.onCreate()
        controller = SinaEngineController.getInstance(applicationContext)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            controller.speechEngine.stopListening()
            removeOverlayViews()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val alwaysSpeak = intent?.getBooleanExtra(EXTRA_ALWAYS_SPEAK, false) ?: false
        val showOrb = intent?.getBooleanExtra(EXTRA_SHOW_ORB, false) ?: false

        val notification = buildNotification(alwaysSpeak, showOrb)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        if (alwaysSpeak) {
            controller.speechEngine.setAlwaysSpeakMode(
                enabled = true,
                onResult = { transcript ->
                    controller.executeOrder(transcript, source = "VOICE")
                },
                onError = { err ->
                    Log.w(TAG, "Always-speak error: $err")
                }
            )
        } else {
            controller.speechEngine.stopListening()
        }

        if (showOrb && Settings.canDrawOverlays(this)) {
            showSystemMoonOrb()
        } else {
            removeOverlayViews()
        }

        return START_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showSystemMoonOrb() {
        if (orbRootView != null) return
        val density = resources.displayMetrics.density
        val orbSizePx = (64 * density).toInt()

        val container = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#CC060A17"))
                setStroke((2 * density).toInt(), Color.parseColor("#22D3EE"))
            }
            elevation = 14f * density
        }

        val moonImage = ImageView(this).apply {
            setImageResource(R.drawable.img_moon_orb)
            scaleType = ImageView.ScaleType.CENTER_CROP
            clipToOutline = true
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL }
        }
        container.addView(
            moonImage,
            FrameLayout.LayoutParams(orbSizePx - (8 * density).toInt(), orbSizePx - (8 * density).toInt()).apply {
                gravity = Gravity.CENTER
            }
        )

        val nameTag = TextView(this).apply {
            text = "Sina"
            textSize = 10f
            setTextColor(Color.parseColor("#E2E8F0"))
            setBackgroundColor(Color.parseColor("#B3060A17"))
            setPadding((6 * density).toInt(), 1, (6 * density).toInt(), 1)
        }
        container.addView(
            nameTag,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            }
        )

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            orbSizePx,
            orbSizePx,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (24 * density).toInt()
            y = (220 * density).toInt()
        }

        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        var isDragging = false

        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    isDragging = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) {
                        isDragging = true
                    }
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager?.updateViewLayout(container, params)
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        toggleSystemOrbMenu()
                    }
                    true
                }

                else -> false
            }
        }

        orbRootView = container
        try {
            windowManager?.addView(container, params)
        } catch (e: Exception) {
            Log.e(TAG, "Unable to attach system moon orb", e)
        }
    }

    private fun toggleSystemOrbMenu() {
        if (orbMenuPopup != null) {
            removeMenuPopupOnly()
            return
        }
        val density = resources.displayMetrics.density
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 22f * density
                setColor(Color.parseColor("#F00B1120"))
                setStroke((1.5f * density).toInt(), Color.parseColor("#22D3EE"))
            }
        }

        val title = TextView(this).apply {
            text = "Sina Quick Order"
            textSize = 15f
            setTextColor(Color.parseColor("#22D3EE"))
        }
        val input = EditText(this).apply {
            hint = "Order or question..."
            setHintTextColor(Color.parseColor("#94A3B8"))
            setTextColor(Color.WHITE)
            setPadding(0, (10 * density).toInt(), 0, (10 * density).toInt())
        }

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, (10 * density).toInt(), 0, 0)
        }

        val sendBtn = TextView(this).apply {
            text = "Run & Minimize"
            textSize = 13f
            setTextColor(Color.parseColor("#060A17"))
            setBackgroundColor(Color.parseColor("#22D3EE"))
            setPadding((14 * density).toInt(), (8 * density).toInt(), (14 * density).toInt(), (8 * density).toInt())
            setOnClickListener {
                val cmd = input.text.toString().trim()
                if (cmd.isNotEmpty()) {
                    controller.executeOrder(cmd, source = "ORB")
                }
                removeMenuPopupOnly()
            }
        }

        val alwaysSpeakBtn = TextView(this).apply {
            text = "Always Speak"
            textSize = 13f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1E293B"))
            setPadding((14 * density).toInt(), (8 * density).toInt(), (14 * density).toInt(), (8 * density).toInt())
            setOnClickListener {
                serviceScope.launch {
                    controller.preferences.setAlwaysSpeak(true)
                    controller.speechEngine.setAlwaysSpeakMode(
                        enabled = true,
                        onResult = { controller.executeOrder(it, source = "VOICE") },
                        onError = {}
                    )
                }
                removeMenuPopupOnly()
            }
        }

        val closeBtn = TextView(this).apply {
            text = "Minimize"
            textSize = 13f
            setTextColor(Color.parseColor("#94A3B8"))
            setPadding((12 * density).toInt(), (8 * density).toInt(), (8 * density).toInt(), (8 * density).toInt())
            setOnClickListener { removeMenuPopupOnly() }
        }

        btnRow.addView(sendBtn)
        btnRow.addView(alwaysSpeakBtn)
        btnRow.addView(closeBtn)

        card.addView(title)
        card.addView(input)
        card.addView(btnRow)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            (300 * density).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        orbMenuPopup = card
        try {
            windowManager?.addView(card, params)
        } catch (e: Exception) {
            Log.e(TAG, "Unable to attach orb popup menu", e)
        }
    }

    private fun removeMenuPopupOnly() {
        orbMenuPopup?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {
            }
        }
        orbMenuPopup = null
    }

    private fun removeOverlayViews() {
        removeMenuPopupOnly()
        orbRootView?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {
            }
        }
        orbRootView = null
    }

    private fun buildNotification(alwaysSpeak: Boolean, showOrb: Boolean): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, SinaVoiceForegroundService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        val status = buildString {
            if (alwaysSpeak) append("Always-Speak Active")
            if (alwaysSpeak && showOrb) append(" · ")
            if (showOrb) append("Moon Orb Floating")
        }.ifBlank { "Sina Ready" }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle("Sina AI Assistant")
            .setContentText(status)
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .addAction(0, "Stop", stopIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_sina_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_sina_desc)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        controller.speechEngine.stopListening()
        removeOverlayViews()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
