package com.aura.agent

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.coroutines.resume

/** SEENA's voice. First choice: Gemini natural voice. Fallback: the phone's own Urdu text-to-speech. */
object Speaker {
    @Volatile private var track: AudioTrack? = null
    @Volatile private var engine: TextToSpeech? = null

    suspend fun speak(ctx: Context, text: String, call: Boolean = false) {
        if (text.isBlank()) return
        // saves API quota: the phone's own Urdu voice first (offline), Gemini's natural voice only if that is missing
        if (Prefs.offlineVoice(ctx) && systemSpeak(ctx, text, call)) return
        if (!Net.aiOk(ctx)) return
        val pcm: ByteArray? = withContext(Dispatchers.IO) {
            try { AiClient.tts(ctx, text) } catch (e: Exception) { null }
        }
        if (pcm != null && pcm.isNotEmpty()) play(pcm, call) else systemSpeak(ctx, text, call)
    }

    fun stop() {
        try { track?.stop() } catch (e: Exception) {}
        try { engine?.stop() } catch (e: Exception) {}
    }

    private suspend fun play(pcm: ByteArray, call: Boolean) {
        withContext(Dispatchers.IO) {
            val rate = 24000
            val attrs = AudioAttributes.Builder()
                .setUsage(if (call) AudioAttributes.USAGE_MEDIA else AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(rate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            val t = AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(pcm.size)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            try {
                t.write(pcm, 0, pcm.size)
                track = t
                t.play()
                delay(pcm.size * 1000L / (rate * 2) + 200)
            } finally {
                try { t.stop() } catch (e: Exception) {}
                t.release()
                track = null
            }
        }
    }

    private suspend fun systemSpeak(ctx: Context, text: String, call: Boolean): Boolean {
        return suspendCancellableCoroutine<Boolean> { cont ->
            val holder = arrayOfNulls<TextToSpeech>(1)
            val t = TextToSpeech(ctx.applicationContext) { status ->
                val e = holder[0]
                if (status != TextToSpeech.SUCCESS || e == null) {
                    if (cont.isActive) cont.resume(false)
                } else {
                    val r = e.setLanguage(Locale("ur", "PK"))
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                        e.shutdown()
                        if (cont.isActive) cont.resume(false)
                    } else {
                        engine = e
                        e.setAudioAttributes(AudioAttributes.Builder()
                            .setUsage(if (call) AudioAttributes.USAGE_MEDIA else AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                        e.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) {}
                            override fun onDone(utteranceId: String?) { e.shutdown(); engine = null; if (cont.isActive) cont.resume(true) }
                            @Deprecated("Deprecated in Java")
                            override fun onError(utteranceId: String?) { e.shutdown(); engine = null; if (cont.isActive) cont.resume(false) }
                        })
                        e.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aura")
                    }
                }
            }
            holder[0] = t
            cont.invokeOnCancellation { try { t.stop(); t.shutdown() } catch (e: Exception) {} }
        }
    }
}
