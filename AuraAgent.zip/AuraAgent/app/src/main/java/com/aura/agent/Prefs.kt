package com.aura.agent

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("aura", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("key", "") ?: ""

    /** Accepts messy pasted text (even a whole curl command) and keeps only the key itself. */
    fun setApiKey(c: Context, v: String) {
        val m = Regex("(AIza[\\w-]{30,}|AQ\\.[\\w.\\-]{20,}|sk-ant-[\\w\\-]{20,})").find(v)
        val k = m?.value ?: v.trim().replace(Regex("\\s+"), "")
        sp(c).edit().putString("key", k).apply()
    }

    /** Names with "gemini" use the Google Gemini API, anything else uses Claude. */
    fun model(c: Context): String {
        val m = sp(c).getString("model", "") ?: ""
        return if (m.isBlank()) "gemini-3.7-flash" else m
    }

    fun setModel(c: Context, v: String) {
        val first = v.trim().split(Regex("\\s+")).firstOrNull().orEmpty()
        sp(c).edit().putString("model", if (first.lowercase().contains("curl")) "" else first).apply()
    }

    /** Empty = automatic. Anything that is not a real http(s) address is ignored. */
    fun baseUrl(c: Context): String {
        val u = sp(c).getString("url", "") ?: ""
        return if (u.startsWith("http://") || u.startsWith("https://")) u else ""
    }

    fun setBaseUrl(c: Context, v: String) = sp(c).edit().putString("url", v.trim()).apply()

    /* ---- generic helpers + settings ---- */
    fun getBool(c: Context, k: String, def: Boolean): Boolean = sp(c).getBoolean(k, def)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun getStr(c: Context, k: String, def: String): String = sp(c).getString(k, def) ?: def
    fun setStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v.trim()).apply()
    fun getInt(c: Context, k: String, def: Int): Int = sp(c).getInt(k, def)
    fun setInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()

    /** Ghost mode: the orb and edge are invisible until you touch them. */
    fun ghost(c: Context): Boolean = getBool(c, "ghost", true)
    fun speakReplies(c: Context): Boolean = getBool(c, "speak", true)
    fun callAuto(c: Context): Boolean = getBool(c, "callAuto", true)
    fun owner(c: Context): String = getStr(c, "owner", "")
    fun brief(c: Context): String = getStr(c, "brief", "وہ ابھی مصروف ہیں۔ پیغام لے لو، اور اگر فوری کام ہو تو پوچھو کہ وہ کس وقت کال بیک کریں۔")
    fun voice(c: Context): String = getStr(c, "voice", "Kore")
}
