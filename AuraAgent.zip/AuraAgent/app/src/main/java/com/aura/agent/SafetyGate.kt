package com.aura.agent

/** The 3 things AURA never does without asking: send money, delete forever, change passwords. */
object SafetyGate {
    private val words = listOf(
        "pay", "send money", "transfer", "purchase", "buy now", "place order", "confirm payment",
        "delete", "remove permanently", "erase", "factory reset",
        "password", "change pin",
        "ادائیگی", "پیسے بھیج", "ٹرانسفر", "خرید", "ڈیلیٹ", "مٹا", "پاسورڈ"
    )

    fun risky(label: String): Boolean {
        val l = label.lowercase()
        return words.any { l.contains(it) }
    }
}
