package com.example.ai

import android.util.Log
import com.example.data.DeviceMemoryEntity
import com.example.data.SmartButtonEntity
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

data class SinaCommandPlan(
    val intentType: String, // SMART_HOME_ON, SMART_HOME_OFF, OPEN_APP, DIAL_NUMBER, WHATSAPP_MESSAGE, SMS_MESSAGE, SEARCH_YOUTUBE, SEARCH_WEB, OPEN_SETTINGS, SCREEN_UI_ACTION, QUESTION_ANSWER
    val targetButtonId: Long = 0L,
    val targetAppPackage: String = "",
    val phoneNumber: String = "",
    val messageBody: String = "",
    val queryText: String = "",
    val uiTargetLabel: String = "",
    val spokenReply: String = "",
    val briefReport: String = "",
    val recoveryNote: String = ""
)

class SinaAiService {

    companion object {
        private const val TAG = "SinaAiService"
        private const val MODEL_PRIMARY = "gemini-3.8-flash"
    }

    private val commandSchema = Schema.obj(
        properties = mapOf(
            "intentType" to Schema.enumeration(
                values = listOf(
                    "SMART_HOME_ON",
                    "SMART_HOME_OFF",
                    "OPEN_APP",
                    "DIAL_NUMBER",
                    "WHATSAPP_MESSAGE",
                    "SMS_MESSAGE",
                    "SEARCH_YOUTUBE",
                    "SEARCH_WEB",
                    "OPEN_SETTINGS",
                    "SCREEN_UI_ACTION",
                    "QUESTION_ANSWER"
                ),
                description = "Exact action category to execute."
            ),
            "targetButtonId" to Schema.integer(description = "Matching Smart Home button ID, or 0 if none."),
            "targetAppPackage" to Schema.string(description = "Exact Android package name from Device Memory when opening an app, or empty string."),
            "phoneNumber" to Schema.string(description = "Clean phone digits if dialing/messaging, or empty string."),
            "messageBody" to Schema.string(description = "Message body if sending WhatsApp/SMS, or text to type."),
            "queryText" to Schema.string(description = "Search query, settings target (WIFI, BLUETOOTH, ACCESSIBILITY, DISPLAY, APPS), or concise topic."),
            "uiTargetLabel" to Schema.string(description = "Exact UI button/field label to find on screen if using SCREEN_UI_ACTION."),
            "spokenReply" to Schema.string(description = "Natural, clear, concise spoken reply in the user's language (Urdu, Roman Urdu, or English)."),
            "briefReport" to Schema.string(description = "Short 1-line completion summary report for the user."),
            "recoveryNote" to Schema.string(description = "Alternative strategy if a prior step got stuck or user corrected mid-task.")
        )
    )

    private val plannerModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_PRIMARY,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = commandSchema
                temperature = 0.2f
            }
        )
    }

    private val conversationalModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_PRIMARY,
            generationConfig = generationConfig {
                temperature = 0.6f
            }
        )
    }

    suspend fun planTextOrder(
        userText: String,
        buttons: List<SmartButtonEntity>,
        memories: List<DeviceMemoryEntity>,
        currentForegroundPackage: String,
        liveCorrectionContext: String = ""
    ): Result<SinaCommandPlan> {
        return try {
            val prompt = buildRoutingPrompt(
                userText = userText,
                buttons = buttons,
                memories = memories,
                currentForegroundPackage = currentForegroundPackage,
                liveCorrectionContext = liveCorrectionContext
            )
            val response = withTimeout(60_000L) {
                plannerModel.generateContent(prompt)
            }
            val jsonText = response.text ?: throw IllegalStateException("Empty AI response")
            Result.success(parseCommandPlan(jsonText))
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Command planning timed out", e)
            Result.failure(Exception("Request timed out. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Failed to plan order", e)
            Result.failure(e)
        }
    }

    suspend fun planAudioOrder(
        audioBytes: ByteArray,
        buttons: List<SmartButtonEntity>,
        memories: List<DeviceMemoryEntity>,
        currentForegroundPackage: String
    ): Result<SinaCommandPlan> {
        return try {
            val systemContext = buildRoutingPrompt(
                userText = "[USER SPOKE AN AUDIO VOICE NOTE — LISTEN CAREFULLY TO URDU / ROMAN URDU / ENGLISH AND EXTRACT THE EXACT ORDER]",
                buttons = buttons,
                memories = memories,
                currentForegroundPackage = currentForegroundPackage,
                liveCorrectionContext = ""
            )
            val response = withTimeout(60_000L) {
                plannerModel.generateContent(
                    content {
                        inlineData(audioBytes, "audio/mp4")
                        text(systemContext)
                    }
                )
            }
            val jsonText = response.text ?: throw IllegalStateException("Empty AI response")
            Result.success(parseCommandPlan(jsonText))
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Audio order timed out", e)
            Result.failure(Exception("Audio analysis timed out. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Failed to process audio order", e)
            Result.failure(e)
        }
    }

    fun streamQuestionAnswer(
        question: String,
        historyContext: String,
        memories: List<DeviceMemoryEntity>,
        buttons: List<SmartButtonEntity>
    ): Flow<String> = flow {
        val memorySnippet = memories.take(25).joinToString("\n") {
            "- [${it.memoryType}] ${it.label} (${it.appPackage}): ${it.actionHint}"
        }
        val buttonSnippet = buttons.joinToString("\n") {
            "- ID=${it.id} '${it.name}' (${it.roomSection}) state=${if (it.isOn) "ON" else "OFF"}"
        }
        val prompt = """
            You are Sina (سینا), an ultra-intelligent, warm, natural-sounding futuristic AI assistant on the user's Android phone.
            Reply clearly and naturally in the same language the user asked in (Urdu, Roman Urdu, or English).
            Keep answers accurate, helpful, and easy to hear aloud if read by TTS.
            
            Known Smart Home Devices:
            $buttonSnippet
            
            Known Device Memory:
            $memorySnippet
            
            Recent Conversation:
            $historyContext
            
            User Question: $question
        """.trimIndent()

        val accumulated = StringBuilder()
        withTimeout(60_000L) {
            conversationalModel.generateContentStream(prompt).collect { chunk ->
                val text = chunk.text.orEmpty()
                if (text.isNotEmpty()) {
                    accumulated.append(text)
                    emit(accumulated.toString())
                }
            }
        }
        if (accumulated.isBlank()) {
            throw IllegalStateException("Model returned an empty response.")
        }
    }.catch { e ->
        if (e is CancellationException) throw e
        Log.e(TAG, "Q&A stream failed", e)
        throw e
    }

    suspend fun summarizeIncomingCall(
        callerDisplay: String,
        ringCount: Int,
        callerMessage: String
    ): Result<String> {
        return try {
            val prompt = """
                You are Sina, the user's smart call-guard assistant.
                Caller "$callerDisplay" called for ring #$ringCount (auto-answered on 2nd attempt).
                Caller said: "$callerMessage"
                Provide a crisp 1-2 sentence report explaining who called, what they need, and the suggested next action.
                Match the caller's language if Urdu/Roman Urdu, otherwise clear English.
            """.trimIndent()
            val response = withTimeout(45_000L) {
                conversationalModel.generateContent(prompt)
            }
            val text = response.text?.trim().orEmpty()
            if (text.isBlank()) Result.failure(IllegalStateException("Empty summary"))
            else Result.success(text)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Call summary failed", e)
            Result.failure(e)
        }
    }

    suspend fun resolveStuckLoop(
        goal: String,
        failedSteps: List<String>,
        visibleScreenLabels: List<String>,
        memories: List<DeviceMemoryEntity>
    ): Result<SinaCommandPlan> {
        return try {
            val prompt = """
                ANTI-LOOP RECOVERY MODE:
                Sina was trying to accomplish: "$goal"
                Recent repeated/stuck steps: ${failedSteps.joinToString(" -> ")}
                Currently visible UI labels on screen: ${visibleScreenLabels.take(25).joinToString(", ")}
                Remembered device facts/apps: ${memories.take(20).joinToString("; ") { "${it.label}=${it.actionHint}" }}
                
                Do NOT repeat the same failed step! Pick a smarter direct alternative:
                - If dialing/typing a number got stuck, switch to DIAL_NUMBER or WHATSAPP_MESSAGE directly.
                - If a screen element isn't visible, pick an exact visible label from above or OPEN_SETTINGS / OPEN_APP directly.
                Return the recovery plan JSON.
            """.trimIndent()
            val response = withTimeout(45_000L) {
                plannerModel.generateContent(prompt)
            }
            val jsonText = response.text ?: throw IllegalStateException("Empty recovery plan")
            Result.success(parseCommandPlan(jsonText))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Anti-loop recovery failed", e)
            Result.failure(e)
        }
    }

    private fun buildRoutingPrompt(
        userText: String,
        buttons: List<SmartButtonEntity>,
        memories: List<DeviceMemoryEntity>,
        currentForegroundPackage: String,
        liveCorrectionContext: String
    ): String {
        val buttonsList = buttons.joinToString("\n") { b ->
            "ID=${b.id} | Name='${b.name}' | Room='${b.roomSection}' | Aliases='${b.voiceAliases}' | State=${if (b.isOn) "ON" else "OFF"}"
        }
        val appsList = memories.filter { it.memoryType == "APP" }.take(35).joinToString("\n") { m ->
            "App='${m.label}' -> pkg='${m.appPackage}'"
        }
        val learnedElements = memories.filter { it.memoryType != "APP" }.take(25).joinToString("\n") { m ->
            "[${m.memoryType}] ${m.screenTitle}: '${m.label}' -> ${m.actionHint}"
        }

        return """
            You are Sina (سینا), an intelligent, fast Android & Smart Home AI assistant.
            Analyze the user's command (which may be in English, Urdu script, or Roman Urdu) and output the exact structured JSON plan.
            
            CRITICAL RULES:
            1. Smart Home Buttons: If the user asks to turn ON/OFF, open/close, chala do/band karo any smart home device listed below, choose SMART_HOME_ON or SMART_HOME_OFF and set targetButtonId accurately. This runs silently via URL without opening the app.
            2. Direct Phone Actions: Never get confused typing numbers or finding menus. If user says call/dial a number -> DIAL_NUMBER with clean digits in phoneNumber. If WhatsApp message -> WHATSAPP_MESSAGE. If SMS -> SMS_MESSAGE.
            3. Opening Apps: Use the exact package name from Known Installed Apps below -> OPEN_APP with targetAppPackage.
            4. Mid-Task Corrections: If liveCorrectionContext is non-empty, prioritize the user's correction immediately and abandon the old mistake.
            5. General Questions ("سوالات"): If the user is asking a general question, fact, advice, or help, use QUESTION_ANSWER and put the complete natural answer in spokenReply AND a short 1-line summary in briefReport.
            6. Keep spokenReply natural, friendly, clear, and concise (under 2 sentences for actions, fuller for Q&A).
            
            Current foreground app package: $currentForegroundPackage
            ${if (liveCorrectionContext.isNotBlank()) "LIVE USER CORRECTION: $liveCorrectionContext" else ""}
            
            Smart Home Automation Buttons:
            $buttonsList
            
            Known Installed Apps (studied on phone):
            $appsList
            
            Remembered Screen Elements & Corrections:
            $learnedElements
            
            User Order: $userText
        """.trimIndent()
    }

    private fun parseCommandPlan(jsonText: String): SinaCommandPlan {
        val json = JSONObject(jsonText)
        return SinaCommandPlan(
            intentType = json.optString("intentType", "QUESTION_ANSWER"),
            targetButtonId = json.optLong("targetButtonId", 0L),
            targetAppPackage = json.optString("targetAppPackage", ""),
            phoneNumber = json.optString("phoneNumber", ""),
            messageBody = json.optString("messageBody", ""),
            queryText = json.optString("queryText", ""),
            uiTargetLabel = json.optString("uiTargetLabel", ""),
            spokenReply = json.optString("spokenReply", ""),
            briefReport = json.optString("briefReport", ""),
            recoveryNote = json.optString("recoveryNote", "")
        )
    }
}
